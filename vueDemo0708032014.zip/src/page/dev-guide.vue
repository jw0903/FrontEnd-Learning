<template>
    <div class="dev-guide">
        <el-container>
            <el-aside width="250px">
                <el-menu
                    default-active="1"
                    class="el-menu-vertical-demo"
                    @open="handleOpen"
                    @close="handleClose"
                    @select="handleSelect"
                    background-color="#3b3b3b"
                    text-color="#e3e6e8"
                    active-text-color="#409eff">
                    <el-menu-item index="1">
                        <i class="el-icon-notebook-1"></i>
                        <span>概述</span>
                    </el-menu-item>
                    <el-menu-item index="2">
                        <i class="el-icon-coin"></i>
                        <span slot="title">环境搭建</span>
                    </el-menu-item>
                    <el-submenu index="3">
                        <template slot="title">
                            <i class="el-icon-document"></i>
                            <span slot="title">开发指南</span>
                        </template>
                        <el-menu-item-group>
                            <template slot="title">插件使用</template>
                            <el-menu-item index="3-1">获取移动端登录信息</el-menu-item>
                            <el-menu-item index="3-2">获取GPS</el-menu-item>
                            <el-menu-item index="3-3">扫描二维码</el-menu-item>
                            <el-menu-item index="3-4">拍照/上传照片</el-menu-item>
                            <el-menu-item index="3-5">视频预览回放</el-menu-item>
                            <!-- <el-menu-item index="3-6">网络请求</el-menu-item> -->
                            <el-menu-item index="3-7">网络状态获取</el-menu-item>
                            <el-menu-item index="3-8">安卓原生的方法</el-menu-item>
                        </el-menu-item-group>
                        <el-menu-item-group>
                            <template slot="title">插件编写</template>
                            <el-menu-item index="3-9">原生插件开发</el-menu-item>
                        </el-menu-item-group>
                    </el-submenu>
                    <el-menu-item index="4">
                        <i class="el-icon-download"></i>
                        <span slot="title">相关下载</span>
                    </el-menu-item>
                </el-menu>
            </el-aside>
            <el-main>
                <div v-html="markdownTp" v-if="showMd"></div>
                <div v-else class="download">
                    <el-button type="primary" @click="downloadDemo">下载<i class="el-icon-download el-icon--right"></i></el-button>
                    <!-- <img src="../assets/logo.png" title="扫描下载app" > -->
                </div>
            </el-main>
        </el-container>
    </div>
</template>

<script>
import introduce from './markdown/introduce.md';
import envBuild from './markdown/env_build.md';
import login from './markdown/login.md';
import gps from './markdown/gps.md';
import QRcode from './markdown/QRcode.md';
import takePic from './markdown/takePic.md';
import videoPlay from './markdown/videoPlay.md';
import netRequest from './markdown/netRequest.md';
import netStatus from './markdown/netStatus.md';
import toolFun from './markdown/toolFun.md';
import pluginDev from './markdown/plugin_dev.md';
import hljs from "highlight.js";
import 'highlight.js/styles/monokai-sublime.css';
// import 'highlight.js/styles/solarized_light.css'
// import 'highlight.js/styles/github.css'
// import 'highlight.js/styles/a11y-dark.css';
const highlightCode = () => {
    const preEl = document.querySelectorAll('pre')
    preEl.forEach((el) => {
        hljs.highlightBlock(el)
    })
}
export default {
    name: 'devGuide',
    data () {
        return {
            markdownTp: introduce,
            result: '',
            md: '',
            showMd: true
        }
    },
    components: {
    },
    mounted () {
        highlightCode();
        this.$store.commit('setIndex', 1);
    },
    methods: {
        handleSelect (index) {
            switch (index) {
                case '1':
                    this.showMd = true;
                    this.markdownTp = introduce;
                    break;
                case '2':
                    this.showMd = true;
                    this.markdownTp = envBuild;
                    break;
                case '3-1':
                    this.showMd = true;
                    this.markdownTp = login;
                    break;
                case '3-2':
                    this.showMd = true;
                    this.markdownTp = gps;
                    break;
                case '3-3':
                    this.showMd = true;
                    this.markdownTp = QRcode;
                    break;
                case '3-4':
                    this.showMd = true;
                    this.markdownTp = takePic;
                    break;
                case '3-5':
                    this.showMd = true;
                    this.markdownTp = videoPlay;
                    break;
                case '3-6':
                    this.showMd = true;
                    this.markdownTp = netRequest;
                    break;
                case '3-7':
                    this.showMd = true;
                    this.markdownTp = netStatus;
                    break;
                case '3-8':
                    this.showMd = true;
                    this.markdownTp = toolFun;
                    break;
                case '3-9':
                    this.showMd = true;
                    this.markdownTp = pluginDev;
                    break;
                case '4':
                    this.showMd = false;
                    break;
                default:
                    this.showMd = true;
                    this.markdownTp = introduce;
                    break;
            }
            this.result = this.markdownTp;
            this.$nextTick(() => {
                highlightCode();
                document.getElementsByClassName('el-main')[0].scrollTop = 0;
            })
        },
        handleOpen () {
            console.log('open');
        },
        handleClose () {
            console.log('close');
        },
        downloadDemo () {
            alert('下载demo代码');
        }
    }
}
</script>

<style lang="scss" scoped>
$font-color: #e3e6e8;
$font-color-white: #fff;
$border-color: #444;
.dev-guide {
    width: 100%;
    height: 100%;
    .el-container {
        height: 100%;
    }
    .el-aside {
        height: 100%;
        position: fixed;
        border-right: 1px solid $border-color;
        .el-menu {
            border-right: none;
            height: 100%;
            .el-submenu__title {
                &:hover {
                    background: #fff;
                }
            }
        }
    }
    .el-main {
        padding-right: 20%;
        padding: 20px;
        flex: auto;
        margin-left: 250px;
        color: $font-color;
        >div {
            min-height: 540px;
            padding: 20px;
            line-height: 30px;
        }
        &::-webkit-scrollbar {
            display: none;
        }
    }
}
</style>
<style>
.el-main h1 {
    color: $font-color-white;
}
.el-main hr {
    height: 2px;
    background-color: #444;
    border: none;
}
.el-main a {
    color: rgb(64, 158, 255);
}
        
table {
    border-collapse: collapse;
}
th, td {
    border: 2px solid #444;
    padding: .6em 1em;
    text-align: center;
}
/* .hljs {
    padding: 1em;
    border-radius: 5px;
    font-size: 16px;
} */
.el-menu-item:hover, .el-submenu>div:hover {
    background-color: #444 !important;
    color: #409eff !important;
}
.el-menu-item span:hover, .el-sub {
    color: #409eff;
}
</style>

