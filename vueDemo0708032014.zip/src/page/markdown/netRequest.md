### 网络请求

hik-hatom-api-c-net.js中export了netRequest函数用于调用移动端进行发起请求

#### 通用参数

| 参数          | 描述          |
| ------------- |:-------------:|
| obj           | 包含发送请求的各项参数 |

#### 响应参数

| 参数          | 描述          |
| ------------- |:-------------:|
| res           | 返回请求成功后的结果 |

#### 使用示例

```
let obj = {
    url: url,        // 请求接口url
    method: "post",  // 请求方法
    contentType: "application/json;charset=UTF-8",
    postMode: "json",
    data: params,    // 请求接口传参
};
netRequest(obj).then(
    res => {
        // 请求成功，进行数据渲染
    }
).catch(
    err => {
        alert(err);                     
    }
);
```
> 此方法是1.1.0项目请求接口所调用。 其他项目开发可以用axios直接请求，不需要通过插件进行请求，具体请求步骤可参考demo中的数据请求。
