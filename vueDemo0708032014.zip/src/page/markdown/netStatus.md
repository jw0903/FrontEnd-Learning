### 网络状态获取

hik-hatom-api-c-network.js文件中定义了6个函数，用于不同情况下对移动端网络状态的获取。

#### 通用参数

不需要传参

#### 响应参数

- getNetWorkType 获取网络状态类型，返回网络状态值

| 返回值         | 类型           | 描述       |
| ------------- | -------------- | ---------- |
| UNKNOWN       | String         | 未知连接    |
| ETHERNET      | String         | 以太网连接  |
| WIFI          | String         | WiFi连接    |
| CELL_2G       | String         | 2G 网络     |
| CELL_3G       | String         | 3G 网络     |
| CELL_4G       | String         | 4G 网络     |
| CELL          | String         | 通用链接    |
| NONE          | String         | 没有网络连接 |

- onNetWorkOnLine 在线状态事件监听

```
onNetWorkOnLine(() => {
    // 在线状态事件监听回调函数
})
```

- onNetWorkOffLine 离线状态事件监听

```
onNetWorkOffLine(() => {
    // 离线状态事件监听回调函数
})
```

- isNetWorkStatus 是否有网络

| 返回值         | 类型           | 描述       |
| ------------- | -------------- | ---------- |
| true          | Boolean        | 是         |
| false         | Boolean        | 否         |

- isWifiConnect 是否WIFI连接

| 返回值         | 类型           | 描述       |
| ------------- | -------------- | ---------- |
| true          | Boolean        | 是         |
| false         | Boolean        | 否         |

- isMobileConnect 是否移动网络连接

| 返回值         | 类型           | 描述       |
| ------------- | -------------- | ---------- |
| true          | Boolean        | 是         |
| false         | Boolean        | 否         |
