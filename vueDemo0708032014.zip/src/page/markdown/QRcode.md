### 扫描二维码

hik-hatom-api-c-barcodescanner.js文件中的takeBarcodeScannerScan函数，用于调用原生进行二维码扫描

#### 通用参数

| 参数          | 描述          |
| ------------- |:-------------:|
| onSuccess     | 成功回调函数   |
| onFail        | 失败回调函数   |

#### 响应参数

| 参数          | 类型           | 描述        |
| ------------- | -------------- | ---------- |
| res           | String         | 扫描信息，可转化JSON对象 |

#### 使用示例

```
takeBarcodeScannerScan(
    res => {
        // 正常调用原生扫描二维码
        res = JSON.parse(res);
        // 返回信息
        {
            text: "",        // 扫描所获得的信息(文本/链接)
            format: "",      // 所扫描的格式(二维码：QR_CODE)
            cancelled: false // 是否取消扫描
        }
    },
    err => {
        // 错误处理
    }
)
```
