### 基本用法

:::demo Alert组件提供四种主题，由`type`属性指定，默认值为`info`。
```html
<template>
    <el-alert title="成功提示" type="success"></el-alert>
    <el-alert title="消息提示的文案" type="info"></el-alert>
    <el-alert title="警告提示" type="warning"></el-alert>
</template>
```
:::
