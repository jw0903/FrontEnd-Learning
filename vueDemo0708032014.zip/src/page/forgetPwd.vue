<template>
    <div class="main forgetpwd">
        <el-row type="flex" justify="center" class="main-panel">
            <el-col :span="24" class="panel-warp">
                <header>找回密码</header>
                <div class="panel-inner">
                    <el-form :model="ruleForm" ref="verifyCodeForm"  :rules="rules">
                        <el-form-item  prop="phoneNum">
                            <el-input type="text" placeholder="手机号" @blur="blurPhoneNo" @focus="focusPhoneNo" @keyup.native="btnAbled('phoneNum')"  v-model="ruleForm.phoneNum"></el-input>
                        </el-form-item>
                        <el-form-item  prop="identifyCode" >
                            <el-row type="flex" :gutter="20">
                                <el-col :span="24">
                                    <el-input type="text" v-model="ruleForm.identifyCode" placeholder="验证码" @keyup.native="btnAbled('verifyCodeForm')" @keyup.enter.native="submitModify('verifyCodeForm')"></el-input>
                                </el-col>
                                <el-col :span="8">
                                    <el-button :disabled="isDisabled" :class="{'loading-sytle': isLoading}" type="primary" @click="getVerifyCode('verifyCodeForm')">{{ buttonName }}</el-button>
                                </el-col>
                            </el-row>
                        </el-form-item>
                        <!-- <span class="unBindUser" v-if="isBind">手机号未绑定账户，请联系管理员</span> -->
                        <el-form-item>
                            <el-button type="primary" icon="el-icon-up" class="full-btn " :disabled="subIsDisabled" :loading="isBtnLoading" @click="submitModify('verifyCodeForm')">{{btnText}}</el-button>
                        </el-form-item>
                    </el-form>
                </div>
            </el-col >
        </el-row>
    </div>
</template>
<script>
import api from '../api/api.js'
export default {
    data () {
        let self = this;
        let phoneNumLength = (rule, value, callback) => {
            value = value.replace(/-/g, "");
            if (value.length !== 11) {
                callback(new Error("请输入11位手机号码"));
            } else {
                callback();
            }
        };
        let validatePhoneNum = (rule, value, callback) => {
            value = value.replace(/-/g, "");
            if (!(/^1[0-9]{10}$/.test(value))) {
                callback(new Error(this.$msgTxt.phoneError));
            } else {
                callback();
            }
        };
        return {
            buttonName: "发送验证码",
            isLoading: false,
            isBind: false,
            isDisabled: true,
            phoneNumValid: false,
            subIsDisabled: true,
            time: 60,
            isBtnLoading: false,
            ruleForm: {
                phoneNum: "",
                identifyCode: ""
            },
            userName: "",
            rules: {
                phoneNum: [
                    { required: true, message: "请输入手机号", trigger: "blur" },
                    { validator: phoneNumLength, trigger: "blur" },
                    { validator: validatePhoneNum, trigger: "blur" }
                ],
                identifyCode: [
                    { required: true, message: "请输入验证码", trigger: "blur" },
                    { trigger: "blur" }
                ]
            }
        };
    },
    created () {
        this.userName = this.$route.params.name;
    },
    computed: {
        btnText () {
            if (this.isBtnLoading) return "下一步...";
            return "下一步";
        }
    },
    methods: {
        /* 判断手机验证码 */
        submitModify (formName) {
            let that = this;
            this.$refs[formName].validate((valid) => {
                if (!valid) {
                    return false;
                }
                this.isBtnLoading = true;
                this.$ajax({
                    method: "post",
                    url: api.checkVerifyCode,
                    data: {
                        phone: this.ruleForm.phoneNum.replace(/-/g, ""),
                        productCode: 'hatom',
                        type: 1,
                        code: this.ruleForm.identifyCode
                    }
                }).then((res) => {
                    if (res.data.code == "0") {
                        this.$router.push({
                            name: "resetPassword",
                            params: {
                                verifyCode: res.data.data.verifyCode,
                                name: this.ruleForm.phoneNum.replace(/-/g, "")
                            }
                        });
                    } else {
                        this.isBtnLoading = false;
                        this.$message.warning(res.data.msg);
                    }
                }).catch((err) => {
                    this.isBtnLoading = false;
                    console.log(err);
                });
            });
        },
        /**
         * 手机号码输入框失焦/获取焦点 手机号码格式产生变化
         */
        focusPhoneNo () {
            this.ruleForm.phoneNum = this.ruleForm.phoneNum.replace(/-/g, "");
        },
        blurPhoneNo () {
            this.$refs.verifyCodeForm.validateField("phoneNum", (err) => {
                if (!err || err === "手机号未绑定账户，请联系管理员") {
                    let arr = this.ruleForm.phoneNum.split("");
                    arr.splice(3, 0, "-");
                    arr.splice(8, 0, "-");
                    this.ruleForm.phoneNum = arr.join("");
                }
            });
        },
        /**
         * 获取手机验证码
         * @param formName
         */
        getVerifyCode (formName) {
            this.isDisabled = true;
            this.buttonName = "正在发送...";
            this.$refs[formName].validateField("phoneNum", (err) => {
                if (err) {
                    return false;
                } else {
                    this.$ajax({
                        method: "post",
                        url: api.sendCode,
                        data: {
                            phone: this.ruleForm.phoneNum.replace(/-/g, ""),
                            productCode: 'hatom',
                            type: 1
                        }
                    }).then((res) => {
                        if (res.data.code == '1007') {
                            this.$message.warning(res.data.msg);
                            this.buttonName = "重新发送";
                        } else if (res.data.code == '0') {
                            this.$message.success("发送验证码成功！");
                            this.changeBtn();
                        } else {
                            this.$message.warning(res.data.msg);
                            this.isDisabled = false;
                            this.buttonName = "重新发送";
                        }
                    }).catch((err) => {
                        this.isDisabled = false;
                        this.buttonName = "重新发送";
                        // this.$message.warning("发送验证码失败！");
                        console.log(err);
                    });
                }
            });
        },
        /**
         * 按钮是否可点击
         */
        btnAbled (name) {
            if (name === "phoneNum") {
                this.$refs.verifyCodeForm.validateField("phoneNum", (err) => {
                    if (err) {
                        this.phoneNumValid = false;
                        this.isDisabled = true;
                        return false;
                    } else {
                        this.phoneNumValid = true;
                        this.isDisabled = false;
                    }
                });
            } else {
                this.$refs[name].validateField("identifyCode", (err) => {
                    if (!err && this.phoneNumValid) {
                        this.subIsDisabled = false;
                    } else {
                        this.subIsDisabled = true;
                    }
                });
            }
        },
        /**
         * 获取验证码时改变按钮状态
         */
        changeBtn () {
            this.isDisabled = true;
            let interval = setInterval(() => {
                this.isLoading = true;
                this.buttonName = this.time + " 秒";
                this.time--;
                if (this.time < 0) {
                    this.buttonName = "重新发送";
                    this.time = 60;
                    this.isDisabled = false;
                    this.isLoading = false;
                    clearInterval(interval);
                }
            }, 1000);
        }
    }
};
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
$background-color-black: #333;
$background-color-gray: #3b3b3b;
$font-color: #e3e6e8;
$font-color-white: #fff;
$border-color: #444;
.main {
    width: 100%;
    height: 100%;
    .main-panel {
        width: 100%;
        height: calc(100% - 96px);
        min-height: 600px;
        display: flex;
        align-items: center;
        .panel-warp {
            width: 80%;
            height: 50%;
            min-height: 410px;
            max-width: 1096px;
            max-height: 560px;
            background-color: $background-color-gray;
            padding: 24px 32px;
            header {
                padding-bottom: 8px;
                color: #4D4D4D;
                font-size: 24px;
                border-bottom: solid 1px $border-color;
                color: #fff;
            }
            .panel-inner {
                width: 80%;
                max-width: 750px;
                margin: 96px auto 0;
                form {
                    position: relative;
                    max-width: 420px;
                    margin: 0 auto;
                    .margin-bottom {
                        margin-bottom: 4px;
                    }
                    .unBindUser {
                        display: block;
                        margin-bottom: 15px;
                        font-size: 12px;
                        color: #999999;
                    }
                    .unBindUser:before {
                        position: relative;
                        top: 3px;
                        width: 17px;
                        height: 17px;
                        padding-right: 20px;
                        display: inline-block;
                        content: "";
                        background: url("../assets/icon/error.png") no-repeat 0 1px;
                    }
                    input {
                        font-size: 14px;
                        height: 44px;
                    }
                    button {
                        font-size: 12px;
                        width: 96px;
                        height: 44px;
                    }
                    .loading-sytle {
                        background: #F7F9FA;
                        color: #999999;
                        border-color: #F7F9FA;
                    }
                    .full-btn {
                        font-size: 14px;
                        font-weight: normal;
                        width: 100%;
                        max-width: 420px;
                        height: 44px;
                    }
                }
            }
        }
    }
}
</style>

<style>
.forgetpwd .el-input__inner {
/**     padding: 13px 10px;
        font-size: 16px;
        outline: none;
        background: transparent;
        border: 0px;
        border-bottom: 1px solid #fff;
        border-radius: 0px;
        letter-spacing: 1.6px;
        color: #fff;*/
        color: #e3e6e8;
        background: #333;
        border: 1px solid #666;
}
.case .form-item .el-input__inner::-webkit-input-placeholder {
    color: #ccc;
}
</style>
