<template>
    <div class="test">
        <h1>TEST PAGE</h1>
    </div>
</template>

<script>
export default {
    
}
</script>

<style lang="scss" scoped>
.test {
    background: #fff;
    color: #000;
}
</style>

