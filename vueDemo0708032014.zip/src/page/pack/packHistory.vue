<template>
    <div class="pack_history">
        <el-container>
            <el-main>
                <div class="modelList" v-if="showModel">
                    <li class="model" v-for="(item, index) in modelList" :key="index">
                        <i class="image"></i>
                        <div class="content">
                            <h1>{{item.packName}}</h1>
                            <p>{{item.packDesc}}</p>
                        </div>
                        <div class="user">
                            <span class="name">{{item.userName}}</span>
                            <span class="date">{{item.updateTime}}</span>
                        </div>
                    </li>
                </div>
            </el-main>
        </el-container>
    </div>
</template>

<script>
export default {
    name: 'packHistory',
    data () {
        return {
            modelList: [],
            historyList: [],
            showModel: true,
            form: {
                modelSVNPath: '',
                branchSVNPath: '',
                SVNAccount: '',
                SVNPwd:'',
                modType: '',
                modTypeOptions: [
                    {
                        option: '文件替换',
                        value: 'fileChange'
                    },
                    {
                        option: '文件修改',
                        value: 'fileMod'
                    }
                ],
                uploadFile: [
                    {
                        type: '',
                        file: '',
                    }
                ],
                name: '',
                file: '',
                type: [{
                    options: ['图标', 'H5资源包']
                }],
            },
            options: [
                '图标',
                'H5资源包'
            ],
            fileList:[]
        }
    },
    mounted () {
        this.getModel();
    },
    methods: {
        handleEdit () {},
        handleDelete () {},
        handlePreview () {

        },
        handleRemove (){},
        getModel () {
            this.$ajax({
                methods: 'get',
                url: 'http://10.19.171.20:8899/mock/5d00dc9ef6f049295807e948/hat/modelList',
                params: {
                },
            }).then((res) => {
                this.modelList = res.data.data;
            }).catch((err) => {
                console.log(err);
            })
        },
        getHistory () {
            this.$ajax({
                methods: 'get',
                url: 'http://10.19.171.20:8899/mock/5d00dc9ef6f049295807e948/hat/historyList',
            }).then((res) => {
                this.historyList = res.data.data;
            }).catch((err) => {
                console.log(err);
            })
        },
        handleSelect (index) {
            switch (index) {
                case '1':
                    this.modelList = [];
                    this.getModel();
                    this.showModel = true;
                    this.showHistory = false;
                    break;
                case '2':
                    this.historyList = [];
                    this.getHistory();
                    this.showHistory = true;
                    this.showModel = false;
                    break;
                default: 
                    break;
            }
        },
        getInModel (item) {
            this.$router.push({
                name: 'pack',
                params: {
                    type: 'pack'
                }
            })
        },
        goBack () {
            this.$router.push('packList');
        },
        addUpload () {
            if (this.form.file === 'fileModify') {
                this.form.type.push({
                    "options":[
                        '名称',
                        '包名',
                        '版本号',
                        '版本名称'
                    ]
                })
            } else {
                this.form.type.push({
                    "options":[
                        '图标',
                        'H5资源包'
                    ]
                })
            }
        },
        removeUpload (item) {
            var index = this.form.type.indexOf(item);
            if (index !== -1) {
                this.form.type.splice(index, 1);
            }
        }
    }
}
</script>

<style lang="scss" scoped>
.pack_history {
    width: 100%;
    height: 100%;
    .el-aside {
        height: 100%;
        background: #545c64;
    }
    .el-main {
        .modelList {
            display: flex;
            flex-direction: row;
            justify-content: flex-start;
            flex-wrap: wrap;
            padding-left: 45px;
            .model {
                list-style-type: none;
                width: 320px;
                min-height: 301px;
                transition: .2s;
                margin: 40px 34px 0 0;
                display: inline-block;
                vertical-align: middle;
                border-radius: 5px;
                box-shadow: 0 0 10px rgba(0, 0, 0, .2);
                &:hover {
                    box-shadow: 0 0 50px rgba(0, 0, 0, .2);
                    cursor: pointer;
                }
                .image {
                    background: url("../../assets/demo.jpg");
                    display: block;
                    width: 320px;
                    height: 200px;
                    border-radius: 5px 5px 0 0;
                    box-shadow: 0 0 3px rgba(0, 0, 0, .2);
                    background-repeat: no-repeat;
                    background-position: center bottom;
                    background-size: cover;
                }
                .content {
                    min-height: 145px;
                    padding: 15px;
                    h1 {
                        line-height: 30px;
                        font-size: 16px;
                        color: #2f394d;
                        font-weight: normal;
                        margin: 0;
                        white-space: nowrap;
                        overflow: hidden;
                        text-overflow: ellipsis;
                        font-size: 20px;
                    }
                    p {
                        color: #6c7685;
                        font-size: 15px;
                        margin: 7px 0 0;
                    }
                }
                .user {
                    padding: 15px;
                    display: flex;
                    justify-content: space-between;
                    color: #808080;
                    font-size: 17px;
                    .date {
                        text-align: right;
                    }
                }
            }
        }
    }
}
</style>
<style>
   html {
    height: 100%;
   }
</style>
