<template>
    <div class="online_pack">
        <el-container>
            <el-aside width="250px">
                <el-menu
                    default-active="1"
                    class="el-menu-vertical-demo"
                    @select="handleSelect"
                    background-color="#3b3b3b"
                    text-color="#e3e6e8"
                    active-text-color="#409eff">
                    <el-menu-item index="1">
                        <i class="el-icon-s-release" :class="{'active':isActive==1}"></i>
                        <span>在线打包</span>
                    </el-menu-item>
                    <el-menu-item index="2">
                        <i class="el-icon-menu" :class="{'active':isActive==2}"></i>
                        <span>打包记录</span>
                    </el-menu-item>
                </el-menu>
            </el-aside>
            <el-main>
                <router-view></router-view>
            </el-main>
        </el-container>
    </div>
</template>

<script>
export default {
    name: 'onlinePack',
    data () {
        return {
            isActive: 1
        }
    },
    mounted () {
        this.$store.commit('setIndex', 2);
    },
    methods: {
        handleSelect (index) {
            switch (index) {
                case '1':
                    this.isActive = 1;
                    this.$router.push('packList');
                    break;
                case '2':
                    this.isActive = 2;
                    this.$router.push('packHistory');
                    break;
                default: 
                    break;
            }
        }
    }
}
</script>

<style lang="scss" scoped>
$font-color: #e3e6e8;
$font-color-white: #fff;
$border-color: #444;
$background-color-black: #333;
$background-color-gray: #3b3b3b;
.online_pack {
    width: 100%;
    height: 100%;
    .el-container {
        height: 100%;
        .el-aside {
            height: 100%;
            height: 100%;
            border-right: 1px solid $border-color;
            padding-top: 20px;
            background: $background-color-gray;
            position: fixed;
            .el-menu-vertical-demo {
                border-right: none;
                .el-menu-item {
                    &:hover {
                        background-color: $border-color !important;
                        color: #409EFF;
                    }
                }
            }
        }
        .el-main {
            margin-left: 250px;
            overflow: inherit;
            padding: 0;
        }
    }
}
</style>

