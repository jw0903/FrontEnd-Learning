<template>
    <div class="pack_list">
        <el-container>
            <el-main>
                <el-steps :active="tabIndex" simple>
                    <el-step title="打包模板" icon="el-icon-edit"></el-step>
                    <el-step title="上传前端包" icon="el-icon-upload"></el-step>
                    <el-step title="修改app" icon="el-icon-picture"></el-step>
                    <el-step title="打包" icon="el-icon-picture"></el-step>
                </el-steps>                
                <div class="modelList" v-if="tabIndex === 0" v-loading="loading" element-loading-text="拼命加载中">
                    <li v-for="(item, index) in modelList" :key="index" class="model" @click="choseModel(item)">
                        <label :class="{active:item.isActive}"><i class="el-icon-check"></i></label>
                        <img :src="'pack'+item.tp_icon" alt="">
                        <div class="content">
                            <h1>{{item.tp_name}}</h1>
                            <p><i class="el-icon-document"></i> {{item.tp_description}}</p>
                        </div>
                    </li>
                </div>
                <div class="uploadList" v-if="tabIndex === 1" v-loading="loading" element-loading-text="拼命加载中">
                    <li v-for="(item, index) in appList" :key="index">
                        <el-upload
                            :class="['avatar-uploader', {upload: item.isUpload}]"
                            action="string"
                            :http-request="handleUpload"
                            drag
                            :on-progress="(event, file, fileList) => uploadProgress(event, file, fileList, index)"
                            :show-file-list="false"
                            :on-error="handleFileError"
                            :on-success="(response, file) => handleSuccess(response, file, index)"
                            :before-upload="beforeZipUpload">
                            <div v-if="item.isUpload && !item.uploading" class="upload-success">
                                <i class="el-icon-folder-checked avatar-upload-success"></i>
                                <span>已上传</span>
                            </div>
                            <div v-if="!item.isUpload && !item.uploading" class="upload-before">
                                <span>上传{{item.label}}包</span>
                                <i class="el-icon-upload avatar-uploader-icon"></i>
                                <div class="el-upload__text">将文件拖到此处，或<em>点击上传</em>({{item.suffix}})</div>
                            </div>
                            <el-progress type="circle" v-if="item.uploading" :percentage="item.percent" style="position:relative;top:45px;"></el-progress>
                            <!-- <img v-if="imageUrl" :src="imageUrl" class="avatar"> -->
                        </el-upload>
                    </li>
                </div>
                <div class="modList" v-if="tabIndex === 2" v-loading="loading" element-loading-text="拼命加载中">

<!--                  <li v-for="(item, index) in modList" :key="index" :class="['mod']">
                        <div>
                            <span class="title">{{item.label}}</span>
                            <el-input
                                type="mini"
                                :placeholder="item.label"
                                v-model="modUploadList[index]"
                                clearable
                            >
                            </el-input>
                            <span class="tips">样例: {{item.example}}</span>
                        </div>
                    </li> -->
                    <el-table
                        :data="modList"
                        style="width: 100%; margin-top: 30px;">
                        <el-table-column
                            prop="label"
                            width="250">
                        </el-table-column>
                        <el-table-column>
                            <template slot-scope="scope">
                                <el-input v-model="modUploadList[scope.$index]" :placeholder="scope.row.label"> </el-input>
                            </template>
                        </el-table-column>
                        <el-table-column>
                            <template slot-scope="scope">
                                <span>样例：{{scope.row.example}}</span>    
                            </template>
                        </el-table-column>
                    </el-table>
                    <i class="split-line"></i>
                    <li v-for="(item, index) in cpList" :key="item.label" class="upload-mod">
                        <el-upload
                            :class="['avatar-uploader', {upload: item.isUpload}]"
                            action="string"
                            :http-request="handleUpload"
                            drag
                            :on-progress="(event, file, fileList) => uploadIconProgress(event, file, fileList, index)"
                            :show-file-list="false"
                            :on-error="handleFileError"
                            :on-success="(response, file)=>handleIconSuccess(response, file, index)"
                            :before-upload="beforeAvatarUpload">
                            <div v-if="item.isUpload && !item.uploading" class="upload-success">
                                <i class="el-icon-folder-checked avatar-upload-success"></i>
                                <span>已上传</span>
                            </div>
                            <div v-if="!item.isUpload && !item.uploading" class="upload-before">
                                <span>上传{{item.label}}</span>
                                <i class="el-icon-upload avatar-uploader-icon"></i>
                                <div class="el-upload__text">将文件拖到此处，或<em>点击上传</em>({{item.suffix}})</div>
                            </div>
                            <el-progress type="circle" v-if="item.uploading" :percentage="item.percent" style="position:relative;top:45px;"></el-progress>
                        </el-upload>
                    </li>
                </div>
                <div class="build" id="build" v-if="tabIndex === 3" v-loading="loading" element-loading-text="拼命加载中">
                    <pre v-html="log"></pre>
                    <i class="el-icon-loading" v-if="buildFlag === 'building'"></i>
                </div>
                <div class="footer">
                    <el-button type="primary" :disabled="tabIndex === 0 || (buildFlag !== 'success' && tabIndex === 3)" @click="prevTab(tabIndex)">{{prevTip}}</el-button>
                    <el-button type="primary" :disabled="buildFlag !== 'success' && tabIndex === 3" @click="nextTab(tabIndex)">{{nextTip}}</el-button>
                </div>
            </el-main>
        </el-container>
    </div>
</template>

<script>
import api from "../../api/api.js";
import axios from 'axios';
export default {
    name: 'packList',
    data () {
        return {
            loading: true,
            imageUrl: '',
            modelList: [],
            tabIndex: 0,
            currModel: '',
            cpList: [],
            appList: [],
            modList: [],
            submitObj: {},
            cpUpload: {},
            appUpload: {},
            modUpload: {},
            modUploadList: [],
            nextTip: '下一步',
            prevTip: '上一步',
            buildFlag: 'before',
            log: '',
            taskId: '',
            offset: 1,
            interval: '',
            scrollTag: '',
        }
    },
    mounted () {
        this.getModel();
    },
    methods: {
        /**
         * 获取模版列表
         */
        getModel () {
            this.$ajax({
                method: 'get',
                url: api.modelList,
                params: {
                    pageNum: 20,
                    pageIndex: 1
                }
            }).then((res) => {
                let list = res.data.data.list;
                list.forEach((item) => {
                    item.isActive = false;
                })
                this.modelList = list;
                this.loading = false;
            }).catch((err) => {
                this.loading = false;
                this.$message({
                    showClose: true,
                    type: 'error',
                    message: err
                })
                console.log(err);
            })
        },
        /**
         * 获取模版可修改的文件类型
         */
        getResType (tp_id) {
            this.loading = true;
            this.$ajax({
                methos: 'get',
                url: api.resType,
                params: {
                    tp_id: tp_id
                }
            }).then((res) => {
                if (res.data.code == '0') {
                    if (res.data.data.length === 0) return;
                    res.data.data.forEach(item => {
                        if (item.label === 'cp') {
                            this.cpList = item.children;
                            this.cpList.forEach((item) => {
                                item.isUpload = false;
                                item.uploading = false;
                                item.percent = 0;
                            })
                        } else if (item.label === 'mod') {
                            this.modList = item.children;
                            this.modList.forEach((item) => {
                                this.modUpload[item.value] = "";
                            })
                        } else {
                            this.appList = item.children;
                            this.appList.forEach((item) => {
                                item.percent = 0;
                                item.uploading = false;
                                item.isUpload = false;
                            })
                        }
                    })
                }
                this.loading = false;
            }).catch((err) => {
                this.loading = false;
                this.$message({
                    showClose: true,
                    type: 'error',
                    message: err
                })
                console.log(err);
            });
        },
        uploadProgress (event, file, fileList, index) {
            let obj = this.appList[index];
            obj.uploading = event.percent !== 100;
            obj.percent = event.percent;
            this.$set(this.appList, index, obj);
        },
        uploadIconProgress (event, file, fileList, index) {
            let obj = this.cpList[index];
            obj.uploading = event.percent !== 100;
            obj.percent = event.percent;
            this.$set(this.cpList, index, obj);
        },
        /**
         * *.zip包文件上传
         */
        handleUpload (param) {
            const formData = new FormData()
            formData.append('file', param.file)
            this.$ajax({
                method: 'post',
                url: api.uploadFile,
                data: formData,
                onUploadProgress: (progressEvent) => {
                    let percent=(progressEvent.loaded / progressEvent.total * 100) | 0;
                    param.onProgress({percent, param});
                }
            }).then((res) => {
                param.onSuccess(res);
            }).catch(err => {
                console.log(err);
            })
        },
        /**
         * *.png/jpeg等图标上传
         */
        handleUploadIcon (param) {
            const formData = new FormData()
            formData.append('file', param.file)
            this.$ajax({
                method: 'post',
                url: api.uploadFile,
                data: formData,
                onUploadProgress: progressEvent => {
                    console.log(progressEvent);
                    let percent=(progressEvent.loaded / progressEvent.total * 100) | 0;
                    param.onProgress({percent:percent});
                }
            }).then((res) => {
                param.onSuccess();
            }).catch(err => {
                console.log(err);
            })
        },
        handleFileError (err, file) {
            alert(err);
        },
        /**
         * zip文件上传成功回调方法
         */
        handleSuccess (res, file, index) {
            this.appUpload[this.appList[index].value] = res.data.data[0].id;
            let obj = this.appList[index];
            obj.isUpload = true;
            this.$set(this.appList, index, obj);
            this.appList[index].isUpload = true;
        },
        /**
         * 图标文件上传文件回调方法
         */
        handleIconSuccess (res, file, index) {
            this.cpUpload[this.cpList[index].value] = res.data.data[0].id;
            let obj = this.cpList[index];
            obj.isUpload = true;
            this.$set(this.cpList, index, obj);
            this.cpList[index].isUpload = true;
        },
        /**
         * zip/图标文件上传格式限制
         */
        beforeZipUpload (file) {
            const fileType = file.name.substr(file.name.lastIndexOf('.')+1);
            if (fileType.toLowerCase() !== 'zip') {
                this.$message({
                    showClose: true,
                    type: 'warning',
                    message: '请上传zip格式包'
                })
                return false;
            }
        },
        beforeAvatarUpload (file) {
            const fileType = file.name.substr(file.name.lastIndexOf('.') + 1);
            if (fileType.toLowerCase() === 'png' || fileType.toLowerCase() === 'jpg' || fileType.toLowerCase() === 'jpeg') {
            } else {
                this.$message({
                    showClose: true,
                    type: 'warning',
                    message: '请上传png/jpg/jpeg格式文件'
                })
                return false;
            }
        },
        choseModel (item) {
            if (item.isActive) {
                item.isActive = false;
                this.currModel = '';
                return;
            } else {
                this.modelList.forEach(i => {
                    if (i.tp_id !== item.tp_id) {
                        i.isActive = false;
                    }
                })
                item.isActive = true;
                this.currModel = item;
            }
        },
        /**
         * 提交打包
         */
        pack () {
            this.submitObj.cp = this.cpUpload;
            this.submitObj.h5 = this.appUpload;
            let index = 0;
            for(let i in this.modUpload) {
                this.modUpload[i] = this.modUploadList[index] ? this.modUploadList[index] : '';
                index++;
            }
            this.submitObj.mod = this.modUpload;
            this.$ajax({
                method: 'post',
                url: api.build + `/${this.currModel.tp_id}`,
                data: this.submitObj
            }).then(res => {
                console.log(res);
                this.taskId = res.data.data.task_id;
                this.interval = setInterval(()=>{
                    this.Log()
                },2000);
                this.Log();
            }).catch(err => {
                console.log(err);
            })
        },
        Log ()　{
            this.$ajax({
                method: 'post',
                url: api.getLog.replace(/replaceHolder/, this.taskId),
                params: {
                    offset: this.offset
                }
            }).then(res => {
                if (res.data.code == 0) {
                    let data = res.data.data;
                    
                    this.offset = data.offset;
                    if ((document.documentElement.scrollTop === 0 && this.log == '') || document.documentElement.scrollTop == document.documentElement.scrollHeight - document.documentElement.offsetHeight) {
                        this.log += data.content;
                        this.$nextTick(function() {
                            document.documentElement.scrollTop = document.documentElement.scrollHeight - document.documentElement.offsetHeight
                        })
                    } else {
                        this.log += data.content;
                    }
                    this.buildFlag = 'building';
                    if (data.content.indexOf('Finished: Success') !== -1 || data.content.indexOf('Finished: Error') !== -1) {
                        clearInterval(this.interval);
                        this.buildFlag = data.content.indexOf('Finished: Success') !== -1 ? 'success' : 'fail';
                    }
                }
            }).catch(err => {
                console.log(err);
            })
        },
        /**
         * 上一步、下一步
         */
        nextTab (index) {
            switch (index) {
                case 0:
                    if (!this.currModel) {
                        this.$message({
                            showClose: true,
                            message: "请选择一个模板",
                            type: 'warning'
                        });
                    } else {
                        this.tabIndex = index + 1;
                        this.getResType(this.currModel.tp_id);
                    }
                    break;
                case 1: 
                    this.tabIndex++;
                    break;
                case 2: 
                    this.tabIndex++;
                    this.prevTip = '提交成果物';
                    this.nextTip = '下载安装包';
                    this.pack();

                    break;
                case 3: 
                    this.downloadApk();
                    break;
                default:
                    break;
            }
        },
        prevTab (index) {
            if (index !== 3){
                this.tabIndex = index - 1;
            } else {
                this.submitApk();
            }
        },
        downloadApk () {
            this.$message({
                type: 'success',
                message: '下载APK',
            })
        },
        submitApk () {
            this.$message({
                type: 'success',
                message: '提交成果物'
            })
        },
        destroyed () {
            // clearInterval(this.interval);
        },
    }
}
</script>

<style lang="scss" scoped>
$font-color: #e3e6e8;
$font-color-blue: rgb(64, 158, 255);
$border-color: #444;
$background-color-black: #333;
$background-color-gray: #3b3b3b;
.pack_list {
    width: calc(100% - 250px);
    height: 100%;
    position: absolute;
    left: 250px;
    .el-container {
        height: 100%;
    }
    .el-main {
        height: 100%;
        overflow: inherit;
        .modelList, .modList, .uploadList, .build{
            min-height: 80%;
            background: $background-color-black;
            padding: 0 40px;
            color: $font-color;
            pre {
                line-height: 20px;
                word-break: break-all;
                white-space: pre-line;
            }
        }
        .modelList {
            display: flex;
            flex-direction: row;
            justify-content: flex-start;
            flex-wrap: wrap;
            padding-left: 45px;
            .model {
                position: relative;
                overflow: hidden;
                list-style-type: none;
                width: 200px;
                height: 300px;
                transition: .2s;
                margin: 40px 34px 0 0;
                display: inline-block;
                vertical-align: middle;
                border-radius: 5px;
                border: 1px solid #ccc;
                label {
                    display: none;
                }
                .active {
                    background: #13ce66;
                    width: 40px;
                    height: 40px;
                    display: block;
                    position: absolute;
                    top: -20px;
                    left: 180px;
                    transform: rotate(45deg);
                    .el-icon-check {
                        position: relative;
                        top: 22px;
                        right: -10px;
                        transform: rotate(-45deg);
                        color: #fff;
                    }
                }
                img {
                    width: 110px;
                    height: 110px;
                    margin: 31px 44px 0px;
                }
                .image {
                    background: url("../../assets/demo.jpg");
                    display: block;
                    width: 320px;
                    height: 200px;
                    border-radius: 5px 5px 0 0;
                    box-shadow: 0 0 3px rgba(0, 0, 0, .2);
                    background-repeat: no-repeat;
                    background-position: center bottom;
                    background-size: cover;
                }
                .content {
                    min-height: 145px;
                    padding: 15px;
                    h1 {
                        line-height: 30px;
                        font-size: 16px;
                        color: #e3e6e8;
                        font-weight: normal;
                        margin: 0;
                        white-space: nowrap;
                        overflow: hidden;
                        text-overflow: ellipsis;
                        font-size: 20px;
                        font-weight: 800;
                        text-align: center;
                    }
                    p {
                        color: #6c7685;
                        font-size: 15px;
                        word-break: break-all;
                        overflow: hidden;
                        text-overflow: clip;
                        width: 100%;
                        height: 60px;
                        display: -webkit-box;
                        -webkit-box-orient: vertical;
                        -webkit-line-clamp: 3;
                    }
                }
            }
        }
        .uploadList, .modList{
            li {
                display: inline-block;
                margin: 10px;
                list-style-type: none;
                .el-upload-dragger {    
                    .upload-before {    
                        span {
                            font-size: 15px;
                            position: relative;
                            top: 15px;
                            color: #aaa;
                        }
                    }
                    .upload-success {
                        span {
                            position: relative;
                            top: 120px;
                            color: #409EFF;
                        }
                    }
                }
            }
        }
        .uploadList {
            padding-top: 30px;
        }
        .modList {
            li {
                height: 220px;
                width: 180px;
                padding: 0 15px;
                text-align: center;
                border: 1px dashed #d9d9d9;
                border-radius: 6px;
            }
            .mod {
                &:hover {
                    border-color: #409EFF;
                }
                div {
                    height: 100%;
                    display: flex;
                    flex-direction: column;
                    justify-content: space-around;
                    padding: 20px 0px;
                    .title {
                        font-size: 15px;
                        color: #e3e6e8;
                    }
                    .tips {
                        color: #aaa;
                        font-size: 14px;
                    }
                }
            }
            .upload-mod {
                border: none;
                padding: 0;
                .el-upload-dragger {    
                    .upload-before {
                        span {
                            font-size: 15px;
                            position: relative;
                            top: 15px;
                            color: #e3e6e8;
                        }
                        .avatar-uploader-icon {
                            position: relative;
                            top: 10px;
                        }
                        .el-upload__text {
                            position: relative;
                            top: 10px;
                        }
                    }
                    .upload-success {
                        span {
                            position: relative;
                            top: 120px;
                            color: #409EFF;
                        }
                    }
                }
            }
            .split-line {
                width: 100%;
                border: 1px dashed #ddd;
                height: 1px;
                display: block;
                margin: 20px 0;
            }
        }
        .footer {
            clear: both;
            width: 100%;
            display: flex;
            justify-content: center;
            padding: 20px 0;
            margin-top: -15px;
            background: $background-color-black;
        }
    }
    .el-steps--simple {
        background-color: $background-color-gray;
        color: $font-color;
    }
    .el-main {
        padding: 0;
    }
}
</style>
<style>
.el-step__title.is-process {
    color: rgb(64, 158, 255);
}
.el-step__head.is-process {
    color: rgb(64, 158, 255);
}
.el-loading-mask {
    background-color: #3b3b3b;
}
.avatar-uploader .el-upload {
    width: 180px;
    height: 220px;
    border-radius: 6px;
    cursor: pointer;
    position: relative;
    overflow: hidden;
}
.upload .el-upload-dragger {
    border-color: #409EFF;
}
.el-upload-dragger {
    width: 180px;
    height: 220px;
    padding: 0 10px;
}
.avatar-uploader .el-upload:hover {
    border-color: #409EFF;
}
.avatar-uploader-icon {
    font-size: 28px;
    color: #8c939d;
    width: 160px;
    height: 70px;
    text-align: center;
}
.avatar-upload-success {
    color: #409EFF;
    transform: scale(4.5);
    position: relative;
    top: 70px;
    display: block;
}
/* .avatar {
width: 178px;
height: 178px;
display: block;
} */
.el-upload-dragger {
    background: #3b3b3b;
}
.el-upload-dragger .el-upload__text {
    color: #aaa;
}
.el-input__inner {
    background-color: #2c2c2c;
    border: 1px solid #aaa;
    color: #e3e6e8;
    outline: none;
}
.el-input__inner:focus {
    outline: none;
}
.modList .el-table--fit {
    border: 1px solid #444;
}
.modList .modList .el-table thead {
    color: #fff;
}
.modList .el-table thead tr {
    background-color: #3b3b3b;
}
.modList .el-table tbody tr {
    background-color: #3b3b3b;
}
.modList .el-table th, .modList .el-table tr {
    background-color: #3b3b3b;
}
.modList .el-table td, .modList .el-table th.is-leaf {
    border-bottom: 1px solid #444;
}
.modList .el-table::before {
    background-color: #444;
}
.modList .el-table--enable-row-hover .modList .el-table__body tr:hover>td {
    background-color: #333;
}
.modList .el-table{
    color: #e3e6e8;
}
.modList .el-table__header-wrapper {
    display: none;
}
.el-input__inner::-webkit-input-placeholder {
    color: #666;
}
.modList .el-table__empty-block {
    background-color: #333;
    color: #fff;
}
</style>
