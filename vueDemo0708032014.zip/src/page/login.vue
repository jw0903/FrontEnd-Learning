<template>
    <div class="case">
        <div class="content">
            <h1>密码登录</h1>
            <div class="form-item">
                <p class="tips" :class="tipsShow ? 'tipsShow' : ''">
                    <i class="el-icon-circle-close"></i>
                    {{tips}}
                </p>
                <el-input v-model="userName" placeholder="请输入用户名" @blur="slideVerifyCode(true)"></el-input>
                <el-input v-model="pwd" placeholder="请输入密码" type="password" @keyup.enter.native="login" show-password></el-input>
            </div>
            <div class="form-item bottom-item">
                <drag-verify v-if="isverifyCodeIdShow" ref="dragVerify" class="dragVerify"></drag-verify>
                <el-checkbox v-model="rememberUser" class="remember-user" @change="isRemberUser">记住用户名</el-checkbox>
                <div class="forget-pwd" @click="forgetPwd">忘记密码？</div>
            </div>
            <div class="login-btn">
                <el-button type="primary" @click="login" :loading="btnLoading">登录</el-button>
            </div>
        </div>
        <div class="copyright">
            <p>© 2019 杭州海康威视系统技术有限公司 | 浙ICP备17026868号-3 </p>
        </div>
    </div>
</template>

<script>
import api from '../api/api.js'
import dragVerify from '../components/dragVerify'
import { pwdHashEncryptVerify } from '@/utils/pwd'
import { setUserName } from '@/utils/token'
export default {
    name: 'personal',
    components: {
        dragVerify
    },
    data () {
        return {
            userName: localStorage.getItem("userName"),
            pwd: '',
            tips: '',
            productCode: 'hatom',
            tipsShow: false,
            rememberUser: '',
            btnLoading: false,
            isverifyCodeIdShow: false,
            verifyCodeId: '',
            redirect: ''
        }
    },
    methods: {
        // 看张全文那边具体格式
        slideVerifyCode (clearMsg) {
            if (this.userName) {
                this.$ajax({
                    method: 'post',
                    url: api.slideVerifyCode,
                    data: {
                        productCode: this.productCode,
                        name: this.userName
                    }
                }).then((res) => {
                    if (res.data.code == '0') {
                        if (res.data.data) {
                            this.isverifyCodeIdShow = true
                            this.verifyCodeId = res.data.data.verifyCodeId
                            this.$nextTick(() => {
                                this.isverifyCodeIdShow && this.$refs.dragVerify.reset()
                            })
                        } else {
                            this.isverifyCodeIdShow = false
                            // this.tipsShow = false
                            this.verifyCodeId = ''
                            if (clearMsg) {
                                this.tips = ''
                            }
                        }
                    } else {
                        this.tipsShow = true
                        this.tips = res.data.msg
                        this.isverifyCodeIdShow && this.$refs.dragVerify.reset()
                    }
                }).catch((err) => {
                    console.log(err)
                })
            }
        },
        // 获取挑战码
        getChallengeCode () {
            this.btnLoading = true
            return new Promise ((resolve, reject) => {
                this.$ajax({
                    method: 'post',
                    url: api.getChallengeCode,
                    data: {
                        productCode: this.productCode,
                        name: this.userName,
                        type: 1
                    }
                }).then((res) => {
                    resolve(res.data)
                }).catch((err) => {
                    reject(err)
                })
            })
        },
        login () {
            if (!this.userName) {
                this.tips = '请输入用户名'
                this.tipsShow = true
                return
            }
            if (!this.pwd) {
                this.tips = '请输入密码'
                this.tipsShow = true
                return
            }
            if (this.verifyCodeId && !this.$refs.dragVerify.confirmSuccess) {
                this.tips = '请先进行滑动验证'
                this.tipsShow = true
                return
            }
            this.tips = ''
            this.tipsShow = false
            this.btnLoading = true

            this.getChallengeCode().then((data) => {
                let userInfo
                if (data.code == '0') {
                    userInfo = {
                        'name': this.userName,
                        'password': pwdHashEncryptVerify(this.pwd.trim(), data.data.salt, data.data.vCode),
                        'verifyCodeId': this.verifyCodeId,
                        'codeId': data.data.codeId,
                        'type': 1,
                        'productCode': this.productCode,
                        "expired": 30,
                    }
                    this.$store.dispatch('Login', userInfo).then(res => {
                        if (res.data.code != '0' && res.data.code != '1018') {
                            this.btnLoading = false
                            this.tipsShow = true
                            this.tips = res.data.msg
                            this.slideVerifyCode()
                        } else {
                            this.tips = ''
                            // if (!res.data.data.pwdStatus) {
                            //     this.$router.push({ path: '/modifyPwd' })  // 强制修改密码？
                            // } else {
                            //     if (this.rememberUser) {
                            //         localStorage.setItem('userName', this.userName)
                            //     }
                            //     this.$router.push({ path: this.redirect || '/devGuide' })
                            // }
                            if (this.rememberUser) {
                                localStorage.setItem('userName', this.userName)
                            }
                            if (res.data.code == '1018') {
                                let params = {
                                    pwd: pwdHashEncryptVerify(this.pwd.trim(), data.data.salt, data.data.vCode),
                                    forceModifPwd: true
                                };
                                this.$router.push({
                                     name: 'modifyPassword',
                                     params: params
                                })
                            } else {
                                this.$router.push({ path: this.redirect || '/' })
                            }
                        }
                    }).catch(err => {
                        console.log(err)
                    })
                } else {
                    this.btnLoading = false
                    this.tipsShow = true
                    this.tips = data.msg
                }
            }).catch(err => {
                this.btnLoading = false
                console.log(err)
            })
        },
        // 记住用户名
        isRemberUser () {
            if (!this.rememberUser) {
                localStorage.removeItem('userName')
            }
        },
        forgetPwd () {
            // 跳转到忘记密码页面
            this.$router.push({ path: '/forgetPwd' })
        }
    },
    watch: {
        $route: {
            handler: function (route) {
                if (route.query){
                    this.redirect = route.query.redirect;
                }
            },
            immediate: true
        }
    }
}
</script>

<style lang="scss" scoped>
    .case {
        // display: flex;
        // justify-content: center;
        // align-items: center;
        padding-top: 100px;
        width: 1200px;
        margin: 0 auto;
        background: url(../assets/login.png) no-repeat 550px 250px;
        // background-size:cover;
        // background-attachment: fixed;
        .content {
            width: 400px;
            height: 400px;
            padding: 20px 40px 0;
            margin-top: 150px;
            color: #fff;
            background: #3b3b3b;
            border-radius: 2px;
            h1 {
                font-size: 20px;
                margin: 0;
                color: #ccc;
            }
            .form-item {
                .el-icon-circle-close {
                    color: #f56c6c;
                }
                .el-input {
                    margin-top: 24px;
                }
                .tips {
                    text-align: right;
                    color: #ccc;
                    opacity: 0;
                    font-size: 14px;
                    margin: 0;
                }
                .tipsShow {
                    opacity: 1;
                }
                .remember-user {
                    color: #999;
                }
                .forget-pwd {
                    float: right;
                    color: #999;
                    font-size: 14px;
                    cursor: pointer;
                }
                .dragVerify {
                    margin-bottom: 20px;
                }
            }
            .bottom-item {
                margin-top: 30px;
            }
            .login-btn {
                margin-top: 30px;
                text-align: center;
                button {
                    width: 100%;
                    font-size: 16px;
 //                   background-color: #666;
                    border: 1px solid #666;
                }
            }
        }
        .copyright {
            position: fixed;
            bottom: 0;
            height: 56px;
            background: #3b3b3b;
            left: 0;
            right: 0;
            p {
                font-size: 16px;
                text-align: center;
                color: #e3e6e8;
            }
        }
    }
</style>
<style>
    .case .form-item .el-input__inner {
        /* padding: 13px 10px;
        font-size: 16px;
        outline: none;
        background: transparent;
        border: 0px;
        border-bottom: 1px solid #fff;
        letter-spacing: 1.6px;
        color: #fff;

        margin-top: 24px; */
        border-radius: 0px;
        color: #e3e6e8;
        border: 1px solid #666;
        background: #333;
    }
    .case .form-item .el-input__inner::-webkit-input-placeholder {
        color: #ccc;
    }
</style>
