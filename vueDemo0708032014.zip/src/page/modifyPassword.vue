<template>
    <div class="main">
        <el-row type="flex" justify="center" class="main-panel">
            <el-col :span="24" class="panel-warp">
                <header>
                    修改密码
                    <span class="h-icon-circle_notice icon"></span>
                    <span v-if="!pwdExpired" class="sub-title">为保证账户安全，首次登录需<span>重新修改密码</span>后方可使用。</span>
                    <span v-else class="sub-title">为保证账户安全，<span>每隔90天</span>需要修改一次密码。</span>
                </header>
                <div class="panel-inner">
                    <!-- 新密码输入提示 -->
                    <el-popover  popper-class="newpwd-tip" ref="popover1" placement="top" width="215" trigger="manual" :value="showNewPwdTip">
                        <div  :class="{'dissatisfy': pwdLackOfLen }"><i>{{ pwdLackOfLen ? '●' : '✔'}}</i>密码长度为8位~20位</div>
                        <div  :class="{'dissatisfy': pwdLackOfType }"><i>{{ pwdLackOfType ? '●' : '✔'}}</i>至少包含以下2种字符：大小写字母、数字、特殊字符</div>
                    </el-popover>
                    <!-- <el-popover popper-class="newpwd-tip" ref="popover2" placement="top" width="215" trigger="manual" :value="showNamePwdTip">
                        <div class='dissatisfy'><i>●</i>密码不能是用户名或者用户名的倒写</div>
                    </el-popover> -->
                    <el-form :model="ruleForm" ref="pwdForm" :rules="rules" >
                        <el-form-item  prop="newPassword" :class="{'margin-bottom': showPwdStrenth}">
                            <el-input :type="isShowPwd1 ? 'text' : 'password'" placeholder="请输入新密码"  v-model="ruleForm.newPassword"
                                      @focus="checkNewPwd" @change="checkNewPwd" v-popover:popover1 v-popover:popover2
                                      show-password></el-input>
                            <password-rank  v-show="showPwdStrenth" :status="newPwdStrenth" ></password-rank>
                        </el-form-item>
                        <el-form-item  prop="newConfirm" >
                            <el-input :type="isShowPwd2 ? 'text' : 'password'" v-model="ruleForm.newConfirm" placeholder="请再次输入新密码" show-password></el-input>
                        </el-form-item>
                        <el-form-item>
                            <el-button type="primary" icon="el-icon-up" class="full-btn " :loading="isBtnLoading" @click="submitModify('pwdForm')">{{btnText}}</el-button>
                        </el-form-item>
                    </el-form>
                </div>

            </el-col >
        </el-row>
    </div>
</template>
<script>
import passwordRank from "@/components/passwordRank";
import { uuid, getPwdRank, pwdHashEncryptVerify, pwdHashEncryptSave, pwdAesEncrypt } from "@/utils";
import store from "@/store/store";
import api from '@/api/api'
export default {
    name: "modifyPassword",
    data () {
        let validateNewPass = (rule, value, callback) => {
            if (value.match(/[^\x00-\xff]/)){// 只能包含数字字母特殊字符
                callback(new Error("密码只能包含数字字母特殊字符"));
            } else {
                this.getNewPwdRank(value);
                callback();
            }
        };
        let validateNewCompareOld = (rule, value, callback) => {
            if (value === this.oldPwd){
                callback(new Error("新密码不能与原密码一样"));
            } else {
                callback();
            }
        };
        let validateConfirmPass = (rule, value, callback) => {
            if (value !== this.ruleForm.newPassword) {
                callback(new Error("两次输入密码不一致"));
            } else {
                callback();
            }
        };
        return {
            userName: this.$store.getters.userName || "",
            isBtnLoading: false,
            isShowPwd1: false,
            isShowPwd2: false,
            ruleForm: {
                newPassword: "",
                newConfirm: ""
            },
            rules: {
                newPassword: [
                    { required: true, message: "请输入新密码", trigger: "change+blur" },
                    { validator: validateNewPass, trigger: "change+blur" },
                    { validator: validateNewCompareOld, trigger: "blur" }
                ],
                newConfirm: [
                    { required: true, message: "请再次输入密码", trigger: "change+blur" },
                    { validator: validateConfirmPass, trigger: "change+blur" }
                ]
            },
            newPwdStrenth: 0, // 密码强度验证控件状态，0:危险 1:弱 2:中 3:强
            pwdLackOfLen: false,
            pwdOverOfType: false, // 字符种类超过
            pwdLackOfType: false,
            pwdExpired: this.$route.params.pwdExpired,
            oldPwd: this.$route.params.pwd
        };
    },
    components: {
        passwordRank
    },
    computed: {
        btnText () {
            if (this.isBtnLoading) return "修改密码中...";
            return "修改密码";
        },
        showNewPwdTip () { // 密码规则不符合
            return (this.pwdLackOfLen || this.pwdLackOfType) && !this.showNamePwdTip;
        },
        showPwdStrenth (){
            return this.ruleForm.newPassword && !this.pwdOverOfType;
        },
        showNamePwdTip (){ // 密码和用户名相似
            let {userName} = this;
            let {newPassword} = this.ruleForm;
            return false || newPassword === userName || newPassword === userName.split("").reverse().join("");
        }
    },
    methods: {
        /**
         * 获取密码强度
         */
        getNewPwdRank (pwd) {
            let { userName } = this;
            this.newPwdStrenth = getPwdRank(pwd, userName);
        },
        /**
         * 分条检验密码要求
         */
        checkNewPwd () {
            let pwd = this.ruleForm.newPassword;
            this.pwdLackOfLen = pwd.length < 8 || pwd.length > 20;
            // 字符种类校验
            this.pwdOverOfType = pwd.match(/[^\x00-\xff]/) ? true : false;
            let iRank = 0;
            pwd.match(/[a-z]/g) && iRank++;
            pwd.match(/[A-Z]/g) && iRank++;
            pwd.match(/[0-9]/g) && iRank++;
            pwd.match(/[^a-zA-Z0-9]/g) && iRank++;
            this.pwdLackOfType = iRank < 2 ? true : false;
        },

        getChallengeCode () {
            let { userName } = this;
            return new Promise((resolve, reject) => {
                this.$ajax({
                    method: "post",
                    url: api.getChallengeCode,
                    data: {
                        name: 'lin',
                        productCode: "hatom",
                        type: 1
                    }
                }).then((res) => {
                    if (res.data.code == "0" && res.data.data){
                        resolve(res.data.data);
                    }
                }).catch((err) => {
                    reject(err);
                    console.log(err);
                });
            });
        },
        /**
         * 提交密码修改
         * @param formName
         */
        submitModify (formName) {
            let {userName, showNewPwdTip, showNamePwdTip} = this;
            let { password, newPassword } = this.ruleForm;
            let salt = uuid();
            this.$refs[formName].validate((valid) => {
                if (!valid) {
                    return false;
                }
                if (showNewPwdTip || showNamePwdTip){
                    return this.$message({ message: "请输入符合规则的密码", type: "warning" });
                }
                this.getChallengeCode().then((data) => {
                    this.isBtnLoading = true;
                    this.$ajax({
                        method: "post",
                        url: api.modPwd,
                        data: {
                            salt: salt,
                            codeId: data.codeId,
                            oldPwd: pwdHashEncryptVerify(this.oldPwd, data.salt, data.vCode),
                            newPwd: pwdAesEncrypt(pwdHashEncryptSave(newPassword.trim(), data.salt), data.vCode, salt)
                        }
                    }).then((res) => {
                        this.isBtnLoading = false;
                        if (res.data.code === "0") {
                            // 登出平台，要求重新登录
                            this.$store.dispatch("LogOut").then(() => {
                                this.$router.push("/login");
                                this.$message.success("密码修改成功,请重新登录");
                            });
                        } else {
                            this.$message({ type: "error", message: "密码修改失败" });
                        }
                    }).catch((err) => {
                        // TODO
                        // console.log("error");根据后台返回错误内容展示
                    });
                });

            });
        }

    },
    beforeRouteEnter: function (to, from, next){
        if (to.params.forceModifPwd){
            next();
        } else {
            // 页面刷新时登出
            store.dispatch("LogOut").then(() => {
                next("/login");
            });
        }
    },
    beforeRouteLeave (to, from, next) {
        // 点击回退按钮时登出
        // 
        store.dispatch("LogOut").then(() => {
            next();
        });
    }
};
</script>

<style rel="stylesheet/scss" lang="scss" >
    .main {
        width: 100%;
        height: 100%;
        .title {
            width: 100%;
            height: 64px;
            padding-left: 24px;
            background-color: #1B1F22;
            color: #FFFFFF;
            font-size: 24px;
            line-height: 64px;
        }
        .title:before {
            position: relative;
            display: inline-block;
            content: "";
            left: -11px;
            top: 6px;
            width: 60px;
            height: 40px;
            background: url("~@/assets/logo.png") no-repeat 0 -9px;
        }
        .main-panel {
            width: 100%;
            height: calc(100% - 96px);
            min-height: 600px;
            display: flex;
            align-items: center;
            .panel-warp {
                width: 80%;
                height: 50%;
                min-height: 410px;
                max-width: 1096px;
                max-height: 560px;
                background-color: #FFF;
                padding: 24px 32px;
                header {
                    padding-bottom: 8px;
                    color: #4D4D4D;
                    font-size: 24px;
                    border-bottom: solid 1px #DDD;
                    .icon {
                        margin-left: 40px;
                        font-size: 14px;
                        color: #FF4949;
                    }
                    .sub-title {
                        font-size: 14px;
                        color: #999;
                        span {
                            color: #FF4949;
                        }
                    }
                }
                .panel-inner {
                    width: 80%;
                    max-width: 750px;
                    margin: 96px auto 0;
                    form {
                        max-width: 420px;
                        margin: 0 auto;
                        .margin-bottom {
                            margin-bottom: 4px;
                        }
                        input {
                            font-size: 14px;
                            height: 44px;
                        }
                        .full-btn {
                            font-size: 14px;
                            font-weight: normal;
                            width: 100%;
                            max-width: 420px;
                            height: 44px;
                        }
                    }
                }
            }
        }
    }

    .el-popover.newpwd-tip {
        line-height: 20px;
        background: rgba(85, 85, 85, 0.9);
        color: #FFF;
        padding: 10px 10px 10px 30px;
        border: none;
        border-radius: 2px;
        div {
            margin-bottom: 5px;
            color: #989A9C;
        }
        .dissatisfy {
            color: #FFF;
        }
        i {
            float: left;
            margin-left: -18px;
        }
        &.el-popover[x-placement^=top] .popper__arrow {
              bottom: -11px;
              border-top-color: #666;
              &:after {
                  border-top-color: #666;
              }
          }
        &.el-popover[x-placement^=bottom] .popper__arrow {
            bottom: -11px;
            border-bottom-color: #666;
            &:after {
                border-bottom-color: #666;
            }
        }
    }
</style>
