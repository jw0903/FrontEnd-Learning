<template>
    <div class="show-case">
        <side-menu></side-menu>
        <div class="content">
            <el-scrollbar tag="div" wrapClass="vue-scrollbar">
                <router-view></router-view>
            </el-scrollbar>
        </div>
    </div>
</template>

<script>
import sideMenu from '../components/sideMenu.vue';
export default {
    name: 'showCase',
    data () {
        return {
        }
    },
    mounted () {
        this.$store.commit('setIndex', 3);
    },
    components: {
        sideMenu
    },
    watch: {
        '$route' (to, from) {
        }
    },
    methods: {
    }
}
</script>

<style lang="scss" scoped>
.show-case {
    width: 100%;
    display: flex;
    aside {
        height: 100%;
    }
    .content {
        width: calc(100% - 220px);
    }
}
</style>
