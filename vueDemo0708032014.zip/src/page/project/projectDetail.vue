<template>
	<div class="project-detail">
		<aside class="main-sidebar animated">
			<div class="title">
				<span>{{ project.name }}</span>
			</div>
			<el-menu
				style="text-align:left"
				default-active="/projectDetail/projectCode"
				class="el-menu-vertical-demo"
				:collapse-transition="true"
				background-color="#3b3b3b"
				text-color="#e3e6e8"
				active-text-color="#409eff"
				:collapse="false"
				:unique-opened="false"
				router
				>
				<el-menu-item :index="'/projectDetail/projectCode?projectId=' + projectId">
					<i class="el-icon-menu"></i>
					<span slot="title">代码</span>
				</el-menu-item>
				<el-menu-item :index="'/projectDetail/projectRelease?projectId=' + projectId">
					<i class="el-icon-menu"></i>
					<span slot="title">打包发布</span>
				</el-menu-item>
				<el-submenu index="">
					<template slot="title">
						<i class="el-icon-setting"></i>
						<span>设置</span>
					</template>
					<el-menu-item-group>
						<el-menu-item :index="'/projectDetail/projectMember?projectId=' + projectId">成员管理</el-menu-item>
						<el-menu-item :index="'/projectDetail/projectEdit?projectId=' + projectId">项目管理</el-menu-item>
					</el-menu-item-group>
				</el-submenu>
			</el-menu>
		</aside>
		<router-view></router-view>
	</div>
</template>

<script>
export default {
    name: 'project-detail',
    data () {
        return {
			project: {},
			projectId: ''
        }
	},
	created () {
		this.projectId = this.$route.query.projectId;
		console.log(this.projectId)
	},
    mounted () {
    },
    components: {
    },
    watch: {
        '$route' (to, from) {
        }
    },
    methods: {
    }
}
</script>

<style lang="scss" scoped>
.project-detail {
	aside {
		height: 100%;
		width: 250px;
		background: #3b3b3b;
		position: fixed;
		.title {
			color: #e3e6e8;
			text-align: center;
			font-size: 18px;
			padding-top: 10px;
			position: relative;
			i {
				position: absolute;
				right: 10px;
				cursor: pointer;
			}
		}
	}
}
</style>

<style>
.title~.el-menu {
	border: none;
}
</style>

