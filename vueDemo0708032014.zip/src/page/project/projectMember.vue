<template>
	<div class="project-member">
		<h1>成员（{{members.length}}）</h1>
        <hr>
        <div class="top">
            <el-select v-model="selectPro" placeholder="请选择" @change="getMembers()">
                <el-option
                    v-for="item in subPro"
                    :key="item.id"
                    :label="item.name"
                    :value="item.id">
                </el-option>
            </el-select>
            <el-button type="primary" @click="showDialog()">添加成员</el-button>
        </div>
        <div class="member-table">
            <el-table
                :data="members"
                style="width: 100%"
                border>
                <el-table-column
                    prop="userName"
                    label="用户名">
                </el-table-column>
                <el-table-column
                    label="权限">
                    <template slot-scope="scope">
                        <span v-if="scope.row.rule === '4'">
                            {{ scope.row.ruleName }}
                        </span>
                        <el-select v-else v-model="scope.row.rule" :disabled="scope.row.rule === '4'" @change="modMember(scope.row)">
                            <el-option
                                v-for="item in authOption"
                                :key="item.value"
                                :label="item.label"
                                :value="item.value"
                                :disabled="item.disabled">
                            </el-option>
                        </el-select>
                    </template>
                </el-table-column>
                <el-table-column
                    label="操作">
                    <template slot-scope="scope">
                        <el-button type="text" :disabled="scope.row.rule === '4'" size="small" @click="delMember(scope.row)">移除</el-button>
                    </template>
                </el-table-column>
            </el-table>
        </div>
        <el-dialog title="添加成员" width="600px" :visible.sync="memberFormVisible" class="member-dialog">
            <!-- <div class="tips">
                您可以从左侧分类中快速添加成员，或搜索关键字来添加成员
            </div> -->
            <el-input placeholder="输入搜索关键字" v-model="searchUser" class="search-user" @input="getUsers()"></el-input>
            <el-transfer
                v-model="selectUser"
                :titles="['成员列表', '已选中成员']"
                :props="{
                    key: 'userName',
                    value: 'userId'
                }"
                :data="userList">
            </el-transfer>
            <!-- <div class="content">
                <div class="con-left">
                    <el-input></el-input>
                </div>
                <div class="con-right"></div>
            </div> -->
            <div slot="footer" class="dialog-footer">
                <el-button @click="memberFormVisible = false">取 消</el-button>
                <el-button type="primary" @click="addMember()">确 定</el-button>
            </div>
        </el-dialog>
	</div>
</template>

<script>
import api from '@/api/api';
export default {
    name: 'project-member',
    data () {
        return {
            searchText: '',
            members: [],
            subPro: [],
            selectPro: '',
            authOption: [
                {
                    label: '只读',
                    value: '1'
                },
                {
                    label: '读写',
                    value: '2'
                },
                {
                    label: '管理员',
                    value: '3'
                }
            ],
            memberFormVisible: false,
            newMember: {
                name: '',
                subProjectId: '',
                rule: ''
            },
            searchUser: '',
            userList: [],
            selectUser: []
        }
	},
	created () {
        this.getSubPro();
	},
    mounted () {
    },
    components: {
    },
    watch: {
        '$route' (to, from) {
        }
    },
    methods: {
        filterMethod (val) {
            console.log(val);
        },
        getSubPro () {
            this.$ajax({
                method: 'get',
                url: api.getProject,
                params: {
                    projectId: this.$route.query.projectId
                }
            }).then((res) => {
                console.log(res.data);
                if (res.data.code == '0') {
                    if (res.data.data.subProjects.length !== 0) {
                        this.subPro = res.data.data.subProjects;
                        this.selectPro = this.subPro[0].id;
                        console.log(this.selectPro);
                        this.getMembers();
                    }
                }
            }).catch((err) => {
                console.log(err);
            })
        },
        getMembers () {
            this.$ajax({
                method: 'get',
                url: api.getMembers + `/${this.selectPro}`
            }).then((res) => {
                if (res.data.code == '0') {
                    if (res.data.data.length != 0) {
                        this.members = res.data.data;
                        this.members.forEach((item) => {
                            switch (item.rule) {
                                case '3':
                                    item.ruleName = '管理员';
                                    break;
                                case '1':
                                    item.ruleName = '只读';
                                    break;
                                case '2':
                                    item.ruleName = '读写';
                                    break;
                                case '4':
                                    item.ruleName = '创建者';
                                    break;
                                default:
                                    break;
                            }
                        })
                    }
                }
            }).catch((err) => {
                console.log(err);
            })
        },
        showDialog () {
            this.getUsers();
            this.selectUser = [];
            this.memberFormVisible = true;
        },
        delMember (member) {
            console.log(member);
            this.$ajax({
                method: 'post',
                url: api.delMember,
                data: {
                    "userId": member.userId,
                    "subProjectId": member.subProjectId
                }
            }).then((res) => {
                console.log(res.data);
                if (res.data.code === '0') {
                    this.$message({
                        type: 'success',
                        message: '删除成功'
                    })
                    this.getMembers();
                } else {
                    this.$message({
                        type: 'error',
                        message: res.data.msg
                    })
                }
            }).catch((err) => {
                console.log(err);
            })
        },
        modMember (member) {
            this.$ajax({
                method: 'post',
                url: api.modMember,
                data: {
                    'userId': member.userId,
                    'subProjectId': member.subProjectId,
                    'rule': member.rule 
                }
            }).then((res) => {
                if (res.data.code === '0') {
                    this.$message({
                        type: 'success',
                        message: '权限修改成功!'
                    })
                } else {
                    this.$message({
                        type: 'error',
                        message: res.data.msg
                    })
                    this.getMembers();
                }
            })
        },
        getUsers () {
            this.$ajax({
                method: 'get',
                url: api.getUsers,
                params: {
                    userName: this.searchUser
                }
            }).then((res) => {
                if (res.data.code === '0') {
                    this.userList = res.data.data;
                } else {
                    this.$message({
                        type: 'error',
                        message: res.data.msg
                    })
                }
            }).catch((err) => {
                console.log(err);
            })
        },
        addMember () {
            let arr = [];
            this.userList.forEach((item) => {
                this.selectUser.forEach((i) => {
                    if (i === item.userName) {
                        let o = {
                            userId: item.userId,
                            subProjectId: this.selectPro,
                            rule: '1'
                        };
                        arr.push(o);
                        return;
                    }
                })
            })
            this.$ajax({
                method: 'post',
                url: api.addMember,
                data: arr
            }).then((res) => {
                if (res.data.code === '0') {
                    this.$message({
                        type: 'success',
                        message: '添加成员成功'
                    })
                    this.getMembers();
                } else {
                    this.$message({
                        type: 'error',
                        message: res.data.msg
                    })
                }
                this.memberFormVisible = false;
            }).catch((err) => {
                this.memberFormVisible = false;
                console.log(err);
            })
        }
    },
}
</script>

<style lang="scss" scoped>
.project-member {
    position: absolute;
    width: calc(100% - 250px);
    left: 250px;
    color: #e3e6e8;
    h1, .top, .member-table {
        margin: 15px 40px;
    }
    .top {
        display: flex;
        justify-content: space-between;
    }
    .search-user {
        width: 200px;
        margin-bottom: 25px;
    }
    // .content {
    //     display: flex;
    // }
}
</style>
<style>
.el-select-dropdown__empty {
    background: #333;
    color: #e3e6e8;
}
.el-select-dropdown__item.hover, .el-select-dropdown__item:hover {
    border-color: #666;
    background-color: #2b2b2b;
    color: #1989fa;
}
.el-select-dropdown__item {
    color: #e3e6e8;
}
.el-select-dropdown {
    border: 1px solid #666;
    background: #2b2b2b;
}
.el-popper[x-placement^=bottom] .popper__arrow::after,.el-popper[x-placement^=top] .popper__arrow::after {
    border-bottom-color: #3b3b3b;
    border-top-color: #3b3b3b;
}
.el-table--enable-row-hover .el-table__body tr:hover>td {
    background-color: #333;
}
.el-table th, .el-table tr {
    background-color: #3b3b3b;
}
.el-table td, .el-table th.is-leaf {
    border-bottom: 1px solid #444;
}
.el-table thead {
    color: #fff;
}
.el-table{
    color: #e3e6e8;
}
.el-table__empty-block {
    background-color: #333;
    color: #fff;
}
.member-dialog .el-dialog, .el-pager li, .member-dialog .el-transfer-panel, .member-dialog .el-transfer-panel .el-transfer-panel__header {
    background-color: #3b3b3b;
}
.member-dialog .el-dialog__title, .member-dialog .el-transfer-panel .el-transfer-panel__header .el-checkbox .el-checkbox__label {
    color: #e3e6e8;
}
.member-dialog .el-transfer-panel__item.el-checkbox {
    color: #e3e6e8;
    display: block;
}
</style>

