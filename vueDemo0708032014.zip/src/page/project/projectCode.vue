<template>
	<div class="project-code">
        <h1>项目子工程代码</h1>
        <hr>
		<div class="project-table">
            <el-table
                :data="subProject"
                style="width: 100%"
                border
                >
                <el-table-column
                    prop="name"
                    label="工程名称">
                </el-table-column>
                <el-table-column label="工程地址">
                    <template slot-scope="scope">
                        <el-link :href="scope.row.repoUrl" target="_blank">{{scope.row.repoUrl}}</el-link>
                    </template>
                </el-table-column>
            </el-table>
        </div>
	</div>
</template>

<script>
import api from '@/api/api';
export default {
    name: 'project-code',
    data () {
        return {
            projectId: '',
            subProject: []
        }
	},
	created () {
        this.projectId = this.$route.query.projectId;
        this.getProject();
	},
    mounted () {
    },
    components: {
    },
    watch: {
        '$route' (to, from) {
        }
    },
    methods: {
        getProject () {
            this.$ajax({
                method: 'get',
                url: api.getProject,
                params: {
                    projectId: this.projectId
                }
            }).then((res) => {
                console.log(res.data.data.subProjects);
                this.subProject = res.data.data.subProjects;
            }).catch((err) => {
                console.log(err);
            })
        }
    }
}
</script>

<style lang="scss" scoped>
.project-code {
    width: calc(100% - 250px);
    position: absolute;
    left: 250px;
    color: #e3e6e8;
    h1, .top, .project-table {
        margin: 15px 40px;
    }
}
</style>
<style>
.el-table--enable-row-hover .el-table__body tr:hover>td {
    background-color: #333;
}
.el-table th, .el-table tr {
    background-color: #3b3b3b;
}
.el-table td, .el-table th.is-leaf {
    border-bottom: 1px solid #444;
}
.el-table thead {
    color: #fff;
}
.el-table{
    color: #e3e6e8;
}
.el-table__empty-block {
    background-color: #333;
    color: #fff;
}
.el-link.el-link--default {
    color: #e3e6e8;
}
</style>
