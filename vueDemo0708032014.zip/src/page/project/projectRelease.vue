<template>
	<div class="project-release">
        <!-- <iframe ref="iframe" src="http://10.17.82.12:2028/#/onlinePack/packList" width='1000px' id="iframe" height='700px' frameborder='0' name="_blank"></iframe> -->
	</div>
</template>

<script>
export default {
    name: 'project-release',
    data () {
        return {
        }
	},
	created () {
	},
    mounted () {
        let frame = document.getElementById('test');
        let obj = {
            name: 'lin'
        }
        frame.contentWindow.postMessage(obj, '*');
    },
    components: {
    },
    watch: {
        '$route' (to, from) {
        }
    },
    methods: {
    }
}
</script>

<style lang="scss" scoped>
.project-release {
    position: absolute;
    left: 250px;
    width: calc(100% - 250px);
    height: calc(100% - 60px);
    #iframe {
        width: 100%;
        height: 100%;
    }
}
</style>
