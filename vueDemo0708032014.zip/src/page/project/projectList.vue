<template>
    <div class="project-list">
        <h1>{{ title }}（{{projectList.length}}）</h1>
        <hr>
        <el-input placeholder="请输入内容" v-model="searchText" @blur="search" prefix-icon="el-icon-search" class="search" @input="getList()"></el-input>
        <div class="list">
            <div class="pro" v-for="(item,index) in projectList" :key="index" @click="goDetail(item)">
                <img src="@/assets/appLogo.png" alt="">
                <div class="text">
                    <span class="name">{{ item.name }}</span>
                    <span class="desc">{{ item.description }}</span>
                </div>
            </div>
            <div class="add-project" @click="createPro()" v-show="type=='all'">
                <img src="@/assets/icon/plus.png" alt="">
                <div class="text">
                    <span class="name">新建项目</span>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
import api from '@/api/api';
export default {
    name: 'projectList',
    data () {
        return {
            title: '所有项目',
            type: 'all',
            projectList: [],
            searchText: '',
            projectType: '1'
        }
    },
    created () {
        this.setTitle('all');
    },
    mounted () {
    },
    watch: {
        '$route' (to, from) {
            this.setTitle(this.$route.query.type)
        }
    },
    methods: {
        search () {
        },
        goDetail (item) {
            this.$router.push({
                name: 'projectDetail',
                query: {
                    projectId: item.id
                }
            })
        },
        setTitle (type) {
            switch (type) {
                case 'all':
                    this.title = '所有项目';
                    this.projectType = 1;
                    break;
                case 'created':
                    this.title = '我创建的';
                    this.projectType = 2;
                    break;
                case 'join':
                    this.title = '我参与的';
                    this.projectType = 3;
                    break;
                default:
                    break;
            }
            this.getList();
            if (type) {
                this.type = type;
            }
        },
        getList () {
            this.$ajax({
                method: 'get',
                url: api.getProjectList,
                params: {
                    userName: this.$store.state.userName,
                    type: this.projectType,
                    key: this.searchText
                }
            }).then((res) => {
                if (res.data.code === '0') {
                    if (res.data.data.length !== 0) {
                        let list = res.data.data;
                        this.projectList = res.data.data;
                    }
                } else {
                    this.$message.error(res.data.msg);
                }
            }).catch((err) => {
                console.log(err);
            })
        },
        createPro () {
            this.$router.push("/project/projectAdd");
        }
    }
}
</script>

<style lang="scss" scoped>
.project-list {
    color: #fff;
    h1, .search, .list {
        margin-left: 30px;
    }
    .search {
        width: 250px;
        margin: 30px;
    }
    .list {
        .pro, .add-project {
            width: 150px;
            height: 250px;
            float: left;
            display: flex;
            flex-direction: column;
            text-align: center;
            justify-content: space-around;
            cursor: pointer;
            // border: 1px solid #ddd;
        }
        .pro {
            img {
                width: 100px;
                height: 100px;
                margin: 0px 25px;
            }
            .text {
                display: flex;
                flex-direction: column;
                text-align: left;
                span {
                    display: block;
                    overflow: hidden;
                    text-overflow: ellipsis;
                    white-space: nowrap;
                }
            }
        }
        .add-project {
            img {
                width: 64px;
                height: 64px;
                margin: 0px 43px;
            }
        }
    }
}
</style>
