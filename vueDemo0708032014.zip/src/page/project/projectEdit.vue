<template>
	<div class="project-edit">
		<h1 class="title">基本信息</h1>
        <div class="con">
            <div class="image">
                <img src="@/assets/appLogo.png" alt="">
            </div>
            <el-scrollbar tag="div">
                <div class="form">
                    <el-form label-position="top" label-width="80px" width="460px" :model="projectForm">
                        <el-form-item label="项目名称" required>
                            <el-input v-model="projectForm.name" placeholder="请输入项目名称,建议以IPM单号+下划线+项目名称，如 IPM20180524214_中新天津生态城运维管理中心监控平台升级改造项目"></el-input>
                        </el-form-item>
                        <span class="el-icon-plus plus" @click="addAddress()"></span>
                        <el-form-item label="项目地址" class="pro-address" required>
                            <div  v-for="(item, index) in projectForm.subProjects" :key="index">
                                <el-input v-model="item.name" placeholder="请输入工程名称"></el-input>
                                <el-input v-model="item.repoUrl" placeholder="请输入工程git地址"></el-input>
                                <el-button @click.prevent="removeAddress(item)">删除</el-button>
                            </div>
                        </el-form-item>
                        <el-form-item label="项目描述" required>
                            <el-input v-model="projectForm.description" placeholder="请输入项目描述" type="textarea"></el-input>
                        </el-form-item>
                        <div class="pro-btn">
                            <el-button @click="updatePro()">更新</el-button>
                        </div>
                    </el-form>
                </div>
            </el-scrollbar>
        </div>
	</div>
</template>

<script>
import api from '@/api/api';
export default {
    name: 'project-edit',
    data () {
        return {
            projectId: '',
            projectForm: {
                name: '',
                proAddress: [
                    {
                        name: '',
                        repoUrl: '',
                    }
                ],
                desc: ''
            },
            project: {}
        }
	},
	created () {
        this.projectId = this.$route.query.projectId;
        this.getProject();
	},
    mounted () {
    },
    components: {
    },
    watch: {
        '$route' (to, from) {
        }
    },
    methods: {
        getProject () {
            this.$ajax({
                method: 'get',
                url: api.getProject,
                params: {
                    projectId: this.projectId
                }
            }).then((res) => {
                console.log(res.data);
                this.projectForm = res.data.data;
            })
        },
        updatePro () {

        },
        addAddress () {
            this.projectForm.proAddress.push({
                name: '',
                repoUrl: '',
            })
        },
        removeAddress (item) {
            if (this.projectForm.proAddress.length === 1) {
                this.$message({
                    type: 'warning',
                    message: '必须填写一个项目地址'
                })
                return;
            }
            let index = this.projectForm.proAddress.indexOf(item);
            if (index != -1) {
                this.projectForm.proAddress.splice(index, 1);
            }
        }
    }
}
</script>

<style lang="scss" scoped>
.project-edit {
    height: calc(100% - 60px);
    width: calc(100% - 250px);
    overflow: hidden;
    color: #e3e6e8;
    position: absolute;
    left: 250px;
    background: #333;
    h1 {
        margin-left: 40px;
    }
    .con {
        width: 100%;
        display: flex;
        margin-left: 40px;
        .image {
            width: 150px;
            height: 150px;
            margin-top: 40px;
        }
        .el-scrollbar {
            width: 100%;
            height: 100%;
        }
        .form {
            height: calc(100% - 27px);
            position: relative;
            width: calc(100% - 220px);
            margin: 30px 0 0 40px;
            .plus {
                position:absolute;
                top: 125px;
                right: 0px;
                cursor: pointer;
            }
            .pro-address {
                .el-input {
                    width: 400px;
                    margin: 0 20px 30px 0px;
                }
                .el-button {
                    margin-bottom: 30px;
                }
            }
        }
    }
}
</style>
