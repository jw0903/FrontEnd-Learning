<template>
    <div class="project">
        <side-menu></side-menu>
        <div class="content">
            <!-- <el-scrollbar tag="div" wrapClass="vue-scrollbar"> -->
                <router-view></router-view>
            <!-- </el-scrollbar> -->
        </div>
    </div>
</template>

<script>
import sideMenu from '@/components/sideMenu.vue';
export default {
    name: 'project',
    data () {
        return {
        }
    },
    mounted () {
        this.$store.commit('setIndex', 2);
    },
    components: {
        sideMenu
    },
    watch: {
        '$route' (to, from) {
        }
    },
    methods: {
    }
}
</script>

<style lang="scss" scoped>
.project {
    width: 100%;
    display: flex;
    aside {
        height: 100%;
    }
    .content {
        height: 100%;
        width: calc(100% - 250px);
    }
}
</style>
