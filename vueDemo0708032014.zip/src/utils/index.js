/*
 * @Author: Sixiang Le 
 * @Date:   2018-11-29 22:36:33 
 * @Last Modified by: Sixiang Le
 * @Last Modified time: 2019-02-22 16:11:59
 */
import CryptoJS from "crypto-js";
export function parseTime (time, cFormat) {
    if (arguments.length === 0) {
        return null;
    }
    const format = cFormat || "{y}-{m}-{d} {h}:{i}:{s}";
    let date;
    if (typeof time === "object") {
        date = time;
    } else {
        if (("" + time).length === 10) time = parseInt(time) * 1000;
        date = new Date(time);
    }
    const formatObj = {
        y: date.getFullYear(),
        m: date.getMonth() + 1,
        d: date.getDate(),
        h: date.getHours(),
        i: date.getMinutes(),
        s: date.getSeconds(),
        a: date.getDay()
    };
    const time_str = format.replace(/{(y|m|d|h|i|s|a)+}/g, (result, key) => {
        let value = formatObj[key];
        if (key === "a") return ["一", "二", "三", "四", "五", "六", "日"][value - 1];
        if (result.length > 0 && value < 10) {
            value = "0" + value;
        }
        return value || 0;
    });
    return time_str;
}

/**
 *
 * 用于生成 16位的随机字符串，时间戳加3位随机数
 * @export
 */
export function uuid () {
    let str = "";
    for (let i = 0; i < 3; i++) {
        str += Math.floor(Math.random() * 10);
    }
    return new Date().getTime() + str;
}

/**
 * 用于生成自定义长度的字母数字 字符串
 * @author: Sixiang Le 
 * @param {*} len  随机字符串长度
 */
export function getRandomAlphaNum (len) {
    let rdmString = "";
    for (; rdmString.length < len; rdmString += Math.random().toString(36).substr(2));
    return rdmString.substr(0, len);
}

 
/**
 * 获取密码的强度
 * 等级0（风险密码）：密码长度小于8位，或者只包含4类字符中的任意一类，或者密码与用户名一样，或者密码是用户名的倒写。
 * 等级1（弱密码）：包含两类字符，且组合为（数字+小写字母）或（数字+大写字母），且长度大于等于8位。
 * 等级2（中密码）：包含两类字符，且组合不能为（数字+小写字母）和（数字+大写字母），且长度大于等于8位。
 * 等级3（强密码）：包含三类字符及以上，且长度大于等于8位。
 * @author chenguanbin
 * @date   2016-01-27
 * @param  {String}   szPwd 密码
 * @param  {String}   szUser 用户名
 * @return {Number}     密码强度
 */
export const getPswdRank = function (szPwd, szUser) {
    let iRank = 0;
    szPwd.match(/[a-z]/g) && iRank++;
    szPwd.match(/[A-Z]/g) && iRank++;
    szPwd.match(/[0-9]/g) && iRank++;
    szPwd.match(/[^a-zA-Z0-9]/g) && iRank++;
    iRank = iRank > 3 ? 3 : iRank;
    if (
        szPwd.length < 8 ||
        iRank === 1 ||
        szPwd === szUser ||
        szPwd === szUser.split("").reverse().join("")
    ) {
        iRank = 0;
    }
    if (iRank === 2) {
        if (
            (szPwd.match(/[0-9]/g) && szPwd.match(/[a-z]/g)) ||
            (szPwd.match(/[0-9]/g) && szPwd.match(/[A-Z]/g))
        ) {
            iRank = 1;
        }
    }
    return iRank;
};
/**
 * 通用用户密码SHA256加密方法，用于验证密码
 * @param password 密码
 * @param salt 加密的盐
 * @param vCode 挑战码
 * @returns {String}  加密后密码
 */
export const pwdHashEncryptVerify = function (password, salt, vCode) {
    return CryptoJS.SHA256(CryptoJS.SHA256(password + salt).toString() + vCode).toString();
};
/**
 * 通用用户密码SHA256加密方法，用于保存密码
 * @param password 密码
 * @param salt 加密的盐
 * @returns {String}  加密后密码
 */
export const pwdHashEncryptSave = function (password, salt) {
    return CryptoJS.SHA256(password + salt).toString();
};
/**
 * 通用用户密码SHA256加密方法
 * @param password 密码
 * @param salt 加密的盐（可不传）
 * @returns {String}  加密后密码
 */
export const pwdHashEncrypt = function (password, salt) {
    salt = salt ? salt : "hikyun";
    return CryptoJS.SHA256(CryptoJS.SHA256(password + salt).toString()).toString();
};

/**
 * 用户密码AES加密方法
 * @param password 密码
 * @param aesKey 密钥（可传用户名）
 * @returns {String}  加密后密码
 */
export const pwdAesEncrypt = function (password, aesKey, salt) {
    let key = CryptoJS.SHA256(CryptoJS.SHA256(aesKey).toString() + salt).toString().substr(0, 16);
    let vi = CryptoJS.SHA256(key).toString().substr(0, 16);
    key = CryptoJS.enc.Utf8.parse(key);
    vi = CryptoJS.enc.Utf8.parse(vi);
    let encryptedPwd = CryptoJS.AES.encrypt(password, key, { iv: vi, mode: CryptoJS.mode.CFB, padding: CryptoJS.pad.ZeroPadding }).toString();
    return encryptedPwd;
};

/**
 * 获取密码的强度
 * 等级0（风险密码）：密码长度小于8位，或者只包含4类字符中的任意一类，或者密码与用户名一样，或者密码是用户名的倒写。
 * 等级1（弱密码）：包含两类字符，且组合为（数字+小写字母）或（数字+大写字母），且长度大于等于8位。
 * 等级2（中密码）：包含两类字符，且组合不能为（数字+小写字母）和（数字+大写字母），且长度大于等于8位。
 * 等级3（强密码）：包含三类字符及以上，且长度大于等于8位。
 * @author chenguanbin
 * @date   2016-01-27
 * @param  {String}   szPwd 密码
 * @param  {String}   szUser 用户名
 * @return {Number}     密码强度
 */
export const getPwdRank = function (szPwd, szUser) {
    let iRank = 0;
    szPwd.match(/[a-z]/g) && iRank++;
    szPwd.match(/[A-Z]/g) && iRank++;
    szPwd.match(/[0-9]/g) && iRank++;
    szPwd.match(/[^a-zA-Z0-9]/g) && iRank++;
    iRank = iRank > 3 ? 3 : iRank;
    if (
        szPwd.length < 8 ||
        iRank === 1 ||
        szPwd === szUser ||
        szPwd === szUser.split("").reverse().join("")
    ) {
        iRank = 0;
    }
    if (iRank === 2) {
        if (
            (szPwd.match(/[0-9]/g) && szPwd.match(/[a-z]/g)) ||
            (szPwd.match(/[0-9]/g) && szPwd.match(/[A-Z]/g))
        ) {
            iRank = 1;
        }
    }
    return iRank;
};

export function param2Obj (param) {
    if (!param) {
        return {};
    }
    return JSON.parse(
        "{\"" +
      decodeURIComponent(param)
          .replace(/"/g, "\\\"")
          .replace(/&/g, "\",\"")
          .replace(/=/g, "\":\"") +
      "\"}"
    );
}

export function debounce (func, wait, immediate) {
    let timeout, args, context, timestamp, result;

    const later = function () {
    // 据上一次触发时间间隔
        const last = +new Date() - timestamp;

        // 上次被包装函数被调用时间间隔last小于设定时间间隔wait
        if (last < wait && last > 0) {
            timeout = setTimeout(later, wait - last);
        } else {
            timeout = null;
            // 如果设定为immediate===true，因为开始边界已经调用过了此处无需调用
            if (!immediate) {
                result = func.apply(context, args);
                if (!timeout) context = args = null;
            }
        }
    };

    return function (...args) {
        context = this;
        timestamp = +new Date();
        const callNow = immediate && !timeout;
        // 如果延时不存在，重新设定延时
        if (!timeout) timeout = setTimeout(later, wait);
        if (callNow) {
            result = func.apply(context, args);
            context = args = null;
        }

        return result;
    };
}

export function deepClone (source) {
    if (!source && typeof source !== "object") {
        throw new Error("error arguments", "shallowClone");
    }
    const targetObj = source.constructor === Array ? [] : {};
    for (const keys in source) {
        if (source.hasOwnProperty(keys)) {
            if (source[keys] && typeof source[keys] === "object") {
                targetObj[keys] = source[keys].constructor === Array ? [] : {};
                targetObj[keys] = deepClone(source[keys]);
            } else {
                targetObj[keys] = source[keys];
            }
        }
    };
    return targetObj;
}
/**
 * @author lesixiang
 * @param {file} file 图片文件
 */
export function getBase64 (file) {
    return new Promise((resolve, reject) => {
        let reader = new FileReader();
        let imgResult = "";
        reader.readAsDataURL(file);
        reader.onload = () => {
            imgResult = reader.result;
        };
        reader.onerror = (error) => {
            reject(error);
        };
        // 完成时
        reader.onloadend = () => {
            resolve(imgResult);
        };
    });
}
