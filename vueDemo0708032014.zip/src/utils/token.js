const TokenKey = 'HATOM-Token'
const loginUserName = 'HATOM-User'

export function getToken () {
  return sessionStorage.getItem(TokenKey)
}

export function setToken (token) {
  return sessionStorage.setItem(TokenKey, token)
}

export function removeToken () {
  return sessionStorage.removeItem(TokenKey)
}

export function getUserName () {
  return sessionStorage.getItem(loginUserName)
}

export function setUserName (userName) {
  return sessionStorage.setItem(loginUserName, userName)
}

export function removeUserName () {
  return sessionStorage.removeItem(loginUserName)
}
