import CryptoJS from 'crypto-js'

/**
 * 通用用户密码SHA256加密方法，用于验证密码
 * @param password 密码
 * @param salt 加密的盐
 * @param vCode 挑战码
 * @returns {String}  加密后密码
 */
export const pwdHashEncryptVerify = function (password, salt, vCode) {
  return CryptoJS.SHA256(CryptoJS.SHA256(password + salt).toString() + vCode).toString()
}

// 16位随机数
export function randomNum () {
  let str = ''
  for (let i = 0; i < 3; i++) {
    str += Math.floor(Math.random() * 10)
  }
  return new Date().getTime() + str
}

/**
 * 用户密码AES加密方法
 * @param password 密码
 * @param aesKey 密钥（可传用户名）
 * @returns {String}  加密后密码
 */
export const pwdAesEncrypt = function (password, aesKey, salt) {
  let key = CryptoJS.SHA256(CryptoJS.SHA256(aesKey).toString() + salt).toString().substr(0, 16)
  let vi = CryptoJS.SHA256(key).toString().substr(0, 16)
  key = CryptoJS.enc.Utf8.parse(key)
  vi = CryptoJS.enc.Utf8.parse(vi)
  let encryptedPwd = CryptoJS.AES.encrypt(password, key, { iv: vi, mode: CryptoJS.mode.CFB, padding: CryptoJS.pad.ZeroPadding }).toString()
  return encryptedPwd
}
/**
 * 通用用户密码SHA256加密方法，用于保存密码
 * @param password 密码
 * @param salt 加密的盐
 * @returns {String}  加密后密码
 */
export const pwdHashEncryptSave = function (password, salt) {
  return CryptoJS.SHA256(password + salt).toString()
}
