<template>
  <aside class="main-sidebar animated">
    <div class="sidebar">
      <div class="title">
        <span>项目管理</span>
        <i class="el-icon-plus" @click="createPro"></i>
      </div>
      <el-menu
        style="text-align:left"
        default-active="/project/projectList?type=all"
        class="el-menu-vertical-demo"
        :collapse-transition="true"
        background-color="#3b3b3b"
        text-color="#e3e6e8"
        active-text-color="#409eff"
        :collapse="isCollapse"
        :unique-opened="false"
        router
      >
        <el-menu-item index="/project/projectList?type=all">
          <i class="el-icon-menu"></i>
          <span slot="title">所有项目</span>
        </el-menu-item>
        <el-menu-item index="/project/projectList?type=created">
          <i class="el-icon-menu"></i>
          <span slot="title">我创建的</span>
        </el-menu-item>
        <el-menu-item index="/project/projectList?type=join">
          <i class="el-icon-menu"></i>
          <span slot="title">我参与的</span>
        </el-menu-item>
      </el-menu>
    </div>
  </aside>
</template>
<script>
export default {
  props: {
    show: Boolean,
    isCollapse: true
  },
  data() {
    return {
      menuList: [
        {
          	adminMenu: {
				menuType: "page",
				url: "/case/projectList",
				code: "所有项目"
          	}
        },
		{
			adminMenu: {
				menuType: "page",
				url: "/case/test",
				code: "我创建的"
			}
		},
		{
			adminMenu: {
				menuType: "page",
				url: "/index",
				code: "我参与的"
			}
		}
      ]
    };
  },
  components: {
  },
  computed: {},
  mounted() {},
  created: function() {},
  methods: {
    handleSelect() {
      // if(this.device.isMobile){
      //   this.toggleSidebarShow(false);
      // }
    },
    createPro() {
      this.$router.push({
        path: "/project/projectAdd"
      });
    }
  }
};
</script>
<style lang="scss" scoped>
aside {
  height: 100%;
  width: 250px;
  background: #3b3b3b;
  .sidebar {
    .title {
      color: #e3e6e8;
      text-align: center;
      font-size: 18px;
      padding-top: 10px;
      position: relative;
      i {
        position: absolute;
        right: 10px;
        cursor: pointer;
      }
    }
  }
}
</style>

<style>
.sidebar .el-menu {
  border: none;
}
</style>
