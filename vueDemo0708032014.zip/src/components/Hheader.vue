<template>
    <div class="header-container">
        <header>
            <span @click="changeRoute(0)" :class="[headerIndex == 0 ? 'active' : '']" class="logo"></span>
            <div class="nav">
                <div @click="changeRoute(1)" :class="[headerIndex == 1 ? 'active' : '']">开发文档</div>
                <div @click="changeRoute(2)" :class="[headerIndex == 2 ? 'active' : '']">项目管理</div>
                <div @click="changeRoute(3)" :class="[headerIndex == 3 ? 'active' : '']">工作空间</div>
                <div @click="changeRoute(4)" :class="[headerIndex == 4 ? 'active' : '']">案例</div>
            </div>
            <div class="personal" @click="changeRoute(5)" v-if="getUsername === ''">登录</div>
            <div class="user" v-else>
                <el-dropdown trigger="click">
                    <span class="el-dropdown-link">
                        {{ getUsername}}<i class="el-icon-arrow-down el-icon--right"></i>
                    </span>
                    <el-dropdown-menu slot="dropdown">
                        <el-dropdown-item @click.native="pwdDialogVisible=true">修改密码</el-dropdown-item>
                        <el-dropdown-item @click.native="loginOut()">退出登录</el-dropdown-item>
                    </el-dropdown-menu>
                </el-dropdown>
            </div>
        </header>
        <passwordReset class="pwd-dialog" :pwdDialogVisible="pwdDialogVisible" :title="title" :type=0 @closeDialog="closeDialog"></passwordReset>
    </div>
</template>

<script>
import passwordReset from '@/components/passwordReset'
import { mapGetters } from 'vuex'
export default {
    name: 'Hheader',
    data () {
        return {
            dialogVisible: false,
            currentIndex: '',
            dialogFormVisible: false,
            pwdDialogVisible: false,
            title: '修改密码',

        }
    },
    computed: {
        ...mapGetters([   
            'getUsername'
        ]),
        headerIndex () {
            return this.$store.state.headerIndex;
        },
    },
    watch: {
        headerIndex (curIndex, oldIndex) {
            return curIndex
        },
        getUsername: {
            handler: function(newVal, oldVal) {
                return newVal
            }
        }
    },
    methods: {
        changeRoute (route) {
            switch (route) {
                case 0:
                    this.$router.push('/index')
                    break
                case 1:
                    this.$router.push('/devGuide')
                    break
                case 2:
                    this.$router.push('/project')
                    break
                case 3:
                    // this.$router.push('/project')
                    break
                case 4:
                    this.$router.push('/plugin')
                    break
                case 5:
                    this.$router.push('/login')
                    break
                default:
                    break
            }
        },
        closeDialog () {
            this.pwdDialogVisible = false;
        },
        loginOut () {
            this.$store.dispatch("LogOut").then(() => {
                location.reload();
            })
        }
    },
    components: {
        passwordReset
    }
}
</script>

<style lang="scss" scoped>
$background-color-black: #3b3b3b;
$font-color: #e3e6e8;
$border-color: #444;
.header-container {
    position: fixed;
    top: 0;
    height: 60px;
    left: 0;
    right: 0;
    background: #000;
}
header {
    // background: #545c64;
    // color: #409eff;
    margin: 0 auto;
    min-width: 1140px;
    padding: 0px 20px;
    height: 60px;
    line-height: 60px;
    color: #fff;
    display: flex;
    justify-content: space-around;
    font-size: 18px;
    .logo {
        background: url('../assets/logo1.png');
        background-size: 125px;
        background-repeat: no-repeat;
        background-position: 5px;
        cursor: pointer;
        display: inline-block;
        min-width: 250px;
        text-align: center;
        // color: #409eff;
        color: $font-color;
        font-weight: 800;
        font-size: 35px;
        text-shadow: -2px -2px #fff, 2px 2px #777;
    }
    .nav {
        display: flex;
        justify-content: flex-start;
        width: 80%;
        div {
            margin-right: 50px;
            cursor: pointer;
            &:hover {
                color: #1989fa;
            }
        }
        .active {
            color: #1989fa;
        }
    }
    .personal {
        cursor: pointer;
        margin: 0  0 0 50px;
        min-width: 100px;
        text-align: center;
    }
    .user {
        color: #fff;
        cursor: pointer;
        min-width: 100px;
        text-align: center;
        .el-dropdown {
            color: #fff;
        }
    }
}
.pwd-dialog {
    .el-dialog {
        background: #000;
    }
}
</style>
<style>
.pwd-dialog .el-dialog {
    background: #333;
    width: 500px;
}
.el-dropdown-menu {
    background-color: #3b3b3b;
    border: 1px solid #666;
}
.el-dropdown-menu__item {
    color: #e3e6e8;
}
.el-popper[x-placement^=bottom] .popper__arrow::after{
    border-bottom-color: #3b3b3b;
}
.el-dropdown-menu__item:focus, .el-dropdown-menu__item:not(.is-disabled):hover {
    border-color: #666;
    background-color: #2b2b2b;
}
</style>