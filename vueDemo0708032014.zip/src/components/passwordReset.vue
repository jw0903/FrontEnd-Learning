<template>
    <el-dialog
        :title="title"
        :visible.sync="pwdDialogVisible"
        :modal-append-to-body="false"
        :close-on-click-modal="false"
        :before-close="closeDialog">
        <div class="form-container-personinfo">
            <el-popover  popper-class="newpwd-tip" ref="popover1" placement="top" width="215" trigger="click" :value="showNewPwdTip">
                <div  :class="{'dissatisfy': pwdLackOfLen }"><i>{{ pwdLackOfLen ? '●' : '✔'}}</i>密码长度为8位~20位</div>
                <div  :class="{'dissatisfy': pwdLackOfType }"><i>{{ pwdLackOfType ? '●' : '✔'}}</i>至少包含以下2种字符：大小写字母、数字、特殊字符（空格除外）</div>
            </el-popover>
            <!-- <el-popover popper-class="newpwd-tip" ref="popover2" placement="top" width="215" trigger="click" :value="showNamePwdTip">
                    <div class='dissatisfy'><i>●</i>密码不能是用户名或者用户名的倒写</div>
            </el-popover> -->
            <el-form ref="pwdForm" :rules="passwordRules" :model="pwdForm" label-position="right" label-width="125px">
                <el-form-item label="登录账户密码：" prop="oldPwd">
                    <el-input v-model="pwdForm.oldPwd" placeholder="请输入登录账户密码" show-password></el-input>
                </el-form-item>
                <el-form-item label="新密码：" prop="newPwd">
                    <el-input v-model="pwdForm.newPwd" placeholder="请输入新密码" show-password
                    @focus="checkNewPwd" @input="checkNewPwd" v-popover:popover1></el-input>
                    <password-rank  v-show="showPwdStrenth" :status="newPwdStrenth" ></password-rank>
                </el-form-item>
                <el-form-item label="重复密码：" prop="rePwd">
                    <el-input v-model="pwdForm.rePwd" placeholder="请再次输入密码" show-password></el-input>
                </el-form-item>
            </el-form>
        </div>
        <span slot="footer" class="dialog-footer">
            <el-button type="primary" @click="handleSave">确 定</el-button>
            <el-button @click="closeDialog">取 消</el-button>
        </span>
    </el-dialog>
</template>
<script>
import passwordRank from "./passwordRank";
import { uuid, getPwdRank, pwdHashEncryptVerify, pwdHashEncryptSave, pwdAesEncrypt } from "@/utils";
import api from '../api/api.js'
export default {
    name: "passwordReset",
    props: {
        title: {
            type: String,
            default: "密码修改"
        },
        userName: {
            type: String,
            default: ""
        },
        userId: {
            type: String,
            default: ""
        },
        pwdDialogVisible: {
            type: Boolean,
            default: false
        },
        type: {
            type: Number,
            default: 1
        }
    },
    data () {
        let self = this;
        let validateNewPass = (rule, value, callback) => {
            if (value.match(/[^\x00-\xff]/)){// 只能包含数字字母特殊字符
                callback(new Error("密码只能包含数字字母特殊字符"));
            } else {
                this.getNewPwdRank(value);
                callback();
            }
        };
        let compareToLoginPwd = (rule, value, callback) => {
            if (this.type === 1){
                callback();
            }
            if (value === this.pwdForm.oldPwd) {
                callback(new Error("新密码不能是当前登录密码"));
            } else {
                callback();
            }
        };
        let validateConfirmPass = (rule, value, callback) => {
            if (value !== this.pwdForm.newPwd) {
                callback(new Error("两次输入密码不一致"));
            } else {
                callback();
            }
        };
        return {
            pwdForm: {
                newPwd: "",
                rePwd: "",
                oldPwd: ""
            },
            isShowPwd1: false,
            isShowPwd2: false,
            isShowPwd3: false,
            passwordRules: {
                oldPwd: [
                    { required: true, message: "登录账户密码不能为空", trigger: "blur" }
                ],
                newPwd: [
                    { required: true, message: "请输入新密码", trigger: "change" },
                    { required: true, message: "请输入新密码", trigger: "blur" },
                    { validator: validateNewPass, trigger: "change" },
                    { validator: validateNewPass, trigger: "blur" },
                    { validator: compareToLoginPwd, trigger: "change" },
                    { validator: compareToLoginPwd, trigger: "blur" }
                ],
                rePwd: [
                    { required: true, message: "请再次输入密码", trigger: "change" },
                    { required: true, message: "请再次输入密码", trigger: "blur" },
                    { validator: validateConfirmPass, trigger: "change" },
                    { validator: validateConfirmPass, trigger: "blur" }
                ]
            },
            uName: this.$store.getters.getUsername,
            newPwdStrenth: 0, // 密码强度验证控件状态，0:危险 1:弱 2:中 3:强
            pwdLackOfLen: false,
            pwdOverOfType: false, // 字符种类超过
            pwdLackOfType: false,
            productCode: 'hatom'
        };
    },
    created () {
    },
    computed: {
        showNewPwdTip () { // 密码规则不符合
            return (this.pwdLackOfLen || this.pwdLackOfType) && !this.showNamePwdTip;
        },
        showNamePwdTip (){ // 密码和用户名相似
            let {uName} = this;
            let {newPwd} = this.pwdForm;
            return false || newPwd === uName || newPwd === uName.split("").reverse().join("");
        },
        showPwdStrenth (){
            return this.pwdForm.newPwd && !this.pwdOverOfType;
        }
    },
    components: { passwordRank },
    methods: {
        /**
         * 获取密码强度
         */
        getNewPwdRank (pwd) {
            let {uName} = this;
            this.newPwdStrenth = getPwdRank(pwd, uName);
        },
        /**
         * 分条检验密码要求
         */
        checkNewPwd () {
            let pwd = this.pwdForm.newPwd;
            this.pwdLackOfLen = pwd.length < 8 || pwd.length > 20;
            // 字符种类校验
            this.pwdOverOfType = pwd.match(/[^\x00-\xff]/) ? true : false;
            let iRank = 0;
            pwd.match(/[a-z]/g) && iRank++;
            pwd.match(/[A-Z]/g) && iRank++;
            pwd.match(/[0-9]/g) && iRank++;
            pwd.match(/[^a-zA-Z0-9]/g) && iRank++;
            this.pwdLackOfType = iRank < 2 ? true : false;
        },
        handleSave () {
            if (this.type === 1){
                this.resetPassword();
            } else {
                this.updatePassword();
            }
        },
        getChallengeCode () {
            this.btnLoading = true
            return new Promise ((resolve, reject) => {
                this.$ajax({
                    method: 'post',
                    url: api.getChallengeCode,
                    data: {
                        productCode: this.productCode,
                        name: this.$store.state.userName,
                        type: 1
                    }
                }).then((res) => {
                    resolve(res.data)
                }).catch((err) => {
                    reject(err)
                })
            })
        },
        updatePassword () {
            let {uName, showNewPwdTip, showNamePwdTip} = this;
            let salt = uuid();
            this.$refs["pwdForm"].validate((valid) => {
                if (!valid) {
                    return false;
                }
                if (showNewPwdTip || showNamePwdTip){
                    return this.$message({ message: "请输入符合规则的密码", type: "warning" });
                }
                this.getChallengeCode().then((data) => {
                    if (data.code == '0') {
                        this.$ajax({
                            method: "post",
                            url: api.modPwd,
                            data: {
                                oldPwd: pwdHashEncryptVerify(this.pwdForm.oldPwd.trim(), data.data.salt, data.data.vCode),
                                newPwd: pwdAesEncrypt(pwdHashEncryptSave(this.pwdForm.newPwd, data.data.salt), data.data.vCode, salt),
                                salt: salt,
                                codeId: data.data.codeId
                            }
                        }).then((res) => {
                            if (res.data.code == "0") {
                                this.$message.success("修改成功,请重新登录");
                                this.$store.dispatch('LogOut').then(() => {
                                    setTimeout(() => {
                                        this.$router.push("/login");
                                    }, 1000)
                                })
                                this.closeDialog();
                            } else {
                                this.$message({
                                    type: 'info',
                                    message: res.data.msg
                                })
                            }
                        });
                        
                    }
                })
            });
        },
        resetPassword () {
            this.$refs["pwdForm"].validate((valid) => {
                if (valid) {
                    this.$http({
                        method: "post",
                        url: this.$api.RESET_PWD,
                        data: {
                            userId: this.userId,
                            operatePwd: pwdHashEncrypt(this.pwdForm.oldPwd),
                            newPwd: pwdHashEncrypt(this.pwdForm.newPwd)
                        }
                    }).then((res) => {
                        if (res.code === "200") {
                            this.closeDialog();
                            this.$message.success(`已重置 ${this.userName} 密码`);
                        } else {
                            this.pwdForm.oldPwd = "";
                            this.$message.error("登录账户密码错误");
                        }
                    });
                } else {
                    return false;
                }
            });
        },
        comparePwd () {
            if (this.pwdForm.newPwd !== this.pwdForm.rePwd) {
                return false;
            }
        },
        closeDialog () {
            this.$refs["pwdForm"].resetFields();
            this.$refs["pwdForm"].clearValidate();
            this.$emit("closeDialog");
        }
    },
    watch: {
    }
};
</script>
<style rel="stylesheet/scss" lang="scss">
    .form-container-personinfo {
        width: 400px;
        padding: 20px 0;
    }
    .el-popover.newpwd-tip {
        line-height: 20px;
        background: rgba(255, 255, 255, 0.9);
        color: #FFF;
        padding: 10px 10px 10px 30px;
        border: none;
        border-radius: 2px;
        div {
            margin-bottom: 5px;
            color: #989A9C;
        }
        .dissatisfy {
            color: #333;
        }
        i {
            float: left;
            margin-left: -18px;
            font-style: normal;
        }
        &.el-popover[x-placement^=top] .popper__arrow {
            bottom: -11px;
            border-top-color: #666;
            &:after {
                border-top-color: #fff;
            }
        }
        &.el-popover[x-placement^=bottom] .popper__arrow {
            bottom: -11px;
            border-bottom-color: #666;
            &:after {
                border-bottom-color: #666;
            }
        }
    }
</style>