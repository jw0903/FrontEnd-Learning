const getModelList = 'http://10.19.171.20:8899/mock/5d00dc9ef6f049295807e948/hat/modelList'

// 在线打包相关接口
const uploadFile = '/file/v1.0/uploadFiles'
const addTemplate = '/template/manager/create_template'
const resType = '/template/manager/get_resource_type'
const modelList = '/template/manager/get_template_list'
const build = '/template/manager/build'
const getLog = '/template/manager/replaceHolder/console'

// 密码相关
const getChallengeCode = '/web/api/v1/center/challenge_code' // 获取挑战码
const slideVerifyCode = '/web/api/v1/center/verify_code' // 验证用户是否登录错误次数过多
const login = '/web/api/v1/center/login' // 用户登录
const logOut = '/web/api/v1/center/logout' // 用户登出
const modPwd = '/web/api/v1/center/modify_password' // 修改密码（包括弱密码、登录之后主动修改密码）
const changePwd = '/web/api/v1/center/change_pwd' // 忘记密码: 重置密码
const checkVerifyCode = '/web/api/v1/center/center_phone_check_code' // 验证短信验证码 返回verifyCode
// const checkVerifyCode = 'proxy/api/eits/v1/phone/checkCode'
const sendCode = '/web/api/v1/center/send_verify_code' // 发送手机验证码？ 验证手机号码已绑定？
const validateUser = ''
const PHONE_STATUS = ''
const CHECK_VERIFYCODE = ''
const GET_VERIFYCODE = ''

// 项目相关
const creatPro = '/web/api/v1/project/createProject' // 创建项目
const upload = '/web/api/v1/upload/uploadFile' // 项目上传文件
const getProject = '/web/api/v1/project/getProject' // 查询项目
const getProjectList = '/web/api/v1/project/getProjectList' // 获取项目列表
// http://localhost:6543/web/api/v1/project/getProjectList?userId=llf 
const getDistList = '/web/api/v1/dist/getDistList' // 获取项目子工程各版本前端包信息
const getUsers = '/web/api/v1/user/getUsers' // 获取用户列表
const getMembers = '/web/api/v1/subproject/getMembers' // 获取项目成员列表
const addMember = '/web/api/v1/subproject/addNewMembers' // 子工程添加成员
const modMember = '/web/api/v1/subproject/modifyMemberRule' // 更新成员权限
const delMember = '/web/api/v1/subproject/RemoveMember' // 子工程删除成员
export default {
    getModelList,
    uploadFile,
    addTemplate,
    resType,
    modelList,
    build,
    getLog,
    logOut,
    modPwd,
    changePwd,
    checkVerifyCode,
    sendCode,
    getChallengeCode,
    slideVerifyCode,
    login,
    validateUser,
    PHONE_STATUS,
    CHECK_VERIFYCODE,
    GET_VERIFYCODE,
    creatPro,
    upload,
    getProject,
    getProjectList,
    getDistList,
    getUsers,
    getMembers,
    addMember,
    modMember,
    delMember
}
