
import axios from 'axios'
import { Message } from 'element-ui'
import { getToken } from '@/utils/token'

const req = axios.create({
    timeout: 20000,
    baseURL: process.env.NODE_ENV === 'development' ? '/ip' : process.env.HOST
})

req.interceptors.request.use(
    config => {
        if (getToken()) {
            config.headers['Authorization'] = getToken()
        }
        console.log(config.url);
        if (config.url.indexOf('template') !== -1 || config.url.indexOf('v1.0') !== -1) {
            config.baseURL = '/pack';
            // config.url.replace('/ip', '');
            // config.url = '/pack' + config.url;
            // console.log(config.url);
        }
        return config
    },
    err => {
        Message.error('请求错误')
        return Promise.reject(err)
    }
)
// 返回状态判断(添加响应拦截器)
req.interceptors.response.use(
    res => {
        return res
        // if (res.data.code === '0') {
        //     return res.data.data
        // } else {
        //     Message({
        //         type: 'info',
        //         message: res.data.msg
        //     })
        // }
    },
    err => {
        // Message.error(err.message);
        return Promise.reject(err)
    }
)

export default req
