import Vue from 'vue'
import Router from 'vue-router'
import index from '../page/index'
import project from '../page/project/project'
import projectList from '../page/project/projectList'
import projectAdd from '../page/project/projectAdd'
import projectDetail from '../page/project/projectDetail'
import projectCode from '../page/project/projectCode'
import projectMember from '../page/project/projectMember'
import projectRelease from '../page/project/projectRelease'
import projectEdit from '../page/project/projectEdit'
import devGuide from '../page/dev-guide'
import onlinePack from '../page/pack/online-pack'
import packList from '../page/pack/packList'
import packHistory from '../page/pack/packHistory'
import plugin from '../page/plugin/plugin'
import login from '../page/login/login'
import forgetPwd from '../page/login/forgetPwd'
import modifyPassword from '../page/login/modifyPassword'
import resetPassword from '../page/login/resetPassword'

Vue.use(Router)
export default new Router({
    routes: [
        {
            path: '',
            redirect: '/index'
        },
        {
            name: 'index',
            path: '/index',
            component: index
        },
        {
            name: 'project',
            path: '/project',
            component: project,
            redirect: '/project/projectList',
            children: [
                {
                    name: 'projectList',
                    path: 'projectList',
                    component: projectList
                },
                {
                    name: 'projectAdd',
                    path: 'projectAdd',
                    component: projectAdd
                }
            ]
        },
        {
            name: 'projectDetail',
            path: '/projectDetail',
            component: projectDetail,
            redirect: '/projectDetail/projectCode',
            children: [
                {
                    name: 'projectCode',
                    path: 'projectCode',
                    component: projectCode
                },
                {
                    name: 'projectMember',
                    path: 'projectMember',
                    component: projectMember
                },
                {
                    name: 'projectEdit',
                    path: 'projectEdit',
                    component: projectEdit
                },
                {
                    name: 'projectRelease',
                    path: 'projectRelease',
                    component: packList
                }
            ]
        },
        {
            name: 'devGuide',
            path: '/devGuide',
            component: devGuide
        },
        {
            name: 'onlinePack',
            path: '/onlinePack',
            component: onlinePack,
            redirect: '/onlinePack/packList',
            children: [
                {
                    name: 'packList',
                    path: 'packList',
                    component: packList
                },
                {
                    name: 'packHistory',
                    path: 'packHistory',
                    component: packHistory
                }
            ]
        },
        {
            name: 'plugin',
            path: '/plugin',
            component: plugin
        },
        {
            name: 'login',
            path: '/login',
            component: login
        },
        {
            name: 'forgetPwd',
            path: '/forgetPwd',
            component: forgetPwd
        },
        {
            name: 'modifyPassword',
            path: '/modifyPassword',
            component: modifyPassword
        },
        {
            name: 'resetPassword',
            path: '/resetPassword',
            component: resetPassword
        }
    ]
})
