import Vue from 'vue'
import Vuex from 'vuex'
import ajax from '@/api/axiosConfig.js'
import api from '@/api/api'
import { getToken, setToken, removeToken, getUserName, setUserName, removeUserName } from "@/utils/token";
Vue.use(Vuex)

export default new Vuex.Store({
    state: {
        headerIndex: 0,
        token: getToken(),
        userName: ''
    },
    mutations: {
        setIndex(state, index) {
            state.headerIndex = index;
        },
        SET_TOKEN: (state, token) => {
            state.token = token;
        },
        SET_USERNAME: (state, name) => {
            state.userName = name;
            setUserName(name)
        }
    },
    actions: {
        Login ({ commit }, userInfo) {
            return new Promise((resolve, reject) => {
                ajax({
                    method: "post",
                    url: api.login,
                    data: userInfo
                }).then((res) => {
                    if (res.data.code == '0' || res.data.code == '1018') {
                        setToken(res.data.data.Authorization);
                        commit("SET_TOKEN", res.data.Authorization);
                        commit("SET_USERNAME", userInfo.name);
                    }
                    resolve(res);
                }).catch((err) => {
                    reject(err);
                });
            });
        },
        LogOut ({ commit, state }) {
            var auth = {
                "Authorization": getToken()
            }
            return new Promise((resolve, reject) => {
                ajax({
                    method: "post",
                    url: api.logOut,
                    data: auth
                }).then((res) => {
                    commit("SET_TOKEN", "");
                    commit("SET_USERNAME", "");
                    removeToken();
                    resolve();
                }).catch((err) => {
                    removeToken();
                    removeUserName();
                    reject(err);
                })
            })
        }
    },
    getters: {
        getUsername: state => {
            if (getUserName()) {
                state.userName = getUserName();
            }
            return state.userName;
        },
        token: state => state.token,
    }
})
