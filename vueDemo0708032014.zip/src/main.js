import Vue from 'vue'
import App from './App.vue'
import store from './store/store.js'
import router from './router/index.js'
import './router/permission.js'
import axios from './api/axiosConfig'
import ElementUI from 'element-ui'
import 'element-ui/lib/theme-chalk/index.css'

Vue.use(ElementUI)

// const Axios = axios.create({
//     baseURL: process.env.NODE_ENV === 'development' ? '/api' : process.env.HOST,
//     timeout: 20000
// })

Vue.prototype.$ajax = axios
Vue.config.productionTip = false

new Vue({
    store,
    router,
    render: h => h(App)
}).$mount('#app')
