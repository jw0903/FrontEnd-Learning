<template>
  <div id="app">
    <el-container>
      <el-header>
        <hheader></hheader>
      </el-header>
      <el-container class="main">
        <router-view></router-view>
      </el-container>
    </el-container>
  </div>
</template>

<script>
import Hheader from './components/Hheader.vue'
export default {
    name: 'app',
    components: {
        Hheader
    },
    created () {
      localStorage.setItem('index', 0);
    }
}
</script>
<style lang="scss" scoped>
$background-color-black: #333;
body {
    background: $background-color-black;
}
#app {
    background: $background-color-black;
}
.el-container {
  width: 100%;
  min-width: 1140px;
  height: 100%;
  margin: 0 auto;
  .el-header {
    min-width: 1140px;
    border-bottom: 1px solid #e6e6e6;
    background: #fff;
    position: fixed;
    z-index: 100;
  }
  .main {
    height: calc(100% - 60px);
    margin-top: 60px;
  }
}
</style>

<style>
* {
    box-sizing: border-box;
    outline: 0;
}
html, body, #app {
    margin: 0px;
    padding: 0;
    width: 100%;
    height: 100%;
    font-family: "PingFangSC-Regular";
}
ul, li {
  list-style-type: none;
}
.el-input__inner, .el-textarea__inner {
    background: #333;
    border: 1px solid #666;
    color: #e3e6e8;
}
</style>
