'use strict'
module.exports = {
  NODE_ENV: '"production"',
  HOST: '"http://10.17.84.236:5000"'
}
