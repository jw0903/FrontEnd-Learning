import Vue from 'vue'
import Router from 'vue-router'
import index from '../page/index'
import showCase from '../page/show-case'
import devGuide from '../page/dev-guide'
import onlinePack from '../page/pack/online-pack'
// import packDetail from '../page/pack/pack'
// import packDemo from '../page/pack/packdemo'
import packList from '../page/pack/packList'
import packHistory from '../page/pack/packHistory'
import plugin from '../page/plugin/plugin'
import personal from '../page/personal'

Vue.use(Router)
export default new Router({
    routes: [
        {
            path: '',
            redirect: '/index'
        },
        {
            name: 'index',
            path: '/index',
            component: index
        },
        {
            name: 'case',
            path: '/case',
            component: showCase
        },
        {
            name: 'devGuide',
            path: '/devGuide',
            component: devGuide
        },
        {
            name: 'onlinePack',
            path: '/onlinePack',
            component: onlinePack,
            redirect: '/onlinePack/packList',
            children: [
                {
                    name: 'packList',
                    path: 'packList',
                    component: packList
                },
                {
                    name: 'packHistory',
                    path: 'packHistory',
                    component: packHistory
                },
                // {
                //     name: 'pack',
                //     path: 'pack',
                //     component: packDetail
                // },
                // {
                //     name: 'packdemo',
                //     path: 'packdemo',
                //     component: packDemo
                // }
                // {
                //     name: 'historyList',
                //     path: 'historyList',
                //     component: historyList
                // },
                // {
                //     name: 'modelPack',
                //     path: 'modelPack',
                //     components: modelPack
                // },
                // {
                //     name: 'historyPack',
                //     path: 'historyPack',
                //     components: historyPack
                // }
            ]
        },
        {
            name: 'plugin',
            path: '/plugin',
            component: plugin
        },
        {
            name: 'personal',
            path: '/personal',
            component: personal
        }
    ]
})
