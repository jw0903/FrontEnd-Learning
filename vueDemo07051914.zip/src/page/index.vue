<template>
    <div class="case">
        <div class="title">
            <h2>使用HTML、CSS&JavaScript进行移动端APP开发</h2>
            <h2>多平台共用一套代码</h2>
        </div>
        <div class="cards">
            <ul class="container">
                <li>
                    <div class="card">
                        <img src="../assets/assemble.png" alt="">
                        <h3>指南</h3>
                        <p>Hatom开发App应用指南，包含前端项目整体架构，原生Android端提供的插件展示以及如何调用插件</p>
                        <a @click="changeRoute(1)">查看详情</a>
                    </div>
                </li>
                <li>
                    <div class="card">
                        <img src="../assets/guide.png" alt="">
                        <h3>在线打包</h3>
                        <p>在线选择模版，自定义上传资源进行打包，支持在线修改App名称、版本号等信息。</p>
                        <a @click="changeRoute(2)">查看详情</a>
                    </div>
                </li>
                <li>
                    <div class="card">
                        <img src="../assets/template.png" alt="">
                        <h3>案例</h3>
                        <p>Hatom项目开发样例展示: 包括智能应用平台移动端等项目。</p>
                        <a @click="changeRoute(3)">查看详情</a>
                    </div>
                </li>
                <li>
                    <div class="card">
                        <img src="../assets/case.png" alt="">
                        <h3>模版管理</h3>
                        <p>在线进行新增模版以适应不同产品线开发需求</p>
                        <a @click="changeRoute(4)">查看详情</a>
                    </div>
                </li>
            </ul>
        </div>
    </div>
</template>

<script>
export default {
    name: 'index',
    data () {
        return {}
    },
    methods: {
        changeRoute (index) {
            switch (index) {
                case 1:
                    this.$router.push('/devGuide')
                    break
                case 2:
                    this.$router.push('/onlinePack')
                    break
                case 3:
                    this.$router.push('/case')
                    break
                case 4:
                    this.$router.push('/plugin')
                    break
                default:
                    break
            }
        }
    }
}
</script>

<style lang="scss" scoped>
.case {
    width: 100%;
    text-align: center;
    .title {
        color: #409EFF;
        margin: 100px 0px;
    }
    .cards {
        width: 100%;
        max-width: 1140px;
        margin: 0 auto;
        .container {
            width: auto;
            padding: 0;
            li {
                width: 25%;
                padding: 0 19px;
                box-sizing: border-box;
                float: left;
                list-style: none;
                .card {
                    height: 430px;
                    width: 100%;
                    background: #fff;
                    border: 1px solid #eaeefb;
                    border-radius: 5px;
                    box-sizing: border-box;
                    text-align: center;
                    position: relative;
                    transition: all .3s ease-in-out;
                    bottom: 0;
                    &:hover {
                        bottom: 6px;
                        box-shadow: 0 6px 18px 0 rgba(232,237,250,.5);
                    }
                    img {
                        width: 160px;
                        height: 120px;
                        margin: 66px auto 60px;
                    }
                    h3 {
                        margin: 0;
                        font-size: 18px;
                        color: #1f2f3d;
                        font-weight: 400;
                    }
                    p {
                        font-size: 14px;
                        color: #99a9bf;
                        padding: 0 25px;
                        line-height: 20px;
                    }
                    a {
                        height: 53px;
                        line-height: 52px;
                        font-size: 14px;
                        color: #409eff;
                        text-align: center;
                        border: 0;
                        border-top: 1px solid #eaeefb;
                        padding: 0;
                        cursor: pointer;
                        width: 100%;
                        position: absolute;
                        bottom: 0;
                        left: 0;
                        background-color: #fff;
                        border-radius: 0 0 5px 5px;
                        transition: all .3s;
                        text-decoration: none;
                        display: block;
                        &:hover {
                            color: #fff;
                            background: #409eff;
                        }
                    }
                }
            }
        }
    }
}
</style>
