<template>
    <div class="plugin">
        <li class="addModel" @click="addModel">
            <i class=el-icon-folder-add></i>
            <div class="content">
                <span>创建新模版</span>
            </div>
        </li>
        <li v-for="(item, index) in modelList" :key="index" class="model" @click="choseModel(item)">
            <img :src="'api'+item.tp_icon" alt="">
            <div class="content">
                <h1>{{item.tp_name}}</h1>
                <p><i class="el-icon-document"></i>{{item.tp_description}}</p>
            </div>
        </li>
        <el-dialog :visible.sync="showModelVisible">
            <el-form :model="currentModel" label-width="100px" ref="modelForm" :rules="rules" v-if="stepIndex === 1">
                <el-form-item label="模版名称" prop="tp_name">
                    <el-input v-model="currentModel.tp_name"></el-input>
                </el-form-item>
                <el-form-item label="svn路径" prop="tp_code_path">
                    <el-input v-model="currentModel.tp_code_path"></el-input>
                </el-form-item>
                <el-form-item label="svn账号" prop="tp_code_account">
                    <el-input v-model="currentModel.tp_code_account"></el-input>
                </el-form-item>
                <el-form-item label="svn密码" prop="tp_code_pwd">
                    <el-input v-model="currentModel.tp_code_pwd" show-password></el-input>
                </el-form-item>
                <el-form-item label="模版图标">
                    <el-upload
                      class="icon-uploader"
                      action="string"
                      :show-file-list="false"
                      :http-request="handleAvatarUpload"
                      :on-success="handleAvatarSuccess"
                      :before-upload="beforeAvatarUpload">
                      <img v-if="imageUrl" :src="imageUrl" class="icon">
                      <i v-else class="el-icon-plus icon-uploader-icon"></i>
                    </el-upload>
                </el-form-item>
                <el-form-item label="模版描述">
                    <el-input type="textarea" v-model="form.tp_description"></el-input>
                </el-form-item>
            </el-form>
        </el-dialog>
        <el-dialog :visible.sync="dialogModelVisible" :close-on-click-modal="false" class="model-dialog">
            <el-steps :active="stepIndex" simple>
                <el-step title="基本信息" icon="el-icon-edit"></el-step>
                <el-step title="打包脚本" icon="el-icon-upload"></el-step>
            </el-steps>
            <el-form :model="form" label-width="100px" ref="modelForm" :rules="rules" v-if="stepIndex === 1">
                <el-form-item label="模版名称" prop="tp_name">
                    <el-input v-model="form.tp_name"></el-input>
                </el-form-item>
                <el-form-item label="svn路径" prop="tp_code_path">
                    <el-input v-model="form.tp_code_path"></el-input>
                </el-form-item>
                <el-form-item label="svn账号" prop="tp_code_account">
                    <el-input v-model="form.tp_code_account"></el-input>
                </el-form-item>
                <el-form-item label="svn密码" prop="tp_code_pwd">
                    <el-input v-model="form.tp_code_pwd" show-password></el-input>
                </el-form-item>
                <el-form-item label="模版图标">
                    <el-upload
                      class="icon-uploader"
                      action="string"
                      :show-file-list="false"
                      :http-request="handleAvatarUpload"
                      :on-success="handleAvatarSuccess"
                      :before-upload="beforeAvatarUpload">
                      <img v-if="imageUrl" :src="imageUrl" class="icon">
                      <i v-else class="el-icon-plus icon-uploader-icon"></i>
                    </el-upload>
                </el-form-item>
                <el-form-item label="模版描述">
                    <el-input type="textarea" v-model="form.tp_description"></el-input>
                </el-form-item>
            </el-form>
            <el-form :model="form" label-width="100px" ref="scriptForm" :rules="rules" v-if="stepIndex===2">
                <el-form-item label="打包脚本" prop="tp_script">
                    <el-input v-model="form.tp_script" type="textarea" :autosize="{ minRows: 21}" placeholder="请输入打包脚本"></el-input>
                </el-form-item>
            </el-form>
            <div slot="footer" class="dialog-footer">
                <el-button type="primary" @click="prevTab(stepIndex)">{{prevText}}</el-button>
                <el-button type="primary" @click="nextTab(stepIndex)">{{nextText}}</el-button>
            </div>
        </el-dialog>
    </div>
</template>

<script>
import api from '../../api/api'
export default {
    name: 'plugin',
    data () {
        return {
            stepIndex: 1,
            prevText: '取消',
            nextText: '下一步',
            imageUrl: '',
            modelList: [],
            currentModel: '',
            showModelVisible: false,
            dialogModelVisible: false,
            form: {
                tp_name: '',
                tp_code_path: '',
                tp_code_account: '',
                tp_code_pwd: '',
                tp_description: '',
                tp_icon: '',
                tp_script: ''
            },
            rules: {
                tp_name: [
                    {required: true, message: '请输入模版名称', trigger: 'blur'}
                ],
                tp_code_path: [
                    {required: true, message: '请输入SVN路径', trigger: 'blur'}
                ],
                tp_code_account: [
                    {required: true, message: '请输入SVN账号', trigger: 'blur'}
                ],
                tp_code_pwd: [
                    {required: true, message: '请输入SVN密码', trigger: 'blur'}
                ],
                tp_script: [
                    {required: true, message: '请输入打包脚本', trigger: 'blur'}
                ]
            }
        }
    },
    mounted () {
        this.getModelList();
    },
    methods: {
        prevTab (flag) {
            if (flag === 1) {
                this.dialogModelVisible = false;
            } else {
                this.stepIndex = flag - 1;
                this.prevText = "取消";
                this.nextText = "下一步";
            }
        },
        nextTab (flag) {
            if (flag === 1) {
                this.$refs.modelForm.validate((valid) => {
                    if (valid) {
                        this.prevText = "上一步";
                        this.nextText = "新建模版";
                        this.stepIndex = flag + 1;
                    } else {
                        return false;
                    }
                });
            } else {
                this.$refs.scriptForm.validate((valid) => {
                    if (valid) {
                        this.addTemplate()
                    } else {
                        return false;
                    }
                })
            }
        },
        addTemplate () {
            this.$ajax({
                method: 'post',
                url: api.addTemplate,
                data: {
                    tp_name: this.form.tp_name,
                    tp_code_path: this.form.tp_code_path,
                    tp_code_account: this.form.tp_code_account,
                    tp_code_pwd: this.form.tp_code_pwd,
                    tp_description: this.form.tp_description,
                    tp_icon: this.form.tp_icon,
                    tp_script: this.form.tp_script
                }
            }).then((res) => {
                let data = res.data;
                if (data.code == 0) {
                    this.$message({
                        message: '新增模板成功!',
                        type: 'success'
                    });
                    this.getModelList();
                } else {
                    this.$message({
                        message: data.msg,
                        type: 'warning'
                    })
                }
                this.dialogModelVisible = false;
            }).catch((err) => {
                this.$message({
                    message: '新增模板失败!',
                    type: 'error'
                })
                console.log(err);
            })
        },
        handleAvatarUpload (param) {
            const formData = new FormData()
            formData.append('file', param.file)
            this.$ajax({
                method: 'post',
                url: api.uploadFile,
                data: formData
            }).then((res) => {
                param.onSuccess(res);
            }).catch(err => {
                console.log(err);
            })
        },
        handleAvatarSuccess(res, file) {
            this.form.tp_icon = res.data[0].id;
            console.log(this.form.tp_icon);
            this.imageUrl = URL.createObjectURL(file.raw);
        },
        beforeAvatarUpload(file) {
            // const isJPG = file.type === 'image/jpeg';
            const isLt2M = file.size / 1024 / 1024 < 2;

            // if (!isJPG) {
            //     this.$message.error('上传头像图片只能是 JPG 格式!');
            // }
            if (!isLt2M) {
                this.$message.error('上传头像图片大小不能超过 2MB!');
            }
            return isLt2M;
        },
        addModel () {
            this.dialogModelVisible = true;
            this.resetForm();
            this.$nextTick(() => {
                this.$refs.modelForm.clearValidate()
            })
        },
        resetForm () {
            this.stepIndex = 1;
            this.prevText = '取消';
            this.nextText = '下一步';
            this.imageUrl = '';
            this.form = {
                tp_name: '',
                tp_code_path: '',
                tp_code_account: '',
                tp_code_pwd: '',
                tp_description: '',
                tp_icon: '',
                tp_script: ''
            }
        },
        getModelList () {
            this.$ajax({
                method: 'get',
                url: api.modelList,
                params: {
                    pageNum: 20,
                    pageIndex: 1
                }
            }).then(res => {
                if (res.status === 200) {
                    this.modelList = res.data.data.list;
                }
            }).catch(err => {
                this.$message({
                    showClose: true,
                    type: 'error',
                    message: err
                })
                console.log(err);
            })
        },
        choseModel (item) {
            this.currentModel = item;
        }
    }
}
</script>

<style lang="scss" scoped>
.plugin {
    width: 100%;
    height: 100%;
    display: flex;
    flex-direction: row;
    justify-content: flex-start;
    flex-wrap: wrap;
    padding: 30px;
    .model, .addModel {
        position: relative;
        overflow: hidden;
        list-style-type: none;
        width: 200px;
        height: 300px;
        transition: .2s;
        margin: 40px 34px 0 0;
        display: inline-block;
        vertical-align: middle;
        border-radius: 5px;
        border: 1px solid #ccc;
        &:hover {
            cursor: pointer;
        }
        label {
            display: none;
        }
        img {
            width: 110px;
            height: 110px;
            margin: 31px 44px 0px;
        }
        .image {
            background: url("../../assets/demo.jpg");
            display: block;
            width: 320px;
            height: 200px;
            border-radius: 5px 5px 0 0;
            box-shadow: 0 0 3px rgba(0, 0, 0, .2);
            background-repeat: no-repeat;
            background-position: center bottom;
            background-size: cover;
        }
        .content {
            min-height: 145px;
            padding: 15px;
            h1 {
                line-height: 30px;
                font-size: 16px;
                color: #2f394d;
                font-weight: normal;
                margin: 0;
                white-space: nowrap;
                overflow: hidden;
                text-overflow: ellipsis;
                font-size: 20px;
                font-weight: 800;
                text-align: center;
            }
            p {
                color: #6c7685;
                font-size: 15px;
                word-break: break-all;
                overflow: hidden;
                text-overflow: clip;
                width: 100%;
                height: 60px;
                display: -webkit-box;
                -webkit-box-orient: vertical;
                -webkit-line-clamp: 3;
            }
        }
    }
    .addModel {
        background: #409eff;
        color: #fff;
        i {
            transform: scale(6);
            position: relative;
            top: 80px;
            left: 90px;
        }
        .content {
            position: relative;
            top: 115px;
            text-align: center;
            font-size: 20px;
        }
    }
    .el-dialog {
        .el-steps--simple {
            padding: 13px 19%;
        }
        .el-form {
            margin: 30px 36px 0px;
        }
        .dialog-footer {
            text-align: center;
        }
    }
}
</style>
<style>
  .el-dialog {
      width: 760px;
  }
  .icon-uploader .el-upload {
    border: 1px dashed #d9d9d9;
    border-radius: 6px;
    cursor: pointer;
    position: relative;
    overflow: hidden;
  }
  .icon-uploader .el-upload:hover {
    border-color: #409EFF;
  }
  .icon-uploader-icon {
    font-size: 28px;
    color: #8c939d;
    width: 60px;
    height: 60px;
    line-height: 60px;
    text-align: center;
  }
  .icon {
    width: 60px;
    height: 60px;
    display: block;
  }
</style>
