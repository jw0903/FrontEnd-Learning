# 原生组件使用

在hatom框架中，插件是核心的一个模块，它起到了桥接的作用，连接Web端应用红尘呢工序和移动设备两者之间的本地通信，提供了移动设备在不同平台下的能力集，并且是Web端应用程序所不具备的能力，比如移动设备的拍照、相册、定位、监听网络状态等特性，进而更加丰富和扩展了APP功能。
在utils/native目录下，是hatom框架调用原生能力提供的对外接口，接口采用ECMAScript6标准进行，开发者可以采用ES6模块化标准进行引用。native文件夹下以hik-hatom-api-c命名的为基础通用接口，以hik-hatom-api-b命名的为业务定制接口。目前为止提供的接口如下：


### 获取移动端登录信息

 hik-hatom-api-c-rootinfo.js中的getRootInfo函数，用于获取移动端登录信息。

#### 通用参数

| 参数          | 描述          |
| ------------- |:-------------:|
| onSuccess     | 成功回调函数   |
| onFail        | 失败回调函数   |

#### 响应参数

| 参数          | 类型           | 描述        |
| ------------- | -------------- | ---------- |
| res           | String         | 登录信息字符串，可转化JSON对象 |

#### 使用示例

```
getRootInfo(
    res => {
        res = JSON.parse(res); // 返回的res为String字符串，转化为JSON对象
        console.log(res);
        // 以下为res对象包含信息（智能应用平台1.1.0版本），可根据实际要求进行定制返回参数
        {
            address: "https://10.2.145.82", // 平台地址
            deptIndexCode: "d1",            // deptIndexCode
            language: "zh",                 // 国际化语言传参
            realName: "Administrator",      // 用户真实姓名
            routeData: {},                  // 路由参数
            routeType: 0,                   // 路由形式
            token: "···",                   // token
            userIndexCode: admin,           // 用户ID
            username: admin                 // 用户名
        }
    }, // 成功回调函数
    err => {}  // 失败回调函数,做错误处理
)

```

### 获取GPS

 hik-hatom-api-c-geoposition.js文件中的getLocationInfo函数，用于定位，获取当前位置经纬度

#### 通用参数

| 参数          | 描述          |
| ------------- |:-------------:|
| onSuccess     | 成功回调函数   |
| onFail        | 失败回调函数   |

#### 响应参数

| 参数          | 类型           | 描述        |
| ------------- | -------------- | ---------- |
| res           | String         | 经纬度字符串，可转化JSON对象 |

#### 使用示例

```
getLocationInfo(
    res => {
        let pos = JSON.parse(res);
        let longitude = pos.longitude; // 获取经度
        let latitude = pos.latitude;   // 获取纬度
    },
    err => {
        alert(err);
    }
)
```

### 扫描二维码

hik-hatom-api-c-barcodescanner.js文件中的takeBarcodeScannerScan函数，用于调用原生进行二维码扫描

#### 通用参数

| 参数          | 描述          |
| ------------- |:-------------:|
| onSuccess     | 成功回调函数   |
| onFail        | 失败回调函数   |

#### 响应参数

| 参数          | 类型           | 描述        |
| ------------- | -------------- | ---------- |
| res           | String         | 扫描信息，可转化JSON对象 |

#### 使用示例

```
takeBarcodeScannerScan(
    res => {
        // 正常调用原生扫描二维码
        res = JSON.parse(res);
        // 返回信息
        {
            text: "",        // 扫描所获得的信息(文本/链接)
            format: "",      // 所扫描的格式(二维码：QR_CODE)
            cancelled: false // 是否取消扫描
        }
    },
    err => {
        // 错误处理
    }
)
```

### 拍照/上传照片

hik-hatom-api-c-camera.js中有两个方法，一个是调用摄像头进行拍照，一个是调用相册照片,两个方法传参相同

- takeCameraPicture 调用摄像头
- getCameraPicture 打开相册/图库

#### 通用参数
| 参数          | 描述          |
| ------------- |:-------------:|
| onSuccess     | 成功回调函数   |
| onFail        | 失败回调函数   |
| quality       | 代表压缩质量提示(0 - 100:0 =低质量&高压缩,100 = max的压缩质量)|

### 视频预览/视频回放

hik-hatom-api-c-singleReadPlay.js中有两个方法，一个是进行视频预览，一个是进行视频回放

- realPlay 视频预览

#### 通用参数
| 参数          | 描述          |
| ------------- |:-------------:|
| onSuccess     | 成功回调函数   |
| onFail        | 失败回调函数   |
| camerID       | 监控点ID      |
| cameraName    | 监控点名称    |
| isCenter      | 播放窗口是否位于屏幕中间： true为屏幕中间，false为屏幕下方(默认) | 

#### 使用示例
```
realPlay(() => {}, 
        (err) => {
            alert(err);
        },
        camerId,
        videoName,
        false
)
```

- playBack 视频回放

#### 通用参数

| 参数          | 描述          |
| ------------- |:-------------:|
| onSuccess     | 成功回调函数   |
| onFail        | 失败回调函数   |
| camerID       | 监控点ID      |
| frameX        | 坐标系X轴(屏幕左上角为坐标原点)，不传默认为0 |
| frameY        | 坐标系Y轴(屏幕左上角为坐标原点)，不传默认为0 |
| frameY        | 宽度，不传或为0时默认为屏幕宽度 |
| frameY        | 高度，不传或为0时默认为(屏幕宽度 * 3)/4 + 76|

> frameX、frameY、frameW、frameH同时为0时，认为是默认居中模式，frameW需要大于frameH

#### 使用示例

```
playBack( ()=>{}, (error)=>{
            alert(error)
        }, id);
playBack(() => {},
         (err) => {
            alert(err);
         },
         camerId
)
```

### 退出webapp/退回上一级/清楚历史记录/清楚缓存/判断是否是iOS系统

hik-hatom-api-c-apphandle.js中提供了5个方法，退出webapp/退回上一级/清楚历史记录/清楚缓存/判断是否是iOS系统
takeExitApp方法，调用该方法关闭app提供的webView容器，与重新登录方法不同，根据具体情况进行选择使用。

- takeExitApp 调用该方法关闭app提供的webView容器，与重新登录方法不同，根据具体情况进行选择使用

- takeBackHistory 退回上一级
- takeClearHistory 清楚历史记录
- takeClearCache 清楚缓存

#### 通用参数

| 参数          | 描述          |
| ------------- |:-------------:|
| onSuccess     | 成功回调函数   |
| onFail        | 失败回调函数   |

#### 响应参数

上述四个函数均无返回值

#### 使用示例

```
// 以退出webapp举例
takeExitApp(
    () => {
        console.log('success');
    },
    err => {
        alert('fail');
    }
)
```
- isIOSSystem 判断是否iOS系统

#### 通用参数

| 参数          | 描述          |
| ------------- |:-------------:|
| onSuccess     | 成功回调函数   |
| onFail        | 失败回调函数   |

#### 响应参数

| 返回          | 描述          |
| ------------- |:-------------:|
| true          | 是iOS系统      |
| false         | 不是iOS系统    |


### 重新登录

hik-hatom-api-c-rootinfo.js文件中tokenOverDue函数，调用之后回到app登录界面进行重新登录。

#### 通用参数

| 参数          | 描述          |
| ------------- |:-------------:|
| onSuccess     | 成功回调函数   |
| onFail        | 失败回调函数   |

#### 响应参数

无返回值

#### 使用示例

```
tokenOverDue(
    () => {
        console.log('success');
    },
    err => {
        alert('fail');
    }
)
```

### 网络请求

hik-hatom-api-c-net.js中export了netRequest函数用于调用移动端进行发起请求

#### 通用参数

| 参数          | 描述          |
| ------------- |:-------------:|
| obj           | 包含发送请求的各项参数 |

#### 响应参数

| 参数          | 描述          |
| ------------- |:-------------:|
| res           | 返回请求成功后的结果 |

#### 使用示例

```
let obj = {
    url: url,        // 请求接口url
    method: "post",  // 请求方法
    contentType: "application/json;charset=UTF-8",
    postMode: "json",
    data: params,    // 请求接口传参
};
netRequest(obj).then(
    res => {
        // 请求成功，进行数据渲染
    }
).catch(
    err => {
        alert(err);                     
    }
);
```
> 此方法是1.1.0项目请求接口所调用。 其他项目开发可以用axios直接请求，不需要通过插件进行请求，具体请求步骤可参考demo中的数据请求。

### 网络状态获取

hik-hatom-api-c-network.js文件中定义了6个函数，用于不同情况下对移动端网络状态的获取。

#### 通用参数

不需要传参

#### 响应参数

- getNetWorkType 获取网络状态类型，返回网络状态值

| 返回值         | 类型           | 描述       |
| ------------- | -------------- | ---------- |
| UNKNOWN       | String         | 未知连接    |
| ETHERNET      | String         | 以太网连接  |
| WIFI          | String         | WiFi连接    |
| CELL_2G       | String         | 2G 网络     |
| CELL_3G       | String         | 3G 网络     |
| CELL_4G       | String         | 4G 网络     |
| CELL          | String         | 通用链接    |
| NONE          | String         | 没有网络连接 |

- onNetWorkOnLine 在线状态事件监听

```
onNetWorkOnLine(() => {
    // 在线状态事件监听回调函数
})
```

- onNetWorkOffLine 离线状态事件监听

```
onNetWorkOffLine(() => {
    // 离线状态事件监听回调函数
})
```

- isNetWorkStatus 是否有网络

| 返回值         | 类型           | 描述       |
| ------------- | -------------- | ---------- |
| true          | Boolean        | 是         |
| false         | Boolean        | 否         |

- isWifiConnect 是否WIFI连接

| 返回值         | 类型           | 描述       |
| ------------- | -------------- | ---------- |
| true          | Boolean        | 是         |
| false         | Boolean        | 否         |

- isMobileConnect 是否移动网络连接

| 返回值         | 类型           | 描述       |
| ------------- | -------------- | ---------- |
| true          | Boolean        | 是         |
| false         | Boolean        | 否         |
