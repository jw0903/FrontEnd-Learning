# 原生插件开发

在hatom框架中，插件是核心的一个模块，它起到了桥接的作用，连接Web端应用红尘呢工序和移动设备两者之间的本地通信，提供了移动设备在不同平台下的能力集，并且是Web端应用程序所不具备的能力，比如移动设备的拍照、相册、定位、监听网络状态等特性，进而更加丰富和扩展了APP功能。 在utils/native目录下，是hatom框架调用原生能力提供的对外接口，接口采用ECMAScript6标准进行，开发者可以采用ES6模块化标准进行引用。native文件夹下以hik-hatom-api-c命名的为基础通用接口，以hik-hatom-api-b命名的为业务定制接口。

通过插件，web前端可以直接调用手机设备任意硬件能力，甚至通过这些API调用其他native开发的组件和应用。在插件开发的过程中，需要与app端开发者进行沟通具体插件包的名称。主要需要修改四个文件(hatom_plugins/config.xml、hatom_plugins/hatom-js/core/cordova_plugins.js、hatom_plugins/hatom-js/plugins/、utils/native),具体开发步骤如下(以workTypePlugin为例)：

1. 首先需与原生app端(Android/iOS)开发者确认好插件包名，以及插件所需要的传参。

2. 在config.xml中添加插件配置项

```
    // 其中"com.hik.station.plugin.WorkTypePlugin"为插件包名
    // feature中的name为插件包名的最后一个单词
    <feature name="WorkTypePlugin">
        <param name="android-package" value="com.hik.station.plugin.WorkTypePlugin" />
    </feature> 
```

3. 在cordova_plugins.js中配置插件路径配置项

```
{
    "id": "hik-hatom-plugin-c-workTypePlugin.workTypePlugin",
    "file": "../plugins/hik-hatom-plugin-c-workTypePlugin/workTypePlugin.js", // 编写插件的具体文件
    "pluginId": "hik-hatom-plugin-c-workTypePlugin",
    "clobbers": [
        "WorkTypePlugin"
    ]
}
```

4. 在hatom_plugins/hatom-js/plugins/目录新建文件夹hik-hatom-plugin-c-workTypePlugin，并在该文件夹下新建workTypePlugin.js文件，新建文件与第3点中的路径保持一致

5. 编写workTypePlugin.js文件

```
cordova.define("hik-hatom-plugin-c-workTypePlugin.workTypePlugin", function(require, exports, module) {
    var exec = require("cordova/exec");

    function workTypePlugin () {};

    workTypePlugin.prototype.workType = function (
        successCallback, errorCallback, options) {
        // 参数为：成功回调，失败回调，第三个参数与cordova_plugins.js中的对应的clobbers保持一致，options参数
        exec(successCallback, errorCallback, "WorkTypePlugin", options);
    }
    var setworktype = new workTypePlugin();
    module.exports = setworktype;
})
```

6. 在utils/native提供workType访问接口,新建hik-hatom-api-c-workType.js

```
function setWorkType(onSuccess, onFail, action) {
    // WorkTypePlugin与cordova_plugins.js中的对应的clobbers保持一致
    // workType与第5点中的workType名称一致
    WorkTypePlugin.workType(onSuccess, onFail, action);
}

export default {
    setWorkType
}
```

7. 至此，在移动端就可以采用ES6模块化标准引用该方法，进行调用了。