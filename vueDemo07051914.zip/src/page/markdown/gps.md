### 获取GPS

 hik-hatom-api-c-geoposition.js文件中的getLocationInfo函数，用于定位，获取当前位置经纬度

#### 通用参数

| 参数          | 描述          |
| ------------- |:-------------:|
| onSuccess     | 成功回调函数   |
| onFail        | 失败回调函数   |

#### 响应参数

| 参数          | 类型           | 描述        |
| ------------- | -------------- | ---------- |
| res           | String         | 经纬度字符串，可转化JSON对象 |

#### 使用示例

```
getLocationInfo(
    res => {
        let pos = JSON.parse(res);
        let longitude = pos.longitude; // 获取经度
        let latitude = pos.latitude;   // 获取纬度
    },
    err => {
        alert(err);
    }
)
```
