### 拍照/上传照片

hik-hatom-api-c-camera.js中有两个方法，一个是调用摄像头进行拍照，一个是调用相册照片,两个方法传参相同

- takeCameraPicture 调用摄像头
- getCameraPicture 打开相册/图库

#### 通用参数
| 参数          | 描述          |
| ------------- |:-------------:|
| onSuccess     | 成功回调函数   |
| onFail        | 失败回调函数   |
| quality       | 代表压缩质量提示(0 - 100:0 =低质量&高压缩,100 = max的压缩质量)|
