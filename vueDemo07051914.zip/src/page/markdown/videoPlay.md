### 视频预览/视频回放

hik-hatom-api-c-singleReadPlay.js中有两个方法，一个是进行视频预览，一个是进行视频回放

- realPlay 视频预览

#### 通用参数
| 参数          | 描述          |
| ------------- |:-------------:|
| onSuccess     | 成功回调函数   |
| onFail        | 失败回调函数   |
| camerID       | 监控点ID      |
| cameraName    | 监控点名称    |
| isCenter      | 播放窗口是否位于屏幕中间： true为屏幕中间，false为屏幕下方(默认) | 

#### 使用示例
```
realPlay(() => {}, 
        (err) => {
            alert(err);
        },
        camerId,
        videoName,
        false
)
```

- playBack 视频回放

#### 通用参数

| 参数          | 描述          |
| ------------- |:-------------:|
| onSuccess     | 成功回调函数   |
| onFail        | 失败回调函数   |
| camerID       | 监控点ID      |
| frameX        | 坐标系X轴(屏幕左上角为坐标原点)，不传默认为0 |
| frameY        | 坐标系Y轴(屏幕左上角为坐标原点)，不传默认为0 |
| frameY        | 宽度，不传或为0时默认为屏幕宽度 |
| frameY        | 高度，不传或为0时默认为(屏幕宽度 * 3)/4 + 76|

> frameX、frameY、frameW、frameH同时为0时，认为是默认居中模式，frameW需要大于frameH

#### 使用示例

```
playBack( ()=>{}, (error)=>{
            alert(error)
        }, id);
playBack(() => {},
         (err) => {
            alert(err);
         },
         camerId
)
```
