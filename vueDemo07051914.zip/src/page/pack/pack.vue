<template>
    <div class="pack">
        <el-container>
            <el-main>
                <div class="packList">
                    <el-page-header @back="goBack" :content="packTitle">
                    </el-page-header>
                    <el-form ref="form" :model="form" label-width="auto">
                        <el-form-item label="app名称">
                            <el-input placeholder="请输入app名称" v-model="form.appName"></el-input>
                        </el-form-item>
                        <el-form-item label="版本号">
                            <el-input placeholder="请输入版本号" v-model="form.appVersion"></el-input>
                        </el-form-item>
                        <el-form-item label="选择组件">
                            <div class="checkBox" v-for="(item, index) in modelList" :key="index">
                                <el-checkbox v-model="item.checked" :label="item.label" border @change="changeList(item)"></el-checkbox>
                            </div>
                        </el-form-item>
                        <!-- <el-form-item label="app预览">
                            <div class="app-preview">
                                <div class="app-wrapper">
                                    <div class="header">
                                        <img src="../../assets/login-pic.png" class="login-pic" alt="logo图片">
                                        <span class="app-name">{{ form.appName }}</span>
                                    </div>
                                    <div class="appplace" alt="超出部分可以进行滚动">
                                        <div class="appblock" v-for="(item, index) in checkList" :key="index">
                                            <img src="../../assets/appLogo.png" alt="">
                                            <div>{{ item.label }}</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </el-form-item> -->
                        <el-form-item label="模板ID">
                            <el-input placeholder="请输入模板ID" v-model="form.modelID"></el-input>
                        </el-form-item>
                        <el-form-item label="模板名字">
                            <el-input placeholder="请输入模板名字" v-model="form.modelName"></el-input>
                        </el-form-item>
                        <el-form-item label="上传LOGO">
                            <el-upload
                                action="https://jsonplaceholder.typicode.com/posts/"
                                :on-preview="handlePreview"
                                :on-remove="handleRemove"
                                :limit="1"
                                :file-list="fileList">
                                <el-button size="default" type="primary">点击上传</el-button>
                            </el-upload>
                        </el-form-item>
                        <el-form-item>
                            <el-button type="primary" @click="submit">立即创建</el-button>
                            <el-button>取消</el-button>
                        </el-form-item>
                    </el-form>
                </div>
            </el-main>
        </el-container>
        <div class="app-preview1">
            <div class="app-wrapper">
                <div class="header">
                    <img src="../../assets/login-pic.png" class="login-pic" alt="logo图片">
                    <span class="app-name">{{ form.appName }}</span>
                </div>
                <div class="appplace" alt="超出部分可以进行滚动">
                    <div class="appblock" v-for="(item, index) in checkList" :key="index">
                        <img src="../../assets/appLogo.png" alt="">
                        <div>{{ item.label }}</div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
import api from '../../api/api'
export default {
    name: 'pack',
    data () {
        return {
            packTitle: '',
            modelList: [
                {
                    label: "车辆查询",
                    checked: false
                },
                {
                    label: "车辆布控",
                    checked: false
                },
                {
                    label: "以车搜车",
                    checked: false
                },
                {
                    label: "地图模块",
                    checked: false
                },
                {
                    label: "地图模块1",
                    checked: false
                },
                {
                    label: "地图模块2",
                    checked: false
                },
                {
                    label: "地图模块3",
                    checked: false
                },
                {
                    label: "地图模块4",
                    checked: false
                },
                {
                    label: "地图模块5",
                    checked: false
                },
                {
                    label: "车辆布控1",
                    checked: false
                },
                {
                    label: "车辆布控2",
                    checked: false
                },
                {
                    label: "车辆布控4",
                    checked: false
                },
                {
                    label: "车辆布控5",
                    checked: false
                },
                {
                    label: "车辆布控7",
                    checked: false
                },
                {
                    label: "车辆布控8",
                    checked: false
                }
            ],
            checkList: [],
            form: {
                modelID: '',
                modelName: '',
                modelSVNPath: '',
                branchSVNPath: '',
                SVNAccount: '',
                SVNPwd:'',
                modType: '',
                appVersion: '',
                appName: '',
                uploadFile: [
                    {
                        type: '',
                        file: '',
                    }
                ],
                type: [
                ],
                name: '',
                file: '',
                options: []
            },
            fileList:[],
            packFlag: true,
            checked1: false,
        }
    },
    mounted () {
        this.formInit();
        console.log(this.$route.params.item);
    },
    methods: {
        handleChange () {},
        handleEdit () {},
        handleDelete () {},
        handlePreview () {},
        handleRemove (){},
        changeList (item) {
            if (item.checked) {
                this.checkList.push(item);
                // this.$set(this.checkList, 1, item);
            } else {
                this.checkList.forEach((i, index) => {
                    if (item.label === i.label) {
                        this.checkList.splice(index, 1);
                        return;
                    }
                })
            }
        },
        getResType () {
            this.$ajax({
                methos: 'get',
                url: api.resType,
                params: {
                    tp_id: '142'
                }
            }).then((res) => {
                this.form.type = res.data;
            }).catch((err) => {
                console.log(err);
            });
            // this.$ajax({
            //     method: "get",
            //     url: api.modelList,
            //     params: {
            //         pageIndex: 1,
            //         pageNum: 10,      
            //     }
            // }).then((res) => {
            //     console.log(res);
            // })
        },
        formInit () {
            if (this.$route.params.type === 'add') {
                this.packTitle = "新增模板";
            } else {
                this.packTitle = "构架管理";
            }
            this.packFlag = this.$route.params.type === 'pack' ? true : false;
            if (this.packFlag) {
                this.getResType();
            }
        },
        goBack () {
            this.$router.push('packList');
        },
        addUpload () {
            // if (this.form.file === 'fileModify') {
            //     this.form.type.push({
            //         "options":[
            //             '名称',
            //             '包名',
            //             '版本号',
            //             '版本名称'
            //         ]
            //     })
            // } else {
            //     this.form.type.push({
            //         "options":[
            //             '图标',
            //             'H5资源包'
            //         ]
            //     })
            // }
        },
        removeUpload (item) {
            var index = this.form.type.indexOf(item);
            if (index !== -1) {
                this.form.type.splice(index, 1);
            }
        },
        submit () {
            this.$ajax({
                method: 'post',
                url: api.addTemplate,
                data: {
                    tp_id: this.form.modelID,
                    tp_name: this.form.modelName,
                    tp_code_path: this.form.modelSVNPath,
                    tp_branch_path: this.form.branchSVNPath,
                    tp_code_account: this.form.SVNAccount,
                    tp_code_pwd: this.form.SVNPwd
                }
            }).then((res) => {
                let data = res.data;
                if (data.code == 0) {
                    this.$message({
                        message: '新增模板成功!',
                        type: 'success'
                    });
                    this.$route.push('packList');
                } else {
                    this.$message({
                        message: data.msg,
                        type: 'warning'
                    })
                }
                console.log(data);
            }).catch((err) => {
                console.log(err);
            })
        }
    }
}
</script>

<style lang="scss" scoped>
.pack {
    width: 100%;
    height: 100%;
    .el-main {
        .packList {
            width: 100%;
            .checkBox {
                float: left;
                margin: 10px 10px 0px 10px;
            }
            .el-page-header {
                margin-bottom: 40px;
                padding-bottom: 20px;
                border-bottom: 1px solid #dddddda6;
            }
            .upload_file {
                display: flex;
                div {
                    &:nth-child(2) {
                        min-width: 200px;
                        text-align: center;
                        overflow: hidden;
                        text-overflow: ellipsis;
                        ul {
                            list-style: circle;
                        }
                    }
                    &:nth-child(3) {
                        margin-right: 20px;
                    }
                }
                button {
                    max-height: 40px;
                }
            }
            .app-preview {
                // width: 500px;
                // height: 800px;
                // background: #f3f3f3;
                // border: 1px solid #ddd;
                // border-radius: 20px;
                // box-shadow: 0 2px 12px 0 rgba(0,0,0,.1);
                // overflow: hidden;
                // background: url("../../assets/iphoneX.png");
                width: 376px;
                height: 700px;
                background: #f3f3f3;
                overflow: hidden;
                background: url(/static/img/iphoneX.38c8778.png);
                background-repeat: no-repeat;
                background-size: contain;
                .app-wrapper {
                    border: 1px solid #ccc;
                    background: #f7f7f7;
                    width: 311px;
                    position: relative;
                    left: 23px;
                    top: 70px;
                    height: 600px;
                    border-radius: 0px 0px 30px 30px;
                    overflow: hidden;
                    .header {
                        // background: #1d8eff;
                        // height: 160px;
                        // text-align: center;

                        background: #1d8eff;
                        height: 160px;
                        text-align: center;
                        width: 311px;
                        .login-pic {
                            left: -35px;
                            width: 180px;
                            height: 160px;
                            position: relative;
                        }
                        .app-name {
                            color: #fff;
                            position: relative;
                            font-size: 16px;
                            top: -65px;
                        }
                    }
                    .appplace {
                        min-height: 280px;
                        max-height: 360px;
                        overflow-y: scroll;
                        margin-top: 20px;
                        background: #fff;
                        width: 326px;
                        .appblock {
                            // text-align: center;
                            // float: left;
                            // width: 104px;
                            // margin: 30px 10px 0px 10px;

                            text-align: center;
                            float: left;
                            width: 67px;
                            margin: 15px 5px 0px 5px;
                            img {
                                width: 50px;
                                height: 50px;
                            }
                            span {
                                font-size: 10px;
                            }
                        }
                    }
                }
            }
        }
    }
    .app-preview1 {
        // width: 500px;
        // height: 800px;
        // background: #f3f3f3;
        // border: 1px solid #ddd;
        // border-radius: 20px;
        // box-shadow: 0 2px 12px 0 rgba(0,0,0,.1);
        // overflow: hidden;
        // background: url("../../assets/iphoneX.png");
        width: 376px;
        height: 700px;
        background: #f3f3f3;
        overflow: hidden;
        background: url(/static/img/iphoneX.38c8778.png);
        background-repeat: no-repeat;
        background-size: contain;
        position: absolute;
        top: 145px;
        right: 18px;
        .app-wrapper {
            border: 1px solid #ccc;
            background: #f7f7f7;
            width: 311px;
            position: relative;
            left: 23px;
            top: 70px;
            height: 600px;
            border-radius: 0px 0px 30px 30px;
            overflow: hidden;
            .header {
                // background: #1d8eff;
                // height: 160px;
                // text-align: center;

                background: #1d8eff;
                height: 160px;
                text-align: center;
                width: 311px;
                .login-pic {
                    left: -35px;
                    width: 180px;
                    height: 160px;
                    position: relative;
                }
                .app-name {
                    color: #fff;
                    position: relative;
                    font-size: 16px;
                    top: -65px;
                }
            }
            .appplace {
                min-height: 280px;
                max-height: 360px;
                overflow-y: scroll;
                margin-top: 20px;
                background: #fff;
                width: 326px;
                .appblock {
                    // text-align: center;
                    // float: left;
                    // width: 104px;
                    // margin: 30px 10px 0px 10px;

                    text-align: center;
                    float: left;
                    width: 67px;
                    margin: 15px 5px 0px 5px;
                    img {
                        width: 50px;
                        height: 50px;
                    }
                    div {
                        font-size: 10px;
                    }
                }
            }
        }
    }
}
</style>
