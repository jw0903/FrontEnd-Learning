<template>
    <div class="online_pack">
        <el-container>
            <el-aside width="250px">
                <el-menu
                    default-active="1"
                    class="el-menu-vertical-demo"
                    @select="handleSelect"
                    background-color="#fff"
                    active-text-color="#409eff">
                    <el-menu-item index="1">
                        <i class="el-icon-s-release" :class="{'active':isActive==1}"></i>
                        <span>在线打包</span>
                    </el-menu-item>
                    <el-menu-item index="2">
                        <i class="el-icon-menu" :class="{'active':isActive==2}"></i>
                        <span>打包记录</span>
                    </el-menu-item>
                </el-menu>
            </el-aside>
            <el-main>
                <router-view></router-view>
            </el-main>
        </el-container>
    </div>
</template>

<script>
export default {
    name: 'onlinePack',
    data () {
        return {
            isActive: 1
        }
    },
    mounted () {
    },
    methods: {
        handleSelect (index) {
            switch (index) {
                case '1':
                    this.isActive = 1;
                    this.$router.push('packList');
                    break;
                case '2':
                    this.isActive = 2;
                    this.$router.push('packHistory');
                    break;
                default: 
                    break;
            }
        }
    }
}
</script>

<style lang="scss" scoped>
.online_pack {
    width: 100%;
    height: 100%;
    .el-container {
        height: 100%;
        .el-aside {
            height: 100%;
            height: 100%;
            border-right: 1px solid #ccc;
            padding-top: 20px;
            background: #fff;
            position: fixed;
            .el-menu-vertical-demo {
                border-right: none;
                .el-menu-item {
                    &:hover {
                        background-color: rgb(255, 255, 255) !important;
                        color: #409EFF;
                    }
                }
            }
        }
        .el-main {
            margin-left: 250px;
            overflow: inherit;
        }
    }
}
</style>

