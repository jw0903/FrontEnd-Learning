<template>
    <div class="pack">
        <el-container>
            <el-main>
                <div class="packList">
                    <el-page-header @back="goBack" :content="packTitle">
                    </el-page-header>
                    <el-form ref="form" :model="form" label-width="auto">
                        <el-form-item label="模板名称">
                            <el-input placeholder="请输入模板名称" v-model="form.modelName" :disabled="true"></el-input>
                        </el-form-item>
                        <el-form-item label="模板SVN路径">
                            <el-input placeholder="请输入模板SVN路径" v-model="form.modelSVNPath" :disabled="true"></el-input>
                        </el-form-item>
                        <el-form-item label="分支SVN路径">
                            <el-input placeholder="请输入分支SVN路径" v-model="form.branchSVNPath"></el-input>
                        </el-form-item>
                        <el-form-item label="分支SVN账号">
                            <el-input placeholder="请输入分支SVN账号" v-model="form.SVNAccount"></el-input>
                        </el-form-item>
                        <el-form-item label="SVN密码">
                            <el-input placeholder="请输入密码" v-model="form.SVNPwd" show-password></el-input>
                        </el-form-item>
                        <el-form-item v-for="(item, index) in form.modList" :label="item.label" :key="index">
                            <el-input :placeholder="'请修改'+item.label"></el-input>
                        </el-form-item>
                        <el-form-item label="上传列表" v-if="form.cpList.length !== 0">
                            <el-upload
                                :before-upload="beforeUpload"
                                :action="uploadurl"
                                drag
                                list-type="picture-card"
                                :limit="form.cpList.length"
                                :on-exceed="handleExceed"
                                :on-preview="handlePictureCardPreview"
                                :on-remove="handleRemove">
                                <i class="el-icon-plus"></i>
                            </el-upload>
                            <el-dialog :visible.sync="dialogVisible">
                                <img width="100%" :src="dialogImageUrl" alt="">
                            </el-dialog>
                        </el-form-item>
                        <el-form-item v-for="item in form.outPathList" :label="item.label" :key="item.value">
                            <el-input :placeholder="'请修改'+item.label"></el-input>
                        </el-form-item>
                        <el-form-item>
                            <el-button type="primary" @click="submit">立即创建</el-button>
                            <el-button>取消</el-button>
                        </el-form-item>
                    </el-form>
                </div>
            </el-main>
        </el-container>
    </div>
</template>

<script>
import api from '../../api/api'
export default {
    name: 'packdemo',
    data () {
        return {
            packTitle: '',
            form: {
                modelName: '',
                modelSVNPath: '',
                branchSVNPath: '',
                SVNAccount: '',
                SVNPwd:'',
                modList: [],
                cpList: [],
                outPathList: []
            },
            fileList:[],
            packFlag: true,
            dialogImageUrl: '',
            dialogVisible: false,
            uploadurl: ''
        }
    },
    mounted () {
        this.formInit();
        this.uploadurl = api.uploadFile;
    },
    methods: {
        beforeUpload (file) {
            const fileTypeName = (file.name).substring(file.name.lastIndexOf('.')*1 + 1*1);
            const imageFormat = ['jpg', 'png', 'gif', 'JPEG'];
            console.log(fileTypeName);
            console.log(imageFormat);
            if (imageFormat.indexOf(fileTypeName) === -1) {
                this.$message.warning('上传图片格式不正确，请重新上传');
                return false;
            }
        },
        handleExceed () {
            console.log('超过上传上限');
        },
        handleRemove(file, fileList) {
            console.log(file, fileList);
        },
        handlePictureCardPreview(file) {
            this.dialogImageUrl = file.url;
            this.dialogVisible = true;
        },
        getResType (id) {
            this.$ajax({
                methos: 'get',
                url: api.resType,
                params: {
                    tp_id: id
                }
            }).then((res) => {
                res.data.forEach((item) => {
                    if (item.value === 'mod') {
                        if (item.children && item.children.length !== 0) {
                            let itemChild = item.children;
                            itemChild.forEach((modItem) => {
                                this.form.modList.push(modItem);
                            })
                        }
                    } else if (item.value === 'cp') {
                        if (item.children && item.children.length !== 0) {
                            let itemChild = item.children;
                            itemChild.forEach((cpItem) => {
                                this.form.cpList.push(cpItem);
                            })
                        }
                    } else {
                        if (item.children && item.children.length !== 0) {
                            let itemChild = item.children;
                            itemChild.forEach((outPathItem) => {
                                this.form.outPathList.push(outPathItem);
                            })
                        }
                    }
                })
                console.log(this.form.cpList.length);
            }).catch((err) => {
                console.log(err);
            });
        },
        formInit () {
            this.packTitle = "在线打包";
            let item = this.$route.params.item;
            this.form.modelName = item.tp_name;
            this.form.modelSVNPath = item.tp_code_path;
            this.getResType(item.tp_id);
        },
        goBack () {
            this.$router.push('packList');
        },
        addUpload () {
            if (this.form.file === 'fileModify') {
                this.form.type.push({
                    "options":[
                        '名称',
                        '包名',
                        '版本号',
                        '版本名称'
                    ]
                })
            } else {
                this.form.type.push({
                    "options":[
                        '图标',
                        'H5资源包'
                    ]
                })
            }
        },
        removeUpload (item) {
            var index = this.form.type.indexOf(item);
            if (index !== -1) {
                this.form.type.splice(index, 1);
            }
        },
        submit () {
            this.$ajax({
                method: 'post',
                url: api.addTemplate,
                data: {
                    tp_id: '142',
                    tp_name: '智能应用2平2台1',
                    tp_code_path: this.form.modelSVNPath,
                    tp_branch_path: this.form.branchSVNPath,
                    tp_code_account: this.form.SVNAccount,
                    tp_code_pwd: this.form.SVNPwd
                }
            }).then((res) => {
                let data = res.data;
                if (data.code == 0) {
                    this.$message({
                        message: '新增模板成功!',
                        type: 'success'
                    });
                    this.$route.push('packList');
                } else {
                    this.$message({
                        message: data.msg,
                        type: 'warning'
                    })
                }
            }).catch((err) => {
                this.$message({
                    message: '新增模板失败!',
                    type: 'fail'
                })
                console.log(err);
            })
        }
    }
}
</script>

<style lang="scss" scoped>
.pack {
    width: 100%;
    height: 100%;
    .el-main {
        .packList {
            width: 100%;
            .el-page-header {
                margin-bottom: 40px;
                padding-bottom: 20px;
                border-bottom: 1px solid #dddddda6;
            }
        }
    }
}
</style>
<style>
.el-upload-dragger {
    width: 148px;
    height: 148px;
}
</style>

