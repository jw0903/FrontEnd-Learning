<template>
    <header>
        <span @click="changeRoute(0)" class="logo"></span>
        <div class="nav">
            <div @click="changeRoute(1)">开发教程</div>
            <div @click="changeRoute(2)">在线打包</div>
            <div @click="changeRoute(3)">案例</div>
            <div @click="changeRoute(4)">模板管理</div>
        </div>
        <div class="personal" @click="changeRoute(5)">登录</div>
    </header>
</template>

<script>
export default {
    name: 'Hheader',
    data () {
        return {

        }
    },
    methods: {
        changeRoute (route) {
            switch (route) {
                case 0:
                    this.$router.push('/index')
                    break
                case 1:
                    this.$router.push('/devGuide')
                    break
                case 2:
                    this.$router.push('/onlinePack')
                    break
                case 3:
                    this.$router.push('/case')
                    break
                case 4:
                    this.$router.push('/plugin')
                    break
                case 5:
                    this.$router.push('/personal')
                    break
                default:
                    break
            }
        }
    }
}
</script>

<style lang="scss" scoped>
header {
    // background: #545c64;
    width: 100%;
    height: 60px;
    line-height: 60px;
    color: #409eff;
    display: flex;
    justify-content: space-around;
    font-size: 18px;
    .logo {
        background: url('../assets/logo1.png');
        background-size: 125px;
        background-repeat: no-repeat;
        background-position: 5px;
    }
    span {
        cursor: pointer;
        display: inline-block;
        min-width: 250px;
        text-align: center;
        font-size: 35px;
        font-weight: 800;
        color: #409eff;
        text-shadow: -2px -2px #fff, 2px 2px #777;
    }
    .nav {
        display: flex;
        justify-content: flex-start;
        width: 80%;
        div {
            margin-right: 50px;
            cursor: pointer;
            &:hover {
                color: #1989fa;
            }
        }
    }
    .personal {
        cursor: pointer;
        margin: 0 50px;
        min-width: 100px;
        text-align: center;
    }
}
</style>
