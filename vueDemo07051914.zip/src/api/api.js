const getModelList = 'http://10.19.171.20:8899/mock/5d00dc9ef6f049295807e948/hat/modelList'

const uploadFile = '/file/v1.0/uploadFiles'
const addTemplate = '/template/manager/create_template'
const resType = '/template/manager/get_resource_type'
const modelList = '/template/manager/get_template_list'
const build = '/template/manager/build'
const getLog = '/template/manager/replaceHolder/console'

export default {
    getModelList,
    uploadFile,
    addTemplate,
    resType,
    modelList,
    build,
    getLog
}