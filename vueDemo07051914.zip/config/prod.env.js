'use strict'
module.exports = {
  NODE_ENV: '"production"',
  HOST: '"http://10.22.83.136:5000"'
}
