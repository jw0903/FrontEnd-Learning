const getModelList = "http://10.19.171.20:8899/mock/5d00dc9ef6f049295807e948/hat/modelList";

const uploadFile = "/api/file/v1.0/uploadFiles";
const addTemplate = "/api/template/manager/create_template";
const resType = "/api/template/manager/get_resource_type";
const modelList = "api/template/manager/get_template_list";


export default {
    getModelList,
    uploadFile,
    addTemplate,
    resType,
    modelList
}