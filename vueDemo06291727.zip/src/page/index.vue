<template>
    <div class="case">
        <div class="cards">
            <ul class="container">
                <li>
                    <div class="card">
                        <img src="../assets/assemble.png" alt="">
                        <h3>指南</h3>
                        <p>操作指南</p>
                        <a href="">查看详情</a>
                    </div>
                </li>
                <li>
                    <div class="card">
                        <img src="../assets/guide.png" alt="">
                        <h3>指南</h3>
                        <p>操作指南</p>
                        <a href="">查看详情</a>
                    </div>
                </li>
                <li>
                    <div class="card">
                        <img src="../assets/template.png" alt="">
                        <h3>指南</h3>
                        <p>操作指南</p>
                        <a href="">查看详情</a>
                    </div>
                </li>
                <li>
                    <div class="card">
                        <img src="../assets/case.png" alt="">
                        <h3>指南</h3>
                        <p>操作指南</p>
                        <a href="">查看详情</a>
                    </div>
                </li>
            </ul>
        </div>
    </div>
</template>

<script>
export default {
    name: 'index',
    data () {
        return {}
    }
}
</script>

<style lang="scss" scoped>
.case {
    width: 100%;
    .cards {
        width: 100%;
        max-width: 1140px;
        margin: 0 auto;
        .container {
            width: auto;
            padding: 0;
            li {
                width: 25%;
                padding: 0 19px;
                box-sizing: border-box;
                float: left;
                list-style: none;
                .card {
                    height: 430px;
                    width: 100%;
                    background: #fff;
                    border: 1px solid #eaeefb;
                    border-radius: 5px;
                    box-sizing: border-box;
                    text-align: center;
                    position: relative;
                    transition: all .3s ease-in-out;
                    bottom: 0;
                    &:hover {
                        bottom: 6px;
                        box-shadow: 0 6px 18px 0 rgba(232,237,250,.5);
                    }
                    img {
                        width: 160px;
                        height: 120px;
                        margin: 66px auto 60px;
                    }
                    h3 {
                        margin: 0;
                        font-size: 18px;
                        color: #1f2f3d;
                        font-weight: 400;
                    }
                    p {
                        font-size: 14px;
                        color: #99a9bf;
                        padding: 0 25px;
                        line-height: 20px;
                    }
                    a {
                        height: 53px;
                        line-height: 52px;
                        font-size: 14px;
                        color: #409eff;
                        text-align: center;
                        border: 0;
                        border-top: 1px solid #eaeefb;
                        padding: 0;
                        cursor: pointer;
                        width: 100%;
                        position: absolute;
                        bottom: 0;
                        left: 0;
                        background-color: #fff;
                        border-radius: 0 0 5px 5px;
                        transition: all .3s;
                        text-decoration: none;
                        display: block;
                        &:hover {
                            color: #fff;
                            background: #409eff;
                        }
                    }
                }
            }
        }
    }
}
</style>
