<template>
    <div class="online_pack">
        <el-container>
            <el-aside width="250px">
                <el-menu
                    default-active="1"
                    class="el-menu-vertical-demo"
                    @select="handleSelect"
                    background-color="#fff"
                    active-text-color="#409eff">
                    <el-menu-item index="1">
                        <i class="el-icon-location"></i>
                        <span>在线打包</span>
                    </el-menu-item>
                    <el-menu-item index="2">
                        <i class="el-icon-menu"></i>
                        <span>打包记录</span>
                    </el-menu-item>
                </el-menu>
            </el-aside>
            <el-main>
                <router-view></router-view>
            </el-main>
        </el-container>
    </div>
</template>

<script>
export default {
    name: 'onlinePack',
    data () {
        return {
        }
    },
    mounted () {
    },
    methods: {
        handleSelect (index) {
            switch (index) {
                case '1':
                    this.$router.push('packList');
                    break;
                case '2':
                    this.$router.push('packHistory');
                    break;
                default: 
                    break;
            }
        }
    }
}
</script>

<style lang="scss" scoped>
.online_pack {
    width: 100%;
    height: 100%;
    .el-container {
        height: 100%;
        .el-aside {
            height: 100%;
            height: 100%;
            border-right: 1px solid #ccc;
            padding-top: 20px;
            position: fixed;
            .el-menu {
                border-right: none;
            }
        }
        .el-main {
            margin-left: 250px;
            overflow: inherit;
        }
    }
}
</style>
<style>
.el-menu-item:hover {
    background: #fff !important;
}
</style>

