<template>
    <div class="addPackModel">
        <el-container>
            <el-main>
                <div class="packList" v-if="showPack">
                    <el-page-header @back="goBack" content="在线打包">
                    </el-page-header>
                    <el-form ref="form" :model="form" label-width="auto">
                        <el-form-item label="模板SVN路径">
                            <el-input placeholder="请输入模板SVN路径" v-model="form.modelSVNPath"></el-input>
                        </el-form-item>
                        <el-form-item label="分支SVN路径">
                            <el-input placeholder="请输入分支SVN路径" v-model="form.branchSVNPath"></el-input>
                        </el-form-item>
                        <el-form-item label="SVN账号">
                            <el-input placeholder="请输入账号" v-model="form.SVNAccount"></el-input>
                        </el-form-item>
                        <el-form-item label="SVN密码">
                            <el-input placeholder="请输入密码" v-model="form.SVNPwd" show-password></el-input>
                        </el-form-item>
                        <el-form-item
                            label="上传/修改资源"
                            v-for="(domain, index) in form.type"
                            :key="index"
                        >
                            <div class="upload_file">
                                <el-cascader
                                    v-model="form.modType"
                                    :options="form.options"
                                    @change="handleChange"></el-cascader>
                                <el-upload
                                    :action="uploadUrl"
                                    :on-preview="handlePreview"
                                    :on-remove="handleRemove"
                                    :limit="1"
                                    :file-list="fileList">
                                    <el-button size="default" type="primary">点击上传</el-button>
                                </el-upload>
                                <el-input width="180" placeholder="输入编号"></el-input>
                                <el-button @click.prevent="removeUpload(domain)" type="danger" icon="el-icon-delete"></el-button>
                            </div>
                        </el-form-item>
                        <el-form-item>
                            <el-button @click="addUpload" icon="el-icon-plus"></el-button>
                        </el-form-item>
                        <el-form-item>
                            <el-button type="primary" @click="submit">立即创建</el-button>
                            <el-button>取消</el-button>
                        </el-form-item>
                    </el-form>
                </div>
            </el-main>
        </el-container>
    </div>
</template>

<script>
import api from '../../api/api.js';
export default {
    name: 'addPackModel',
    data () {
        return {
            modelList: [],
            historyList: [],
            showModel: false,
            showHistory: false,
            showPack: true,
            form: {
                modelSVNPath: '',
                branchSVNPath: '',
                SVNAccount: '',
                SVNPwd:'',
                modType: '',
                uploadFile: [
                    {
                        type: '',
                        file: '',
                    }
                ],
                name: '',
                file: '',
                options: [
                    {
                        label: "文件修改",
                        value: "fileMod",
                        children: [
                            {
                                label: '名称',
                                value: 'name',
                            },
                            {
                                label: '包名',
                                value: 'packageName',
                            },
                            {
                                label: '版本号',
                                value: 'version',
                            }
                        ]
                    },
                    {
                        label: "文件替换",
                        value: "fileChange",
                        children: [
                            {
                                label: "LOGO",
                                value: "logo",
                            },
                            {
                                label: "H5资源包",
                                value: "zip",
                            }
                        ]
                    }
                ],
                type: [{
                    options: ['图标', 'H5资源包'],
                }],
            },
            options: [
                '图标',
                'H5资源包'
            ],
            fileList:[],
            uploadUrl: ''
        }
    },
    mounted () {
        this.uploadUrl = api.uploadFile;
    },
    methods: {
        handleChange () {},
        handleEdit () {},
        handleDelete () {},
        handlePreview () {

        },
        handleRemove (){},
        goBack () {
            this.$router.push('packList');
        },
        addUpload () {
            if (this.form.file === 'fileModify') {
                this.form.type.push({
                    "options":[
                        '名称',
                        '包名',
                        '版本号',
                        '版本名称'
                    ]
                })
            } else {
                this.form.type.push({
                    "options":[
                        '图标',
                        'H5资源包'
                    ]
                })
            }
        },
        removeUpload (item) {
            var index = this.form.type.indexOf(item);
            if (index !== -1) {
                this.form.type.splice(index, 1);
            }
        },
        submit () {
            console.log('---------------')
            for(let i in this.form) {
                console.log(i + " : " + this.form[i]);
            }
            console.log('---------------')
        }
    }
}
</script>

<style lang="scss" scoped>
.addPackModel {
    width: 100%;
    height: 100%;
    .el-main {
        .packList {
            width: 100%;
            .el-page-header {
                margin-bottom: 40px;
                padding-bottom: 20px;
                border-bottom: 1px solid #dddddda6;
            }
            .upload_file {
                display: flex;
                div {
                    &:nth-child(2) {
                        min-width: 200px;
                        text-align: center;
                        overflow: hidden;
                        text-overflow: ellipsis;
                        ul {
                            list-style: circle;
                        }
                    }
                    &:nth-child(3) {
                        margin-right: 20px;
                    }
                }
                button {
                    max-height: 40px;
                }
            }
        }
    }
}
</style>
