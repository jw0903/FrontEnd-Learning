<template>
    <div class="pack_list">
        <el-container>
            <el-main>
                <el-steps :active="tabIndex" simple>
                    <el-step title="打包模板" icon="el-icon-edit"></el-step>
                    <el-step title="上传前端包" icon="el-icon-upload"></el-step>
                    <el-step title="修改app" icon="el-icon-picture"></el-step>
                    <el-step title="打包" icon="el-icon-picture"></el-step>
                </el-steps>                
                <div class="modelList" v-if="tabIndex === 0">
                    <li v-for="(item, index) in modelList" :key="index" class="model" @click="choseModel(item)">
                        <label :class="{active:item.isActive}"><i class="el-icon-check"></i></label>
                        <img src="../../assets/demo.jpg" alt="">
                        <div class="content">
                            <h1>{{item.tp_name}}</h1>
                            <p>{{item.packDesc}}</p>
                        </div>
                    </li>
                </div>
                <div class="uploadList" v-if="tabIndex === 1">
                    <li v-for="(item, index) in appList" :key="index">
                        <!-- <el-upload
                            class="upload-demo"
                            drag
                            action="https://jsonplaceholder.typicode.com/posts/"
                            multiple>
                            <i class="el-icon-upload"></i>
                            <div class="el-upload__text">将文件拖到此处，或<em>点击上传</em></div>
                        </el-upload> -->
                        <el-upload
                            class="avatar-uploader"
                            action="/api/file/v1.0/uploadFiles"
                            drag
                            :show-file-list="false"
                            :on-success="(response, file)=>handleAvatarSuccess(response, file, index)"
                            :before-upload="beforeAvatarUpload">
                            <div v-show="item.isUpload === true">
                                <i class="el-icon-folder-checked"></i>
                                <span>上传成功</span>
                            </div>
                            <div v-show="item.isUpload === false">
                                <span>上传{{item.label}}包</span>
                                <i class="el-icon-upload avatar-uploader-icon"></i>
                                <div class="el-upload__text">将文件拖到此处，或<em>点击上传</em></div>
                            </div>
                            <!-- <img v-if="imageUrl" :src="imageUrl" class="avatar"> -->
                        </el-upload>
                        <!-- <el-dialog :visible.sync="dialogVisible">
                            <img width="100%" :src="dialogImageUrl" alt="">
                        </el-dialog> -->
                    </li>
                </div>
                <div class="modList" v-if="tabIndex === 2">
                    <li v-for="(item, index) in modList" :key="index" class="mod">
                        <h4>修改{{item.label}}</h4>
                        <el-input
                            type="mini"
                            :placeholder="item.label"
                            v-model="item.value"
                            clearable>
                        </el-input>
                        <span>样例{{item.label}}</span>
                    </li>
                    <!-- <li v-for="(item, index) in modList" :key="index" class="mod" @click="choseModel()">
                        <label :class="{active:item.isActive}"><i class="el-icon-check"></i></label>
                        <img src="../../assets/demo.jpg" alt="">
                        <div class="content">
                            <h1>{{item.tp_name}}</h1>
                            <p>{{item.packDesc}}</p>
                        </div>
                    </li> -->
                </div>
                <div class="footer">
                    <el-button type="primary" :disabled="tabIndex === 0" @click="prevTab(tabIndex)">上一步</el-button>
                    <el-button type="primary" :disabled="tabIndex === 3 "@click="nextTab(tabIndex)">下一步</el-button>
                </div>
            </el-main>
        </el-container>
    </div>
</template>

<script>
import api from "../../api/api.js";
export default {
    name: 'packList',
    data () {
        return {
            imageUrl: '',
            modelList: [],
            tabIndex: 0,
            currModel: '',
            cpList: [],
            appList: [],
            modList: [],
            outPathList: []
        }
    },
    mounted () {
        this.getModel();
    },
    methods: {
        handleAvatarSuccess(res, file, index) {
            let obj = this.appList[index];
            obj.isUpload = true;
            this.$set(this.appList, index, obj);
            this.appList[index].isUpload = true;
            this.imageUrl = URL.createObjectURL(file.raw);
        },
        beforeAvatarUpload(file) {
            const isLt2M = file.size / 1024 / 1024 < 2;
            if (!isLt2M) {
            this.$message.error('上传头像图片大小不能超过 2MB!');
            }
            return isLt2M;
        },
        getModel () {
            this.$ajax({
                method: 'get',
                url: api.modelList,
                params: {
                    pageNum: 20,
                    pageIndex: 1
                }
            }).then((res) => {
                let list = res.data.data.list;
                list.forEach((item) => {
                    item.isActive = false;
                })
                this.modelList = list;
            }).catch((err) => {
                console.log(err);
            })
        },
        choseModel (item) {
            if (item.isActive) {
                item.isActive = false;
                this.currModel = '';
                return;
            } else {
                this.modelList.forEach(i => {
                    if (i.tp_id !== item.tp_id) {
                        i.isActive = false;
                    }
                })
                item.isActive = true;
                this.currModel = item;
            }
        },
        removeUpload (item) {
            var index = this.form.type.indexOf(item);
            if (index !== -1) {
                this.form.type.splice(index, 1);
            }
        },
        getResType (ty_id) {
            this.$ajax({
                methos: 'get',
                url: api.resType,
                params: {
                    tp_id: ty_id
                }
            }).then((res) => {
                if (res.status == 200) {
                    res.data.forEach(item => {
                        if (item.label === 'cp') {
                            this.cpList = item.children;
                            this.cpList.forEach(i => {
                                if (i.label.indexOf('icon') === -1) {
                                    i.isUpload = false;
                                    this.appList.push(i);
                                }
                            })
                        } else if (item.label === 'mod') {
                            this.modList = item.children;
                        } else {
                            this.outPathList = item.children;
                        }
                    })
                }
            }).catch((err) => {
                console.log(err);
            });
        },
        nextTab (index) {
            switch (index) {
                case 0:
                    if (!this.currModel) {
                        this.$message({
                            message: "请选择一个模板",
                            type: 'warning'
                        });
                    } else {
                        this.tabIndex = index + 1;
                        this.getResType(this.currModel.tp_id);
                    }
                    break;
                case 1: 
                    this.tabIndex++;
                    break;
                case 2: 
                    this.tabIndex++;
                    break;
            }
        },
        prevTab (index) {
            this.tabIndex = index - 1;
        }
    }
}
</script>

<style lang="scss" scoped>
.pack_list {
    width: 100%;
    height: 100%;
    .el-main {
        .modelList {
            display: flex;
            flex-direction: row;
            justify-content: flex-start;
            flex-wrap: wrap;
            padding-left: 45px;
            .model {
                position: relative;
                overflow: hidden;
                list-style-type: none;
                width: 200px;
                min-height: 300px;
                transition: .2s;
                margin: 40px 34px 0 0;
                display: inline-block;
                vertical-align: middle;
                border-radius: 5px;
                border: 1px solid #ccc;
                label {
                    display: none;
                }
                .active {
                    background: #13ce66;
                    width: 40px;
                    height: 40px;
                    display: block;
                    position: absolute;
                    top: -20px;
                    left: 180px;
                    transform: rotate(45deg);
                    .el-icon-check {
                        position: relative;
                        top: 22px;
                        right: -10px;
                        transform: rotate(-45deg);
                        color: #fff;
                    }
                }
                img {
                    width: 200px;
                    height: 100px;
                }
                .image {
                    background: url("../../assets/demo.jpg");
                    display: block;
                    width: 320px;
                    height: 200px;
                    border-radius: 5px 5px 0 0;
                    box-shadow: 0 0 3px rgba(0, 0, 0, .2);
                    background-repeat: no-repeat;
                    background-position: center bottom;
                    background-size: cover;
                }
                .content {
                    min-height: 145px;
                    padding: 15px;
                    h1 {
                        line-height: 30px;
                        font-size: 16px;
                        color: #2f394d;
                        font-weight: normal;
                        margin: 0;
                        white-space: nowrap;
                        overflow: hidden;
                        text-overflow: ellipsis;
                        font-size: 20px;
                    }
                    p {
                        color: #6c7685;
                        font-size: 15px;
                        margin: 7px 0 0;
                    }
                }
            }
        }
        .uploadList, .modList{
            li {
                display: inline-block;
                margin: 10px;
                list-style-type: none;
            }
        }
        .modList {
            li {
                height: 220px;
                width: 180px;
                padding: 0 15px;
                text-align: center;
                border: 1px dashed #d9d9d9;
                border-radius: 6px;
            }
        }
        .footer {
            clear: both;
            width: 185px;
            margin: 20px auto;
        }
    }
}
</style>
<style>
  .avatar-uploader .el-upload {
    width: 180px;
    height: 220px;
    border: 1px dashed #d9d9d9;
    border-radius: 6px;
    cursor: pointer;
    position: relative;
    overflow: hidden;
  }
  .el-upload-dragger {
    width: 180px;
    height: 220px;
  }
  .avatar-uploader .el-upload:hover {
    border-color: #409EFF;
  }
  .avatar-uploader-icon {
    font-size: 28px;
    color: #8c939d;
    width: 180px;
    height: 70px;
    text-align: center;
  }
  /* .avatar {
    width: 178px;
    height: 178px;
    display: block;
  } */
</style>
