### 获取移动端登录信息

 hik-hatom-api-c-rootinfo.js中的getRootInfo函数，用于获取移动端登录信息。

#### 通用参数

| 参数          | 描述          |
| ------------- |:-------------:|
| onSuccess     | 成功回调函数   |
| onFail        | 失败回调函数   |

#### 响应参数

| 参数          | 类型           | 描述        |
| ------------- | -------------- | ---------- |
| res           | String         | 登录信息字符串，可转化JSON对象 |

#### 使用示例

```
getRootInfo(
    res => {
        res = JSON.parse(res); // 返回的res为String字符串，转化为JSON对象
        console.log(res);
        // 以下为res对象包含信息（智能应用平台1.1.0版本），可根据实际要求进行定制返回参数
        {
            address: "https://10.2.145.82", // 平台地址
            deptIndexCode: "d1",            // deptIndexCode
            language: "zh",                 // 国际化语言传参
            realName: "Administrator",      // 用户真实姓名
            routeData: {},                  // 路由参数
            routeType: 0,                   // 路由形式
            token: "···",                   // token
            userIndexCode: admin,           // 用户ID
            username: admin                 // 用户名
        }
    }, // 成功回调函数
    err => {}  // 失败回调函数,做错误处理
)

```

### 重新登录

hik-hatom-api-c-rootinfo.js文件中tokenOverDue函数，调用之后回到app登录界面进行重新登录。

#### 通用参数

| 参数          | 描述          |
| ------------- |:-------------:|
| onSuccess     | 成功回调函数   |
| onFail        | 失败回调函数   |

#### 响应参数

无返回值

#### 使用示例

```
tokenOverDue(
    () => {
        console.log('success');
    },
    err => {
        alert('fail');
    }
)
```
