### 退出webapp/退回上一级/清楚历史记录/清楚缓存/判断是否是iOS系统

hik-hatom-api-c-apphandle.js中提供了5个方法，退出webapp/退回上一级/清楚历史记录/清楚缓存/判断是否是iOS系统
takeExitApp方法，调用该方法关闭app提供的webView容器，与重新登录方法不同，根据具体情况进行选择使用。

- takeExitApp 调用该方法关闭app提供的webView容器，与重新登录方法不同，根据具体情况进行选择使用

- takeBackHistory 退回上一级
- takeClearHistory 清楚历史记录
- takeClearCache 清楚缓存

#### 通用参数

| 参数          | 描述          |
| ------------- |:-------------:|
| onSuccess     | 成功回调函数   |
| onFail        | 失败回调函数   |

#### 响应参数

上述四个函数均无返回值

#### 使用示例

```
// 以退出webapp举例
takeExitApp(
    () => {
        console.log('success');
    },
    err => {
        alert('fail');
    }
)
```
- isIOSSystem 判断是否iOS系统

#### 通用参数

| 参数          | 描述          |
| ------------- |:-------------:|
| onSuccess     | 成功回调函数   |
| onFail        | 失败回调函数   |

#### 响应参数

| 返回          | 描述          |
| ------------- |:-------------:|
| true          | 是iOS系统      |
| false         | 不是iOS系统    |
