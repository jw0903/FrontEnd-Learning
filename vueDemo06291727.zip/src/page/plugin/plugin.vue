<template>
    <div class="plugin">
        <el-container>
            <el-main>
                <div class="packList">
                    <el-page-header @back="goBack" :content="packTitle">
                    </el-page-header>
                    <el-form ref="form" :model="form" label-width="auto">
                        <el-form-item label="模板SVN路径">
                            <el-input placeholder="请输入模板SVN路径" v-model="form.modelSVNPath"></el-input>
                        </el-form-item>
                        <el-form-item label="分支SVN路径">
                            <el-input placeholder="请输入分支SVN路径" v-model="form.branchSVNPath"></el-input>
                        </el-form-item>
                        <el-form-item label="SVN账号">
                            <el-input placeholder="请输入账号" v-model="form.SVNAccount"></el-input>
                        </el-form-item>
                        <el-form-item label="SVN密码">
                            <el-input placeholder="请输入密码" v-model="form.SVNPwd" show-password></el-input>
                        </el-form-item>
                        <el-form-item
                            label="上传/修改资源"
                            v-for="(domain, index) in form.type"
                            :key="index"
                        >
                            <div class="upload_file">
                                <el-cascader
                                    v-model="form.modType"
                                    :options="form.options"
                                    @change="handleChange"></el-cascader>
                                <el-upload
                                    action="https://jsonplaceholder.typicode.com/posts/"
                                    :on-preview="handlePreview"
                                    :on-remove="handleRemove"
                                    :limit="1"
                                    :file-list="fileList">
                                    <el-button size="default" type="primary">点击上传</el-button>
                                </el-upload>
                                <el-input width="180" placeholder="输入编号"></el-input>
                                <el-button @click.prevent="removeUpload(domain)" type="danger" icon="el-icon-delete"></el-button>
                            </div>
                        </el-form-item>
                        <!-- <template>
                            <el-form-item
                                label="上传/修改资源"
                                v-for="(domain, index) in form.type"
                                :key="index"
                            >
                                <div class="upload_file">
                                    <el-cascader
                                        v-model="form.modType"
                                        :options="form.options"
                                        @change="handleChange"></el-cascader>
                                    <el-upload
                                        action="https://jsonplaceholder.typicode.com/posts/"
                                        :on-preview="handlePreview"
                                        :on-remove="handleRemove"
                                        :limit="1"
                                        :file-list="fileList">
                                        <el-button size="default" type="primary">点击上传</el-button>
                                    </el-upload>
                                    <el-input width="180" placeholder="输入编号"></el-input>
                                    <el-button @click.prevent="removeUpload(domain)" type="danger" icon="el-icon-delete"></el-button>
                                </div>
                            </el-form-item>
                        </template> -->
                        <el-form-item v-if="packFlag">
                            <el-button @click="addUpload" icon="el-icon-plus"></el-button>
                        </el-form-item>
                        <el-form-item>
                            <el-button type="primary" @click="submit">立即创建</el-button>
                            <el-button>取消</el-button>
                        </el-form-item>
                    </el-form>
                </div>
            </el-main>
        </el-container>
    </div>
</template>

<script>
import api from '../../api/api'
export default {
    name: 'plugin',
    data () {
        return {
            packTitle: '',
            form: {
                modelSVNPath: '',
                branchSVNPath: '',
                SVNAccount: '',
                SVNPwd:'',
                modType: '',
                uploadFile: [
                    {
                        type: '',
                        file: '',
                    }
                ],
                type: [
                ],
                name: '',
                file: '',
                options: []
            },
            fileList:[],
            packFlag: true
        }
    },
    mounted () {
        this.formInit();
    },
    methods: {
        handleChange () {},
        handleEdit () {},
        handleDelete () {},
        handlePreview () {},
        handleRemove (){},
        getResType () {
            this.$ajax({
                methos: 'get',
                url: api.resType,
                params: {
                    tp_id: '8200'
                }
            }).then((res) => {
                this.form.type = res.data;
                console.log(this.form.type);
                console.log(res);
            }).catch((err) => {
                console.log(err);
            });
        },
        formInit () {
            if (this.$route.params.type === 'add') {
                this.packTitle = "新增模板";
            } else {
                this.packTitle = "在线打包";
            }
            console.log(this.$route.params.type);
            this.packFlag = this.$route.params.type === 'pack' ? true : false;
            if (this.packFlag) {
                this.getResType();
            }
        },
        goBack () {
            this.$router.push('packList');
        },
        addUpload () {
            if (this.form.file === 'fileModify') {
                this.form.type.push({
                    "options":[
                        '名称',
                        '包名',
                        '版本号',
                        '版本名称'
                    ]
                })
            } else {
                this.form.type.push({
                    "options":[
                        '图标',
                        'H5资源包'
                    ]
                })
            }
        },
        removeUpload (item) {
            var index = this.form.type.indexOf(item);
            if (index !== -1) {
                this.form.type.splice(index, 1);
            }
        },
        submit () {
            this.$ajax({
                method: 'post',
                url: api.addTemplate,
                data: {
                    tp_id: '142',
                    tp_name: '智能应用2平2台1',
                    tp_code_path: this.form.modelSVNPath,
                    tp_branch_path: this.form.branchSVNPath,
                    tp_code_account: this.form.SVNAccount,
                    tp_code_pwd: this.form.SVNPwd
                }
            }).then((res) => {
                let data = res.data;
                if (data.code == 0) {
                    this.$message({
                        message: '新增模板成功!',
                        type: 'success'
                    });
                    this.$route.push('packList');
                } else {
                    this.$message({
                        message: data.msg,
                        type: 'warning'
                    })
                }
                console.log(data);
            }).catch((err) => {
                this.$message({
                    message: '新增模板失败!',
                    type: 'fail'
                })
                console.log(err);
            })
        }
    }
}
</script>

<style lang="scss" scoped>
.pack {
    width: 100%;
    height: 100%;
    .el-main {
        .packList {
            width: 100%;
            .el-page-header {
                margin-bottom: 40px;
                padding-bottom: 20px;
                border-bottom: 1px solid #dddddda6;
            }
            .upload_file {
                display: flex;
                div {
                    &:nth-child(2) {
                        min-width: 200px;
                        text-align: center;
                        overflow: hidden;
                        text-overflow: ellipsis;
                        ul {
                            list-style: circle;
                        }
                    }
                    &:nth-child(3) {
                        margin-right: 20px;
                    }
                }
                button {
                    max-height: 40px;
                }
            }
        }
    }
}
</style>
