<template>
    <div class="case">
        <h1>SHOW CASE PAGE</h1>
    </div>
</template>

<script>
export default {
    name: 'showCase',
    data () {
        return {}
    }
}
</script>

<style lang="scss" scoped>

</style>
