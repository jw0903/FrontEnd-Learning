<template>
    <div class="case">
        <h1>PERSONAL PAGE</h1>
    </div>
</template>

<script>
export default {
    name: 'personal',
    data () {
        return {}
    }
}
</script>

<style lang="scss" scoped>

</style>
